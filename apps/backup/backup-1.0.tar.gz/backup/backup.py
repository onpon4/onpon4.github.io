#!/usr/bin/env python3

# Copyright 2014 Julian Marchant <onpon4@riseup.net>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

__version__ = "1.0"

import sys
import os
import argparse
import tempfile
import tarfile
import subprocess


COMPRESSION = ""
KEY = "backup@localhost"
FILES = [
    "~/Documents/important_document_1.txt",
    "~/Documents/important_document_2.odt",
    "~/Documents/important_document_3.pdf",
    "~/Pictures",
    "~/Videos/funny_cat_video.webm",
    "~/Videos/PersonalBusiness",
    ]

TAR_EXTENSION = ".tar.{}".format(COMPRESSION) if COMPRESSION else ".tar"
GPG_EXTENSION = TAR_EXTENSION + ".gpg"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output",
                        default=os.path.join(os.getcwd(), "backup"),
                        help="custom name to save the backup as")
    args = parser.parse_args()
    backup_dest = args.output
    if not backup_dest.endswith(GPG_EXTENSION):
        backup_dest += GPG_EXTENSION

    with tempfile.TemporaryDirectory() as tempdir:
        backup = os.path.join(tempdir, "backup{}".format(TAR_EXTENSION))
        print("Creating {}...".format(backup))
        tar = tarfile.open(backup, "w:{}".format(COMPRESSION))
        for origin in FILES:
            origin = origin.replace("~", os.path.expanduser("~"))
            print("Adding {} to archive...".format(origin))
            tar.add(origin, origin)
        tar.close()

        print("Encrypting tar archive as {}...".format(backup_dest))
        subprocess.call(["gpg", "-o", backup_dest, "-r", KEY, "--encrypt",
                         backup])

    print("Done.")


if __name__ == '__main__':
    sys.exit(main())
