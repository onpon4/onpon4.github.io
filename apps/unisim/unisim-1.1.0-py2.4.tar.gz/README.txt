Running UniSim
-----------------------------------------------------------
If you downloaded one of the binaries, simply run the
binary (i.e. UniSim.exe) to start the application.

If you downloaded the source, you must download and install
the following:

    Python 2.4 or later*  <http://www.python.org/>
    Pygame 1.8.1 or later  <http://www.pygame.org/>
    NumPy  <http://numpy.scipy.org/> (old Numeric is also fine)

    * This program is not compatible with Python 3 or later.

Once you have all of them installed, simply open unisim.py
with the Python binary (i.e. python.exe). On UNIX-like
systems, you can simply tell the OS to run unisim.py and it
will automatically launch it with the current version of
Python found on your machine.

UniSim for Python 2.x also supports Psyco
(<http://psyco.sourceforge.net/>), which will improve the
speed of UniSim. I try to include Psyco with the binary
versions to ensure optimum performance.


Configuring UniSim
-----------------------------------------------------------
UniSim can easily be configured via the text file,
config.txt (found in the same directory as UniSim). Simply
open it with any plain text editor of your choice and edit
the values. Remember that names are case-sensitive; Foo is
not the same as foo or FOO.
