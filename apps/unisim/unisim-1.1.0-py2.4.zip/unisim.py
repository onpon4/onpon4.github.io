#!/usr/bin/env python

# UniSim
# Copyright (C) 2011 Julian Marchant <onpon4@yahoo.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Programmed for Python 2.2

from __future__ import division


import os
import sys
import math
import random
import copy

import pygame
from pygame.locals import *


class GameOfLife(object):
    """Creates a simulated universe based on John Conway's
    Game of Life. Note one major difference: the Game of
    Life is supposed to be infinite in size, but as a
    simplification, this version simply has a defined size
    and wraps (that is, the leftmost square is considered
    to be adjacent to the rightmost square).

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, tuple([3]), (2,3), color)

    def init(self, size, dispsize, initarea, chance, fullscreen,
             seed, born, survives, color):
        """This is separated from __init__, allowing other
        versions of Conway's Game of Life to more easily
        inherit this class.

        """
        pygame.init()
        random.seed(seed)

        #dispsize = (int(size[0]//pixelsquares), int(size[1]//pixelsquares))

        self.window = pygame.display.set_mode(dispsize, fullscreen*FULLSCREEN)

        self.image = pygame.Surface(size).convert()
        self.image.fill(pygame.Color(0, 0, 0, 255))
        self.rect = Rect((0,0), dispsize)

        dispsurf = pygame.Surface(dispsize).convert()

        # Choose scale method
        if dispsize[0] < size[0] or dispsize[1] < size[1]:
            self.scale = pygame.transform.smoothscale
        else:
            self.scale = pygame.transform.scale

        self.clock = pygame.time.Clock()

        # Set universe
        self.state = []
        for i in xrange(0, size[0]):
            self.state.append([])
            for j in xrange(0, size[1]):
                self.state[i].append(False)

        # Set colors
        self.red = []
        self.green = []
        self.blue = []
        for i in xrange(0, size[0]):
            self.red.append([])
            self.green.append([])
            self.blue.append([])
            for j in xrange(0, size[1]):
                if color:
                    xseq = i % 3
                    yseq = j % 3

                    if yseq == 0:
                        self.red[i].append(255*(xseq==0))
                        self.green[i].append(255*(xseq==1))
                        self.blue[i].append(255*(xseq==2))
                    elif yseq == 1:
                        self.red[i].append(255*(xseq==1))
                        self.green[i].append(255*(xseq==2))
                        self.blue[i].append(255*(xseq==0))
                    else:
                        self.red[i].append(255*(xseq==2))
                        self.green[i].append(255*(xseq==0))
                        self.blue[i].append(255*(xseq==1))
                else:
                    self.red[i].append(255)
                    self.green[i].append(255)
                    self.blue[i].append(255)

        xspace = max(size[0]-initarea[0], 0)
        yspace = max(size[1]-initarea[1], 0)
        for i in xrange((xspace//2), size[0]-(xspace//2)):
            for j in xrange((yspace//2), size[1]-(yspace//2)):
                self.state[i][j] = (random.random() < chance)

        # Begin loop
        while 1:
            # Quit if requested
            for event in pygame.event.get():
                if event.type == QUIT \
                   or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    return

            # Limit frame rate to 60 FPS
            self.clock.tick(10)

            # Adjust "live" and "dead"
            imgarray = pygame.surfarray.pixels2d(self.image)
            new = copy.deepcopy(self.state)
            for x in xrange(0, len(self.state)):
                for y in xrange(0, len(self.state[x])):
                    xbef = (x-1) % len(self.state)
                    xaft = (x+1) % len(self.state)
                    ybef = (y-1) % len(self.state[x])
                    yaft = (y+1) % len(self.state[x])
                    neighbors = self.state[xbef][ybef] + \
                                self.state[x][ybef] + \
                                self.state[xaft][ybef] + \
                                self.state[xbef][y] + \
                                self.state[xaft][y] + \
                                self.state[xbef][yaft] + \
                                self.state[x][yaft] + \
                                self.state[xaft][yaft]

                    if self.state[x][y]:
                        if not neighbors in survives:
                            new[x][y] = False

                    else:
                        if neighbors in born:
                            new[x][y] = True

                    # Set pixel
                    r = int(new[x][y]*self.red[x][y])
                    g = int(new[x][y]*self.green[x][y])
                    b = int(new[x][y]*self.blue[x][y])
                    color = self.image.map_rgb(pygame.Color(r, g, b, 255))

                    imgarray[x][y] = color

            self.state = new
            del imgarray

            self.scale(self.image, dispsize, dispsurf)

            self.window.blit(dispsurf, self.rect)
            pygame.display.update()

class HighLife(GameOfLife):
    """B36/S23

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, (3,6), (2,3), color)

class LifeWithoutDeath(GameOfLife):
    """B3/S012345678

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, tuple([3]), (0,1,2,3,4,5,6,7,8), color)

class DayAndNight(GameOfLife):
    """B3678/S34678

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, (3,6,7,8), (3,4,6,7,8), color)

class Seeds(GameOfLife):
    """B2/S

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, tuple([2]), tuple(), color)

class Gnarl(GameOfLife):
    """B1/S1

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, tuple([1]), tuple([1]), color)

class Replicator(GameOfLife):
    """B1357/S1357

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, (1,3,5,7), (1,3,5,7), color)

class Serviettes(GameOfLife):
    """B234/S

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, (2,3,4), tuple(), color)

class Maze(GameOfLife):
    """B3/S12345

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, tuple([3]), (1,2,3,4,5), color)

class Coral(GameOfLife):
    """B3/S45678

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, tuple([3]), (4,5,6,7,8), color)

class Amoeba(GameOfLife):
    """B357/S1358

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, (3,5,7), (1,3,5,8), color)

class Stains(GameOfLife):
    """B3678/S235678

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, (3,6,7,8), (2,3,5,6,7,8))

class WalledCities(GameOfLife):
    """B45678/S2345

    """
    def __init__(self, size, dispsize, initarea=(16,16), chance=0.5,
                 fullscreen=False, seed=None, color=True):
        self.init(size, dispsize, initarea, chance, fullscreen,
                  seed, (4,5,6,7,8), (2,3,4,5))

def main():
    unitype = GameOfLife
    unisize = (320,240)
    dispsize = (800,600)
    initarea = (16,16)
    spawnchance = 0.4
    fullscreen = False
    seed = None
    color = True

    # Some extra variables to aid laymen with the config
    # file (i.e. make True, False, and None less case-
    # sensitive)
    true = True
    false = False
    TRUE = True
    FALSE = False
    none = None
    NONE = None

    if os.path.exists('config.txt'):
        f = open('config.txt', 'r')
        ftext = f.read()
        f.close()
        exec ftext
##        with open('config.txt', 'r') as f:
##            exec f

    # If Psyco is available, use it to speed-up the program.
    try:
        import psyco
        psyco.full()
    except ImportError:
        pass

    unitype(unisize, dispsize, initarea, spawnchance, fullscreen,
            seed, color)

if __name__ == '__main__':
    main()
