#!/usr/bin/python

# Random Phrase Generator
# Copyright 2012 Julian Marchant <onpon4@yahoo.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""Random phrase generator.
Usage: phrasegen.py [options] INDEX

Generate random phrases using the given index.

Options:
  -h, --help                   Show this help text.
  -n                           Specify a certain number of phrases to
                                 generate.

"""

from __future__ import division
from __future__ import absolute_import
from __future__ import unicode_literals
from __future__ import print_function

__version__ = "1.2"

import sys
import os
import random
from random import random as rand
import json
import warnings

DEFAULT_INDEX = "freedom_index.json"

# These defaults are necessary.  They allow the assumption that
# the format of ``index`` is correct without also requiring the
# end-user to format the index exactly correctly.
index = {'actions':('eat pudding',),
         'nouns':{}, 'subnouns':{},
         'prefix':("I like to ",), 'suffix':(".",)}


def load_index(fname, replace=False):

    """Load the given index file located at ``fname``.

    Load the JSON file with the file name ``fname`` and store it for
    later use with other functions.  If ``replace`` is True, the
    currently loaded index will be replaced entirely; otherwise, the
    newly loaded index will be appended to the current one.

    """

    global index

    if replace:
        # These defaults are necessary.  They allow the assumption that
        # the format of ``index`` is correct without also requiring the
        # end-user to format the index exactly correctly.
        index = {'actions':('rant in front of a camera',),
                 'nouns':{}, 'subnouns':{},
                 'prefix':("I like to",), 'suffix':(".",)}

    with open(fname, 'r') as f:
        index.update(json.load(f))

    for noun in index['nouns'].keys():
        try:
            index['nouns'][noun].setdefault('properties', ())
            index['nouns'][noun].setdefault('otherwords', ())
            index['nouns'][noun].setdefault('subnouns', ())
        except AttributeError:
            del index['nouns'][noun]
            warnings.warn('"{0}" in {1} is not correctly formatted.'.format(
                noun, os.path.normpath(fname)))

    for noun in index['subnouns'].keys():
        try:
            index['subnouns'][noun].setdefault('properties', ())
            index['subnouns'][noun].setdefault('otherwords', ())
        except AttributeError:
            del index['subnouns'][noun]
            warnings.warn('"{0}" in {1} is not correctly formatted.'.format(
                noun, os.path.normpath(fname)))


def generate():

    """Generate phrase and return it."""

    action = index['actions'][random.randrange(0, len(index['actions']))]

    while '{' in action and '}' in action:
        start = action.find('{')
        end = action.find('}')
        end = len(action) if end == -1 else end + 1

        wtype = action[start + 1:end - 1]

        possible_nouns = []

        for noun in index['nouns'].keys():
            if wtype in index['nouns'][noun]['properties']:
                possible_nouns.append(noun)

        for noun in index['subnouns'].keys():
            if wtype in index['subnouns'][noun]['properties']:
                possible_nouns.append(noun)

        if possible_nouns:
            chosen_noun = possible_nouns[random.randrange(
                0, len(possible_nouns))]

            if chosen_noun in index['nouns']:
                synonyms = list(index['nouns'][chosen_noun]['otherwords'])
                synonyms.append(chosen_noun)
                chosen_noun = synonyms[random.randrange(0, len(synonyms))]
            else:
                synonyms = list(index['subnouns'][chosen_noun]['otherwords'])
                synonyms.append(chosen_noun)
                chosen_subnoun = synonyms[random.randrange(0, len(synonyms))]

                possible_parents = []
                for noun in index['nouns'].keys():
                    if chosen_noun in index['nouns'][noun]['subnouns']:
                        possible_parents.append(noun)

                if possible_parents:
                    parent = possible_parents[random.randrange(
                        0, len(possible_parents))]

                    synonyms = list(index['nouns'][parent]['otherwords'])
                    synonyms.append(parent)
                    parent = synonyms[random.randrange(0, len(synonyms))]

                    if rand() < 0.5:
                        chosen_noun = "{0}'s {1}".format(parent, chosen_subnoun)
                    else:
                        chosen_noun = "the {1} of {0}".format(parent,
                                                              chosen_subnoun)
                else:
                    chosen_noun = "something's {0}".format(chosen_subnoun)
        else:
            chosen_noun = '[{0}]'.format(wtype)

        action = chosen_noun.join((action[:start], action[end:]))

    prefix = index['prefix'][random.randrange(0, len(index['prefix']))]
    suffix = index['suffix'][random.randrange(0, len(index['suffix']))]

    return action.join((prefix, suffix))


def main(*args):

    """Main function, called automatically."""

    random.seed()

    numgenerations = -1
    try:
        load_index(DEFAULT_INDEX)
    except IOError:
        pass

    args = list(args)
    for i in xrange(1, len(args)):
        if args[i] == '-n':
            if i < len(args) - 1:
                args[i + 1] = ''.join(('-n', args[i + 1]))
        elif args[i] == '-h' or args[i] == '--help':
            print(__doc__.strip())
            return
        elif args[i].startswith('-n'):
            try:
                numgenerations = int(float(args[i][2:]))
            except ValueError:
                print('"{0}" is not a number.'.format(args[i][2:]))
                raise
        else:
            try:
                load_index(args[i])
            except IOError:
                print('Could not read "{0}".'.format(args[i]))
                raise

    try:
        input_ = raw_input
    except NameError:
        input_ = input

    if numgenerations > 0:
        for i in xrange(numgenerations):
            print(generate())
        input_('Press Enter to exit.')
    else:
        entry = ''
        while entry == '':
            print()
            print(generate())
            print()
            entry = input_('Press Enter to generate another, or type "quit" and press Enter to quit.')


if __name__ == '__main__':
    sys.exit(main(*sys.argv))
