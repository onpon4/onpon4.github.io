Random Phrase Generator
===============================================================================

This is a pretty simple program. It reads from an "index" file telling of
possible words and phrases (freedom_index by default) and generates phrases
based on them.


Running the program
-------------------------------------------------------------------------------

Before running this program, you need Python version 2.6 or later installed,
which you can get from <http://www.python.org/>. Once you have Python, simply
run phrasegen.py with Python (which usually simply involves double-clicking
phrasegen.py, but this may vary depending on your OS). If asked how to open it,
open it in a terminal.

Depending on your OS, you may already have Python installed (in particular,
GNU/Linux distributions tend to come with the latest version of Python). You
can find out if you already have Python installed by opening a terminal and
typing "python". If you have Python, the interpreter will start. It will print
the version number of Python you have installed; if it is at least version 2.6,
it will work with this program.

A note for GNU/Linux users: you may have to modify phrasegen.py's permissions
to allow it to be executed as a program. Alternatively, you can run it with the
command:

    python phrasegen.py


Modifying the index
-------------------------------------------------------------------------------

This program works by checking an "index" file and creating random
combinations. The index file can be edited or replaced.

Index files are standard JSON files with a pretty straightforward format.
Basically, lines from "actions" are chosen at random, then all words contained
in curly braces ({}) are replaced with a random noun or subnoun that has the
contained word as a property. There are no particular rules for properties, but
note that properties are case-sensitive; "badthing" is not the same as
"BadThing".

Subnouns are objects that belong to another. For example, "Windows" might be a
subnoun of "Microsoft". In this example, it would be rendered as either
"Microsoft's Windows" or "Windows of Microsoft". Subnouns are defined under the
"subnouns" section of each noun. At this time, subnouns cannot have their own
subnouns.

NOTE: If the file is not formatted correctly, an error will be spit out when
the program is run that usually says "ValueError". In most cases, it will tell
you exactly which line the error is on. If it is not being of any help, use a
JSON validator tool to check the syntax.
