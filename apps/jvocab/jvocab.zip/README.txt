﻿JVocab (Version 1.1.2) README.txt
=====================================================================

Thank you for using JVocab!

This is a simple review tool for Japanese. It allows you to create
custom "dictionaries" of words to review and review them by being
given a random set out of that "dictionary" for you to supply the
English meaning, the correct kana order, or both, for.


Copyright Info:
---------------------------------------------------------------------

Copyright (c) Julian Marchant ("onpon4")

JVocab is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

JVocab is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with JVocab. If not, see <http://www.gnu.org/licenses/>.


Running JVocab:
---------------------------------------------------------------------

If you have an executable version, you simply need to run the JVocab
binary, which is called "jvocab" on all platforms (with the
appropriate extension for the platform). A number of files must also
be present in order for the program to run; see DEPENDENCIES.txt for
a list of these files.

If you downloaded the source code, you must download and install the
following (the exact process can vary between operating systems):

    Python version 2.6 or later*
    wxPython version 2.8** (Unicode***)

*This program WILL NOT WORK with Python 3.x and beyond. You MUST
use Python 2.x (where x is the latest release available). At the
time of this text file's creation, the latest stable version is
version 2.7.1.

**This program may not be compatible with versions prior to or
following wxPython version 2.8.

***For versions prior to and including wxPython 2.8, there are
two versions: the ASCII version and the Unicode version. You must
choose the Unicode version for this program to work.

Most Linux distributions already have a version of Python installed.
Do make sure it is at least version 2.6 before opting to use it.

Once you have Python and wxPython, simply run jvocab.py with Python.
This is usually done by double-clicking it and telling the OS what
to run it with (if an association for the .py extension hasn't
already been made) or by right clicking and choosing "Open with".
Under Linux, it will automatically try to use "/usr/bin/python" if
you tell the OS to run it (this can be changed if your Python
installation is located elsewhere by using a text editor to modify
the shebang at the beginning of the file).

Alternatively, you can open a terminal, navigate to the directory
(using "cd" or a similar command) where JVocab is located, and type
the name of the Python executable followed by jvocab.py. This tells
most operating systems to open jvocab.py with the Python executable
indicated. If this is the method you use, you can make your life
easier by creating a shortcut which will do the sequence for you.


Using JVocab:
---------------------------------------------------------------------

Before you can start a review, you must first load a "dictionary"
text file. See below under "Creating Dictionaries" to learn how to
create these text files. To load the dictionary, choose Load
Dictionary from the File menu. If you try to start a review before
loading a dictionary, JVocab will prompt you to load one.

Once the dictionary is loaded, choose Start Review from the File menu
start reviewing. Choose the number of words to study in the Range
Selection dialog. In the Review Type dialog, choose the basic options
for the review. The review will then start.

To select a word, simply click on the word in the list box on the
left. When a word is selected, the word is displayed to the right. If
the review is set to display readings (pronunciation), the reading of
the word (as specified by the dictionary text file) will also be
shown below the word.

If the review is set to score for word order, the two buttons on the
left (labeled "上" and "下") will shift the position of the currently
selected word in the indicated direction (上 for up, 下 for down). See
"Word Ordering" below for details on word order scoring.

If the review is set to score for meaning, the English meaning of
each word should be entered into the box labeled "英語は". Leaving this
blank counts as wrong, so it is better to guess.

When you are finished with the review, simply click Done. JVocab will
then calculate your score and show you which words you got right and
which ones you got wrong. Green indicates that the word is correct,
yellow indicates that it is partially correct (used only for word
order; see "Word Ordering" below), and red indicates that it is
incorrect.


Word Ordering:
---------------------------------------------------------------------

Word ordering is a possible element of scoring in JVocab. It is based
on the reading of each word indicated in the dictionary text file (or
the word itself if no reading is supplied) and the hiragana/katakana
chart, which is ordered as follows:

    あ　い　う　え　お
    か　き　く　け　こ
    さ　し　す　せ　そ
    た　ち　つ　て　と
    な　に　ぬ　ね　の
    は　ひ　ふ　へ　ほ
    ま　み　む　め　も
    や　　　ゆ　　　よ
    ら　り　る　れ　ろ
    わ　　　　　　　を
    ん

When a set is finished, JVocab scores based on which words are
ordered correctly based on their relation to other words. For example,
if the correct order is A, B, C, D, E, then E, A, B, C, D will result
in a score of 3/4, while A, D, C, B, E will result in a score of 0/4.
Notice that the maximum score is the number of words minus 1; this is
always the case.

When the exact results are shown, each word is colored green, yellow,
or red. Green indicates that the word is in the correct position;
however, note that points are only scored if two words in a row are
correct. For example, even though A, D, C, B, E (above) scores 0
points, A, C, and E will be displayed in green.

If the word is not in the correct position, but points were scored
for it, the word will be colored yellow. This indicates that the word
is "partially correct"; that is, it is in the wrong absolute position,
but it is correct in relation to one of the other words and has been
scored as correct.


Creating Dictionaries:
---------------------------------------------------------------------

JVocab uses "dictionary" text files to load words from, allowing you
to easily customize the words you review. Dictionaries are nothing
more than plain text files; you can create them using any plain text
editor. Note that the files must be plain text; JVocab cannot read
Rich Text (.rtf), Word (.doc), OOXML (.docx), or any other formatted
text. All dictionaries must be saved as plain text files. Therefore,
I recommend using a plain text editor (such as Windows Notepad or
Gedit) rather than "rich text" or document editors (such as Microsoft
Word or OpenOffice.org Writer). If you do use one of these editors,
be sure to save the document as "plain text".

It is important to note that dictionaries should be encoded in
Unicode (preferably UTF-8). This is because hiragana, katakana, and
kanji are not available in ASCII or ANSI (which are sometimes the

default encoding for text editors). Most text editors will prompt you
to save in another encoding if the format specified doesn't support
all characters on the document, including the lowly Windows
Notepad, so this shouldn't be an issue normally. However, bear in
mind that if you save in a format which doesn't support certain
characters, said characters will be lost.

For an example of a dictionary text file, see the included file,
example.txt.

Any line beginning with a hash (#) is a comment. Comments are ignored
by JVocab and can be used to insert notes (i.e. information about a
set of words). You can also insert a hash to "erase" a word which you
don't need to review, but still be able to re-add it by removing the
hash.

Other lines (excluding blank lines and lines containing only spaces)
are treated as dictionary entries. Each entry takes the following
form:

    今日｜きょう = today; this day

The first part is the word itself. If the word contains kanji, a
reading must be specified as well. The word and reading are separated
by a vertical line (| or ｜) or a Japanese dot (・), with the word
coming first. Any characters which are not kana are ignored
(including alphanumeric characters).

The second part, indicated by the equals sign (= or ＝) is a list of
possible English meanings. Each pair of possible meanings must be
separated by either a semicolon (;), a forward slash (/), or a
backslash (\). Note that all meanings specified here are displayed
to the user at the end.

Optionally, you can also specify a third part, indicated by an
ampersand (& or ＆). This is another list of possible English meanings,
but these are not displayed at the end. This can be used for common
misspellings, different conjugations for verbs, or other possible
anomalies which should be counted as correct. An example of an entry
using this thrid part would be:

    知る｜しる = to know && know; will know; knows; I know

This way, while "know", "knows", "I know", and "will know" will be
accepted as correct, only "to know" will be displayed to the user
when given the correct answers.

Due to the way dictionary text files are read, there is no harm in
using multiple separators. You may also include any amount of spaces
and/or tabs between the different elements.
