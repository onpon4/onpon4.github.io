#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Copyright (c) Julian Marchant ("onpon4")

This file is part of JVocab.

JVocab is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

JVocab is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with JVocab.  If not, see <http://www.gnu.org/licenses/>.

"""

from __future__ import print_function

import os, io, random, wx

hiragana = [['あ', 'い', 'う', 'え', 'お'],
            ['か', 'き', 'く', 'け', 'こ'],
            ['さ', 'し', 'す', 'せ', 'そ'],
            ['た', 'ち', 'つ', 'て', 'と'],
            ['な', 'に', 'ぬ', 'ね', 'の'],
            ['は', 'ひ', 'ふ', 'へ', 'ほ'],
            ['ま', 'み', 'む', 'め', 'も'],
            ['や', '　', 'ゆ', '　', 'よ'],
            ['ら', 'り', 'る', 'れ', 'ろ'],
            ['わ', '　', '　', '　', 'を'],
            ['ん', '　', '　', '　', '　']]

katakana = [['ア', 'イ', 'ウ', 'エ', 'オ'],
            ['カ', 'キ', 'ク', 'ケ', 'コ'],
            ['サ', 'シ', 'ス', 'セ', 'ソ'],
            ['タ', 'チ', 'ツ', 'テ', 'ト'],
            ['ナ', 'ニ', 'ヌ', 'ネ', 'ノ'],
            ['ハ', 'ヒ', 'フ', 'ヘ', 'ホ'],
            ['マ', 'ミ', 'ム', 'メ', 'モ'],
            ['ヤ', '　', 'ユ', '　', 'ヨ'],
            ['ラ', 'リ', 'ル', 'レ', 'ロ'],
            ['ワ', '　', '　', '　', 'ヲ'],
            ['ン', '　', '　', '　', '　']]

# These are the other forms of the kana, which are
# in the same place when it comes to alphabetical order.
same_kana = {'が':'か', 'ぎ':'き', 'ぐ':'く', 'げ':'け',
             'ご':'こ', 'ざ':'さ', 'じ':'し', 'ず':'す',
             'ぜ':'せ', 'ぞ':'そ', 'だ':'た', 'ぢ':'ち',
             'づ':'つ', 'で':'て', 'ど':'と', 'ば':'は',
             'び':'ひ', 'ぶ':'ふ', 'べ':'へ', 'ぼ':'ほ',
             'ぱ':'は', 'ぴ':'ひ', 'ぷ':'ふ', 'ぺ':'へ',
             'ぽ':'ほ', 'ぁ':'あ', 'ぃ':'い', 'ぅ':'う',
             'ぇ':'え', 'ぉ':'お', 'っ':'つ', 'ゃ':'や',
             'ゅ':'ゆ', 'ょ':'よ', 'ゎ':'わ', 'ガ':'カ',
             'ギ':'キ', 'グ':'ク', 'ゲ':'ケ', 'ゴ':'コ',
             'ザ':'サ', 'ジ':'シ', 'ズ':'ス', 'ゼ':'セ',
             'ゾ':'ソ', 'ダ':'タ', 'ヂ':'チ', 'ヅ':'ツ',
             'デ':'テ', 'ド':'ト', 'バ':'ハ', 'ビ':'ヒ',
             'ブ':'フ', 'ベ':'ヘ', 'ボ':'ホ', 'パ':'ハ',
             'ピ':'ヒ', 'プ':'フ', 'ペ':'ヘ', 'ポ':'ホ',
             'ァ':'ア', 'ィ':'イ', 'ゥ':'ウ', 'ェ':'エ',
             'ォ':'オ', 'ヵ':'カ', 'ヶ':'ケ', 'ッ':'ツ',
             'ャ':'ヤ', 'ュ':'ユ', 'ョ':'ヨ', 'ヮ':'ワ'}

# Convert hiragana/katakana to unicode
for row in xrange(0,len(hiragana)):
    for kana in xrange(0,len(hiragana[row])):
        hiragana[row][kana] = unicode(hiragana[row][kana], 'utf_8')

for row in xrange(0,len(katakana)):
    for kana in xrange(0,len(katakana[row])):
        katakana[row][kana] = unicode(katakana[row][kana], 'utf_8')

for kana in same_kana.keys():
    same_kana[unicode(kana, 'utf_8')] = unicode(same_kana[kana], 'utf_8')
    del same_kana[kana]

def kana_index(kana):
    """Determines the position on the kana chart which
    a given kana would be found on. Returns a list with
    2 integers in the form [row/consonant, column/vowel].
    Returns None if the given kana is not found.

    This function does not handle the character "ー",
    since it cannot be handled without knowing the character
    which comes before it. To find its position, simply
    use this function on the character directly before it
    and change the first index of the return value to 0.

    """
    returnvalue = None

    # Replace smaller versions with the "larger" version
    if kana in same_kana.keys():
        kana = same_kana[kana]
    
    for row in xrange(0,len(hiragana)):
        if kana in hiragana[row]:
            for k in xrange(0,len(hiragana[row])):
                if kana == hiragana[row][k]:
                    returnvalue = (row,k)

        elif kana in katakana[row]:
            for k in xrange(0,len(katakana[row])):
                if kana == katakana[row][k]:
                    returnvalue = (row,k)

    return returnvalue

def del_nonkana(ustr):
    """Deletes all characters (including whitespace) which
    are not kana. Japanese style spaces are treated specially
    and refused kana status. Uses kana_index function.

    """
    returnvalue = ''

    for s in ustr:
        if s != unicode('　', 'utf_8') \
           and kana_index(s) != None:
            returnvalue += s

    return returnvalue

def order_alpha(words):
    for w in xrange(0,len(words)):
        for c in xrange(0,w):
            solved = 0
            for i in xrange(0, min(len(words[w]['reading']),len(words[c]['reading']))):
                # Handle the special character "ー"
                if words[w]['reading'][i] == unicode('ー', 'utf_8'):
                    if i > 0:
                        w_index = (0, kana_index(words[w]['reading'][i-1])[1])
                    else:
                        w_index = (42,0)
                else:
                    w_index = kana_index(words[w]['reading'][i])

                if words[c]['reading'][i] == unicode('ー', 'utf_8'):
                    if i > 0:
                        c_index = (0, kana_index(words[c]['reading'][i-1])[1])
                    else:
                        c_index = (42,0)
                else:
                    c_index = kana_index(words[c]['reading'][i])

                if w_index[0] < c_index[0]:
                    words.insert(c,words.pop(w))
                    solved = 1
                    break
                elif w_index[0] > c_index[0]:
                    solved = 1
                    break
                else:
                    if w_index[1] < c_index[1]:
                        words.insert(c,words.pop(w))
                        solved = 1
                        break
                    elif w_index[1] > c_index[1]:
                        solved = 1
                        break
                    
            if not solved:
                if len(words[w]) < len(words[c]):
                    words.insert(c,words.pop(w))

    return words

def load_dictionary(fname):
    """Loads from specified dictionary file and returns the
    dictionary.

    """
    f = io.open(fname, 'r', 2, 'utf_8_sig')

    words = []

    line = f.readline()
    while line != u'':
        line = line.strip()

        if line != u'' and line[0] != u'#':
            word = u''
            reading = u''
            meaning = u''
            meanings = []
            alt_meanings = []
            curvar = u'word'

            for char in line:
                if (char == unicode('・', 'utf_8') \
                    or char == unicode('｜', 'utf_8') or char == u'|'):
                    curvar = 'reading'

                elif char == unicode('＝', 'utf_8') or char == u'=':
                    if curvar == 'alt_meanings':
                        meaning = meaning.strip(unicode(' 　\t', 'utf_8'))
                        if meaning != u'' and not meaning in meanings:
                            alt_meanings.append(meaning)
                        meaning = u''
                    
                    curvar = 'meanings'
                
                elif char == unicode('＆', 'utf_8') or char == u'&':
                    if curvar == 'meanings':
                        meaning = meaning.strip(unicode(' 　\t', 'utf_8'))
                        if meaning != u'' and not meaning in meanings:
                            meanings.append(meaning)
                        meaning = u''
                    
                    curvar = 'alt_meanings'

                else:
                    if curvar == 'meanings':
                        if char == u';' or char == u'/' or char == u'\\' \
                           or char == unicode('；', 'utf_8') \
                           or char == unicode('／', 'utf_8') \
                           or char == unicode('/', 'utf_8'):
                            meaning = meaning.strip(unicode(' 　\t', 'utf_8'))
                            if meaning != u'' and not meaning in meanings:
                                meanings.append(meaning)
                            meaning = u''
                        else:
                            meaning += char
                    elif curvar == 'alt_meanings':
                        if char == u';' or char == u'/' or char == u'\\':
                            meaning = meaning.strip(unicode(' 　\t', 'utf_8'))
                            if meaning != u'' and not meaning in meanings:
                                alt_meanings.append(meaning)
                            meaning = u''
                        else:
                            meaning += char
                    elif curvar == 'reading':
                        reading += char
                    else:
                        word += char

            # Add last meaning to list of meanings
            if curvar == 'meanings':
                meaning = meaning.strip(unicode(' 　\t', 'utf_8'))
                if meaning != '' and not meaning in meanings:
                    meanings.append(meaning)
            elif curvar == 'alt_meanings':
                meaning = meaning.strip(unicode(' 　\t', 'utf_8'))
                if meaning != '' and not meaning in meanings:
                    alt_meanings.append(meaning)

            # Ignore entries without a word and/or meaning defined
            if word != u'' and meanings != []:
                reading = del_nonkana(reading)
                if reading == u'':
                    # There is no reading, so assume that the reading
                    # is the same as the word (i.e., there is no kanji)
                    reading = del_nonkana(word)

                # If the reading is still empty, ignore this entry.
                if reading != u'':
                    words.append({'word':word.strip(unicode(' 　\t', 'utf_8')),
                                  'reading':reading.strip(unicode(' 　\t', 'utf_8')),
                                  'meanings':meanings,
                                  'alt_meanings':alt_meanings})

        line = f.readline()

    f.close()

    return words

class Frame(wx.Frame):
    def __init__(self, parent, ID):
        cap = 'Japanese Vocab'
        wx.Frame.__init__(self, parent, ID, cap, size=(480,400))

        self.dictionary = []
        random.seed()

        statusbar = self.CreateStatusBar()
        menubar = wx.MenuBar()
        filemenu = wx.Menu()
        helpmenu = wx.Menu()

        m = filemenu.Append(wx.NewId(), 'Start &Review', 'Start review with current loaded dictionary')
        self.Bind(wx.EVT_MENU, self.OnStart, m)
        m = filemenu.Append(wx.NewId(), '&Load Dictionary', 'Choose a new dictionary to review')
        self.Bind(wx.EVT_MENU, self.OnLoad, m)
        m = filemenu.Append(wx.NewId(), 'E&xit', 'Quit this application')
        self.Bind(wx.EVT_MENU, self.OnExit, m)

        menubar.Append(filemenu, '&File')
        self.SetMenuBar(menubar)

        self.panel = WordsPanel(self)

        self.Show(1)

    def OnStart(self, event):
        self.panel.StartSet()

    def OnLoad(self, event):
        self.LoadDict()

    def OnExit(self, event):
        self.Close(1)

    def LoadDict(self):
        # Go to /dictionary first if possible
        if os.path.exists('dictionaries'):
            defdir = 'dictionaries'
        else:
            defdir = ''

        fdlg = wx.FileDialog(self, 'Choose a file', defdir, '', '*.*', wx.OPEN|wx.FD_FILE_MUST_EXIST)
        chosen = fdlg.ShowModal() == wx.ID_OK

        if chosen:
            fname = fdlg.GetPath()

            try:
                self.dictionary = load_dictionary(fname)

                if len(self.dictionary) < 2:
                    dlg = wx.MessageDialog(self, 'The dictionary was successfully loaded, but it is too small to be used. A dictionary must contain at least 2 words to be used. Please select another file.',
                                           'Too small', wx.OK|wx.ICON_ERROR)
                    dlg.ShowModal()
                    dlg.Destroy()
                    chosen = self.LoadDict()
                else:
                    dlg = wx.MessageDialog(self, 'The dictionary has been successfully loaded.',
                                           'Result', wx.OK|wx.ICON_INFORMATION)
                    dlg.ShowModal()
                    dlg.Destroy()
            except UnicodeDecodeError:
                dlg = wx.MessageDialog(self, 'File chosen ("{0}") is not a valid UTF-8 compatible plain text file. Please select another file.'.format(os.path.normpath(os.path.realpath(fname))),
                                       'File Error', wx.OK|wx.ICON_ERROR)
                dlg.ShowModal()
                dlg.Destroy()
                chosen = self.LoadDict()
        fdlg.Destroy()

        return chosen

class WordsPanel(wx.Panel):
    def __init__(self, parent):
        wx.Panel.__init__(self, parent)
        self.words = []
        self.selection = -1
        self.meanings = []
        self.auto_order = 0
        self.score_order = 0
        self.show_reading = 1
        self.score_meaning = 1

        hsizer = wx.BoxSizer(wx.HORIZONTAL)

        arrowsizer = wx.BoxSizer(wx.VERTICAL)
        infosizer = wx.BoxSizer(wx.VERTICAL)

        buttonfont = wx.Font(16, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL,
                             wx.FONTWEIGHT_BOLD)
        self.btnShiftUp = wx.Button(self, wx.NewId(), unicode('上', 'utf_8'), size=(48,48))
        self.btnShiftDown = wx.Button(self, wx.NewId(), unicode('下', 'utf_8'), size=(48,48))
        self.btnShiftUp.SetFont(buttonfont)
        self.btnShiftDown.SetFont(buttonfont)
        self.Bind(wx.EVT_BUTTON, self.OnShiftUp, self.btnShiftUp)
        self.Bind(wx.EVT_BUTTON, self.OnShiftDown, self.btnShiftDown)
        self.btnShiftUp.Enable(0)
        self.btnShiftDown.Enable(0)
        
        arrowsizer.AddStretchSpacer()
        arrowsizer.Add(self.btnShiftUp, 0, wx.BOTTOM|wx.ALIGN_TOP|wx.ALIGN_CENTER_HORIZONTAL, 3)
        arrowsizer.Add(self.btnShiftDown, 0, wx.TOP|wx.ALIGN_BOTTOM|wx.ALIGN_CENTER_HORIZONTAL, 3)
        arrowsizer.AddStretchSpacer()

        self.lstWords = wx.ListBox(self, -1, choices=[], style=wx.LB_SINGLE|wx.LB_HSCROLL)
        self.Bind(wx.EVT_LISTBOX, self.OnSelectWord, self.lstWords)

        wordfont = wx.Font(20, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL,
                           wx.FONTWEIGHT_NORMAL)
        meaningfont = wx.Font(12, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL,
                              wx.FONTWEIGHT_NORMAL)

        self.sttWord = wx.StaticText(self, -1, u'')
        self.sttReading = wx.StaticText(self, -1, u'')
        sttMeaningLabel = wx.StaticText(self, -1, unicode('英語は', 'utf_8'))
        self.txtMeaning = wx.TextCtrl(self, -1)
        self.Bind(wx.EVT_TEXT, self.OnChangeMeaningText, self.txtMeaning)
        self.txtMeaning.Enable(0)

        self.sttWord.SetFont(wordfont)
        sttMeaningLabel.SetFont(meaningfont)
        
        self.btnDone = wx.Button(self, wx.NewId(), 'Done')
        self.Bind(wx.EVT_BUTTON, self.OnDone, self.btnDone)
        self.btnDone.Enable(0)

        infosizer.Add(self.sttWord, 0, wx.ALL|wx.ALIGN_TOP|wx.ALIGN_LEFT, 5)
        infosizer.Add(self.sttReading, 0, wx.ALL|wx.ALIGN_LEFT, 5)
        infosizer.AddStretchSpacer()
        infosizer.Add(sttMeaningLabel, 0, wx.LEFT|wx.ALIGN_LEFT, 5)
        infosizer.Add(self.txtMeaning, 0, wx.EXPAND|wx.RIGHT, 5)
        infosizer.AddStretchSpacer()
        infosizer.Add(self.btnDone, 0, wx.ALIGN_RIGHT|wx.RIGHT, 5)

        hsizer.Add(arrowsizer, 4, wx.ALL|wx.EXPAND|wx.ALIGN_CENTER_VERTICAL, 4)
        hsizer.Add(self.lstWords, 12, wx.ALL|wx.EXPAND|wx.ALIGN_CENTER, 5)
        hsizer.AddStretchSpacer()
        hsizer.Add(infosizer, 16, wx.ALL|wx.EXPAND|wx.ALIGN_CENTER, 5)

        self.SetSizer(hsizer)
        self.Refresh()

    def StartSet(self):
        if len(self.GetParent().dictionary) >= 2:
            dlg = SpinCtrlDialog(self, 'How many words would you like to review?',
                                 'Range selection', min(10,len(self.GetParent().dictionary)),
                                 2, len(self.GetParent().dictionary))

            if dlg.ShowModal() == wx.ID_OK:
                typedlg = ReviewTypeDialog(self)
                typedlg.ShowModal()
                sets = typedlg.GetValue()
                self.auto_order = sets[0]
                self.score_order = sets[1]
                self.show_reading = sets[2]
                self.score_meaning = sets[3]
                
                word_jar = self.GetParent().dictionary[:]
                words = []
                for i in xrange(0, dlg.GetValue()):
                    words.append(word_jar.pop(random.randint(0, len(word_jar)-1)))
                
                if self.auto_order:
                    words = order_alpha(words)

                self.NewWords(words)

                self.btnDone.Enable(1)

            dlg.Destroy()

        else:
            dlg = wx.MessageDialog(self, 'A dictionary is not loaded, or the dictionary that was loaded is too short (a dictionary must have at least 2 words to be valid). Would you like to load a dictionary now?',
                                   'Error', wx.YES_NO|wx.ICON_ERROR)
            if dlg.ShowModal() == wx.ID_YES:
                retry = self.GetParent().LoadDict()
                if retry:
                    self.StartSet()
                
            dlg.Destroy()

    def NewWords(self, words):
        self.words = words
        self.meanings = []
        self.lstWords.Set([])

        for i in self.words:
            self.meanings.append(u'')
            self.lstWords.Append(i['word'])

    def OnShiftUp(self, event):
        if self.selection > 0:
            # Maintain correct selection (for gtk2)
            newselection = self.selection - 1

            self.words.insert(self.selection-1, self.words.pop(self.selection))
            self.meanings.insert(self.selection-1, self.meanings.pop(self.selection))

            items = self.lstWords.GetItems()
            items.insert(self.selection-1, items.pop(self.selection))

            self.lstWords.Set(items)
            self.lstWords.SetSelection(newselection)
            self.selection = newselection

            # Restore widgets (for gtk2)
            curword = self.words[self.selection]
            self.sttWord.SetLabel(curword['word'])

            if self.show_reading \
               and curword['word'] != curword['reading']:
                self.sttReading.SetLabel(curword['reading'])
            else:
                self.sttReading.SetLabel(u'')

            self.txtMeaning.ChangeValue(self.meanings[self.selection])

            if self.score_order:
                self.btnShiftUp.Enable(1)
                self.btnShiftDown.Enable(1)

            if self.score_meaning:
                self.txtMeaning.Enable(1)

    def OnShiftDown(self, event):
        if self.selection < len(self.words)-1:
            # Maintain correct selection (for gtk2)
            newselection = self.selection + 1

            self.words.insert(self.selection+1, self.words.pop(self.selection))
            self.meanings.insert(self.selection+1, self.meanings.pop(self.selection))

            items = self.lstWords.GetItems()
            items.insert(self.selection+1, items.pop(self.selection))

            self.lstWords.Set(items)
            self.lstWords.SetSelection(newselection)
            self.selection = newselection

            # Restore widgets (for gtk2)
            curword = self.words[self.selection]
            self.sttWord.SetLabel(curword['word'])

            if self.show_reading \
               and curword['word'] != curword['reading']:
                self.sttReading.SetLabel(curword['reading'])
            else:
                self.sttReading.SetLabel(u'')

            self.txtMeaning.ChangeValue(self.meanings[self.selection])

            if self.score_order:
                self.btnShiftUp.Enable(1)
                self.btnShiftDown.Enable(1)

            if self.score_meaning:
                self.txtMeaning.Enable(1)

    def OnSelectWord(self, event):
        self.selection = event.GetSelection()

        if self.selection != -1:
            curword = self.words[self.selection]
            self.sttWord.SetLabel(curword['word'])

            if self.show_reading \
               and curword['word'] != curword['reading']:
                self.sttReading.SetLabel(curword['reading'])
            else:
                self.sttReading.SetLabel(u'')

            self.txtMeaning.ChangeValue(self.meanings[self.selection])

            if self.score_order:
                self.btnShiftUp.Enable(1)
                self.btnShiftDown.Enable(1)

            if self.score_meaning:
                self.txtMeaning.Enable(1)

        else:
            self.sttWord.SetLabel(u'')
            self.sttReading.SetLabel(u'')
            self.txtMeaning.ChangeValue(u'')

            self.btnShiftUp.Enable(0)
            self.btnShiftDown.Enable(0)
            self.txtMeaning.Enable(0)

    def OnChangeReadingText(self, event):
        self.readings[self.selection] = event.GetString()

    def OnChangeMeaningText(self, event):
        self.meanings[self.selection] = event.GetString()

    def OnDone(self, event):
        score = 0
        maxscore = 0
        
        if self.score_meaning:
            maxscore += len(self.words)

        if self.score_order:
            maxscore += len(self.words) - 1

        orderstatus = [1]*len(self.words)
        meaningstatus = [1]*len(self.words)

        correct_order = order_alpha(self.words[:])

        if self.score_order:
            if self.words == correct_order:
                score += len(self.words) - 1
            else:
                #Figure out score attained from order or words
                for word in xrange(0, len(self.words)):
                    for cword in xrange(0, len(correct_order)):
                        if self.words[word] == correct_order[cword]:
                            # Find out what he next/last words are
                            lastword = None
                            nextword = None
                            lastcword = None
                            nextcword = None
        
                            if word > 0:
                                lastword = self.words[word-1]
                            if word < len(self.words) - 1:
                                nextword = self.words[word+1]
                            if cword > 0:
                                lastcword = correct_order[cword-1]
                            if cword < len(correct_order) - 1:
                                nextcword = correct_order[cword+1]

                            # Add score to total
                            addscore = 0
                            if lastword == lastcword and lastword != None:
                                addscore += 0.5
                            if nextword == nextcword and nextword != None:
                                addscore += 0.5
                            score += addscore

                            if word != cword:
                                if addscore > 0:
                                    orderstatus[word] = 0.5
                                else:
                                    orderstatus[word] = 0

        if self.score_meaning:
            for i in xrange(0, len(self.words)):
                correct = 0
                for meaning in self.words[i]['meanings']:
                    m_entered = self.meanings[i].lower().strip(unicode('.!?,;:。！？、', 'utf_8'))
                    m_correct = meaning.lower().strip(unicode('.!?,;:。！？、', 'utf_8'))
                    if m_entered == m_correct:
                        correct = 1
                        break
                if not correct:
                    for meaning in self.words[i]['alt_meanings']:
                        m_entered = self.meanings[i].lower().strip(unicode('.!?,;:。！？、', 'utf_8'))
                        m_correct = meaning.lower().strip(unicode('.!?,;:。！？、', 'utf_8'))
                        if m_entered == m_correct:
                            correct = 1
                            break

                if correct:
                    score += 1
                else:
                    meaningstatus[i] = 0
        
        score = int(score)

        percentage = int((score/maxscore) * 100)

        if percentage <= 40:
            exclamation = u''
            endmark = unicode('.', 'utf_8')
        elif percentage <= 70:
            exclamation = u'Not bad! '
            endmark = unicode('.', 'utf_8')
        elif percentage <= 90:
            exclamation = u"You're doing great! "
            endmark = u'!'
        else:
            exclamation = u'Excellent work! '
            endmark = unicode('! あなたは日本語の名人ですよ。', 'utf_8')

        dlg = wx.MessageDialog(self, u'{0}You scored {1} / {2} points ({3}%){4}'.format(exclamation,score,maxscore,percentage,endmark),
                               'Your Score', wx.OK)
        dlg.ShowModal()
        dlg.Destroy()

        if self.score_order:
            dlg = WordOrderDialog(self, self.words, correct_order, orderstatus)
            dlg.ShowModal()
            dlg.Destroy()

        if self.score_meaning:
            dlg = WordMeaningDialog(self, self.meanings, self.words, meaningstatus)
            dlg.ShowModal()
            dlg.Destroy()

        self.words = []
        self.selection = -1
        meanings = []
        self.lstWords.Set([])
        self.txtMeaning.ChangeValue(u'')
        self.sttWord.SetLabel(u'')
        self.sttReading.SetLabel(u'')

        self.btnDone.Enable(0)
        self.btnShiftUp.Enable(0)
        self.btnShiftDown.Enable(0)
        self.txtMeaning.Enable(0)

class WordOrderDialog(wx.Dialog):
    def __init__(self, parent, entered_words, correct_words, status):
        wx.Dialog.__init__(self, parent, -1, 'Stats: Word Order', size=(480,280))

        panel = wx.ScrolledWindow(self, -1, style=wx.VSCROLL)
        panel.SetScrollbars(1,1,1,1)

        vsizer = wx.BoxSizer(wx.VERTICAL)

        szrPanel = wx.BoxSizer(wx.VERTICAL)
        szrButtons = self.CreateButtonSizer(wx.OK)
        
        grid = wx.FlexGridSizer(-1, 2, 16, 16)

        fntHeader = wx.Font(14, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL,
                            wx.FONTWEIGHT_BOLD, True)
        fntWords = wx.Font(12, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL,
                           wx.FONTWEIGHT_NORMAL)
        
        sttYouSaid = wx.StaticText(panel, -1, 'You said:')
        sttCorrectAnswer = wx.StaticText(panel, -1, 'Correct answer:')
        sttYouSaid.SetFont(fntHeader)
        sttCorrectAnswer.SetFont(fntHeader)

        grid.Add(sttYouSaid, 1, wx.ALIGN_CENTER_HORIZONTAL)
        grid.Add(sttCorrectAnswer, 1, wx.ALIGN_CENTER_HORIZONTAL)

        for i in xrange(0, len(correct_words)):
            hsizer = wx.BoxSizer(wx.HORIZONTAL)

            sttEntered = wx.StaticText(panel, -1, entered_words[i]['word'])
            sttCorrect = wx.StaticText(panel, -1, correct_words[i]['word'])
            sttEntered.SetFont(fntWords)
            sttCorrect.SetFont(fntWords)

            if status[i] == 1:
                sttEntered.SetForegroundColour('green')
            elif status[i] == 0.5:
                sttEntered.SetForegroundColour('yellow')
            else:
                sttEntered.SetForegroundColour('red')

            grid.Add(sttEntered, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.TOP, 5)
            grid.Add(sttCorrect, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.TOP, 5)

        szrPanel.Add(grid, 0, wx.ALIGN_CENTER_HORIZONTAL)
        
        panel.SetSizer(szrPanel)
        panel.Refresh()

        vsizer.Add(panel, 1, wx.EXPAND|wx.TOP|wx.LEFT|wx.RIGHT, 6)
        vsizer.Add(wx.StaticLine(self, style=wx.LI_HORIZONTAL), 0, wx.EXPAND|wx.ALL, 6)
        vsizer.Add(szrButtons, 0, wx.EXPAND|wx.BOTTOM|wx.LEFT|wx.RIGHT, 6)

        self.SetSizer(vsizer)
        self.Layout()
        self.Centre()

class WordMeaningDialog(wx.Dialog):
    #Needs to be adjusted further
    def __init__(self, parent, entered_meanings, words, status):
        wx.Dialog.__init__(self, parent, -1, 'Stats: Word Meanings', size=(520,300))

        panel = wx.ScrolledWindow(self, -1, style=wx.VSCROLL)
        panel.SetScrollbars(1,1,1,1)

        vsizer = wx.BoxSizer(wx.VERTICAL)

        szrPanel = wx.BoxSizer(wx.VERTICAL)
        szrButtons = self.CreateButtonSizer(wx.OK)
        
        grid = wx.FlexGridSizer(-1, 3, 16, 16)

        fntHeader = wx.Font(14, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL,
                            wx.FONTWEIGHT_BOLD, True)
        fntWords = wx.Font(12, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL,
                           wx.FONTWEIGHT_NORMAL)
        
        sttWord = wx.StaticText(panel, -1, 'Word:')
        sttYouSaid = wx.StaticText(panel, -1, 'You said:')
        sttCorrectAnswer = wx.StaticText(panel, -1, 'Correct answer:')
        sttWord.SetFont(fntHeader)
        sttYouSaid.SetFont(fntHeader)
        sttCorrectAnswer.SetFont(fntHeader)

        grid.Add(sttWord, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_TOP)
        grid.Add(sttYouSaid, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_TOP)
        grid.Add(sttCorrectAnswer, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_TOP)

        for i in xrange(0, len(words)):
            hsizer = wx.BoxSizer(wx.HORIZONTAL)

            sttWord = wx.StaticText(panel, -1, words[i]['word'])
            sttEntered = wx.StaticText(panel, -1, entered_meanings[i])

            n_meanings = len(words[i]['meanings'])
                
            if n_meanings == 1:
                meanings = words[i]['meanings'][0]
            else:
                meanings = u''
                for m in xrange(0, n_meanings-1):
                    meanings += u'{0}; '.format(words[i]['meanings'][m])
                meanings += words[i]['meanings'][-1]

            sttCorrect = wx.StaticText(panel, -1, meanings, style=wx.ALIGN_CENTRE)
            sttCorrect.Wrap(180)
            
            sttWord.SetFont(fntWords)
            sttEntered.SetFont(fntWords)
            sttCorrect.SetFont(fntWords)

            if status[i] == 1:
                sttEntered.SetForegroundColour('green')
            elif status[i] == 0.5:
                sttEntered.SetForegroundColour('yellow')
            else:
                sttEntered.SetForegroundColour('red')

            grid.Add(sttWord, 0, wx.ALIGN_CENTER|wx.TOP, 5)
            grid.Add(sttEntered, 0, wx.ALIGN_CENTER|wx.TOP, 5)
            grid.Add(sttCorrect, 0, wx.ALIGN_CENTER|wx.TOP, 5)

        szrPanel.Add(grid, 0, wx.ALIGN_CENTER_HORIZONTAL)
        
        panel.SetSizer(szrPanel)
        panel.Refresh()

        vsizer.Add(panel, 1, wx.EXPAND|wx.TOP|wx.LEFT|wx.RIGHT, 6)
        vsizer.Add(wx.StaticLine(self, style=wx.LI_HORIZONTAL), 0, wx.EXPAND|wx.ALL, 6)
        vsizer.Add(szrButtons, 0, wx.EXPAND|wx.BOTTOM|wx.LEFT|wx.RIGHT, 6)

        self.SetSizer(vsizer)
        self.Layout()
        self.Centre()

class SpinCtrlDialog(wx.Dialog):
    def __init__(self, parent, text, title, value, min_v=0, max_v=100):
        wx.Dialog.__init__(self, parent, -1, title, size=(400,150))

        vsizer = wx.BoxSizer(wx.VERTICAL)

        label = wx.StaticText(self, -1, text)
        self.spin = wx.SpinCtrl(self, -1, str(value), style=wx.SP_ARROW_KEYS,
                                min=min_v, max=max_v, initial=value)
        line = wx.StaticLine(self, style=wx.LI_HORIZONTAL)
        buttons = self.CreateButtonSizer(wx.OK|wx.CANCEL)

        vsizer.Add(label, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.TOP, 6)
        vsizer.AddStretchSpacer()
        vsizer.Add(self.spin, 0, wx.ALIGN_CENTER_HORIZONTAL)
        vsizer.AddStretchSpacer()
        vsizer.Add(line, 0, wx.EXPAND|wx.LEFT|wx.RIGHT, 4)
        vsizer.AddStretchSpacer()
        vsizer.Add(buttons, 0, wx.EXPAND|wx.LEFT|wx.RIGHT|wx.BOTTOM, 6)

        self.SetSizer(vsizer)
        self.Layout()
        self.Centre()

    def GetValue(self):
        return self.spin.GetValue()

class ReviewTypeDialog(wx.Dialog):
    def __init__(self, parent):
        wx.Dialog.__init__(self, parent, -1, 'Review Type', size=(400,200))

        vsizer = wx.BoxSizer(wx.VERTICAL)

        self.chkAutoSort = wx.CheckBox(self, -1, 'Sort words automatically')
        self.chkScoreAlpha = wx.CheckBox(self, -1, 'Score for word order')
        self.chkShowReading = wx.CheckBox(self, -1, 'Show readings for words with kanji')
        self.chkScoreMeaning = wx.CheckBox(self, -1, 'Score for English meaning')
        self.Bind(wx.EVT_CHECKBOX, self.OnAutoSort, self.chkAutoSort)
        self.Bind(wx.EVT_CHECKBOX, self.OnScoreAlpha, self.chkScoreAlpha)
        self.Bind(wx.EVT_CHECKBOX, self.OnScoreMeaning, self.chkScoreMeaning)

        self.chkAutoSort.SetValue(0)
        self.chkScoreAlpha.SetValue(0)
        self.chkShowReading.SetValue(1)
        self.chkScoreMeaning.SetValue(1)

        line = wx.StaticLine(self, style=wx.LI_HORIZONTAL)
        buttons = self.CreateButtonSizer(wx.OK)

        vsizer.AddStretchSpacer()
        vsizer.Add(self.chkAutoSort, 0, wx.ALIGN_LEFT|wx.LEFT, 16)
        vsizer.AddStretchSpacer()
        vsizer.Add(self.chkScoreAlpha, 0, wx.ALIGN_LEFT|wx.LEFT, 16)
        vsizer.AddStretchSpacer()
        vsizer.Add(self.chkShowReading, 0, wx.ALIGN_LEFT|wx.LEFT, 16)
        vsizer.AddStretchSpacer()
        vsizer.Add(self.chkScoreMeaning, 0, wx.ALIGN_LEFT|wx.LEFT, 16)
        vsizer.AddStretchSpacer()
        vsizer.Add(line, 0, wx.EXPAND|wx.LEFT|wx.RIGHT, 4)
        vsizer.AddStretchSpacer()
        vsizer.Add(buttons, 0, wx.EXPAND|wx.LEFT|wx.RIGHT|wx.BOTTOM, 6)

        self.SetSizer(vsizer)
        self.Layout()
        self.Centre()

    def OnAutoSort(self, event):
        if event.IsChecked():
            self.chkScoreAlpha.Enable(0)
            self.chkScoreMeaning.SetValue(1)
        else:
            self.chkScoreAlpha.Enable(1)

    def OnScoreAlpha(self, event):
        if not event.IsChecked():
            self.chkScoreMeaning.SetValue(1)

    def OnScoreMeaning(self, event):
        if not event.IsChecked():
            if self.chkScoreAlpha.IsEnabled():
                self.chkScoreAlpha.SetValue(1)
            else:
                self.chkScoreMeaning.SetValue(1)

    def GetValue(self):
        return [self.chkAutoSort.GetValue(),
                self.chkScoreAlpha.GetValue() and self.chkScoreAlpha.IsEnabled(),
                self.chkShowReading.GetValue(),
                self.chkScoreMeaning.GetValue()]

if __name__ == '__main__':
    app = wx.PySimpleApp()
    frame = Frame(None, wx.ID_ANY)
    app.MainLoop()
