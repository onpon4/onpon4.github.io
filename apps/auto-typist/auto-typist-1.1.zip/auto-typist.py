#!/usr/bin/env python

# Auto Typist
# Copyright 2012 Julian Marchant <onpon4@lavabit.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""Auto Typist
Usage: auto-typist.py [CONFIG]

CONFIG is optional and specifies a different config file to use than
config.json.

"""

from __future__ import division
from __future__ import absolute_import
from __future__ import print_function
from __future__ import unicode_literals

__version__ = "1.1"

import sys
import os
import random
import json
import warnings

import pygame
from pygame.locals import *

SCREENRECT = Rect(0, 0, 640, 480)
TEXTRECT = Rect(0, 16, 640, 464)
FPS_MAX = 60
TYPING_SPEED = 1000
SENTENCE_BREAK = 300
PARAGRAPH_BREAK = 150
BACKGROUND = 'tutorial.png'
BACKGROUND_COLOR = (255, 255, 255)
FONT = None
FONT_SIZE = 24
TEXT_COLOR = (0, 0, 0)
TEXT_ALIGN = 'left'
INPUT_FILE = 'tutorial.txt'
INPUT_TEXT = "Oops, I can't open the file I'm supposed to read!"
RANDOM_SEED = None


class glob(object):

    """Container for "global" variables."""

    # Resources
    background = None
    font = None
    typing_sounds = []

    # Objects
    all_sprites = None
    text_sprite = None
    text_remaining = None

    # Clock
    clock = None

    # Settings
    screenrect = SCREENRECT.copy()
    textrect = TEXTRECT.copy()
    fps_max = FPS_MAX
    typing_speed = TYPING_SPEED
    sentence_break = SENTENCE_BREAK
    paragraph_break = PARAGRAPH_BREAK
    background_name = BACKGROUND
    background_color = BACKGROUND_COLOR
    font_name = FONT
    font_size = FONT_SIZE
    text_color = TEXT_COLOR
    text_align = TEXT_ALIGN
    input_file = INPUT_FILE
    input_text = INPUT_TEXT
    random_seed = RANDOM_SEED

    # Display
    window = None

    # Program state
    running = False


class TextSprite(pygame.sprite.Sprite):

    """Sprite class which stores and displays the current text."""

    @property
    def text(self):
        return self._text

    @text.setter
    def text(self, value):
        self._text_changed = True
        self._text = value

    def __init__(self, *groups):
        pygame.sprite.Sprite.__init__(self, *groups)

        self.rect = glob.textrect.copy()
        self.image = pygame.Surface(self.rect.size, SRCALPHA)
        self.image.fill(pygame.Color(0, 0, 0, 0))
        self.text = ''
        self._text_changed = False

    def update(self):
        """Adjust the text display if the text has changed."""
        if self._text_changed:
            self._text_changed = False
            self.image.fill(pygame.Color(0, 0, 0, 0))
            lines = self.text.split('\n')
            new_lines = []

            # Split lines that are too long
            for line in lines:
                words = line.split(' ')
                next_line = words[0]
                for i in xrange(1, len(words)):
                    t = ' '.join((next_line, words[i]))
                    if glob.font.size(t)[0] <= glob.textrect.w:
                        next_line = t
                    else:
                        new_lines.append(next_line)
                        next_line = words[i]

                new_lines.append(next_line)

            # Delete lines that cannot fit
            line_height = glob.font.get_linesize()
            screen_height = max(line_height, glob.textrect.h)
            while len(new_lines) * line_height > screen_height:
                del new_lines[0]

            # Update string
            lines = new_lines
            self.text = '\n'.join(lines)

            line_number = 0

            for line in lines:
                self._print_text(line, line_number)
                line_number += 1

    def _print_text(self, text, line):
        # Print ``text`` at ``line``, where 0 is the first line.
        rendered_text = glob.font.render(text, True, glob.text_color)
        rect = rendered_text.get_rect()

        if glob.text_align == 'center':
            rect.centerx = glob.textrect.centerx
        elif glob.text_align == 'right':
            rect.right = glob.textrect.right
        else: # 'left'
            rect.left = glob.textrect.left

        rect.top = glob.textrect.top + glob.font.get_linesize() * line

        self.image.blit(rendered_text, rect)


def load_config(fname='config.json'):
    """Load the specified JSON config file."""
    fix_config = False
    try:
        with open(fname, 'r') as f:
            config = json.load(f)
    except (IOError, ValueError):
        config = {}
        fix_config = True

    config.setdefault('screen_w', SCREENRECT.w)
    config.setdefault('screen_h', SCREENRECT.h)
    config.setdefault('text_x', TEXTRECT.left)
    config.setdefault('text_y', TEXTRECT.top)
    config.setdefault('text_w', TEXTRECT.w)
    config.setdefault('text_h', TEXTRECT.h)
    config.setdefault('fps', FPS_MAX)
    config.setdefault('typing_speed', TYPING_SPEED)
    config.setdefault('sentence_break', SENTENCE_BREAK)
    config.setdefault('paragraph_break', PARAGRAPH_BREAK)
    config.setdefault('background', BACKGROUND)
    config.setdefault('background_color', BACKGROUND_COLOR)
    config.setdefault('font', FONT)
    config.setdefault('font_size', FONT_SIZE)
    config.setdefault('text_color', TEXT_COLOR)
    config.setdefault('text_align', TEXT_ALIGN)
    config.setdefault('input_file', INPUT_FILE)
    config.setdefault('input_text', INPUT_TEXT)
    config.setdefault('random_seed', RANDOM_SEED)

    if fix_config:
        with open(fname, 'w') as f:
            json.dump(config, f, sort_keys=True, indent=4)

    numeric_settings = {'screen_w':SCREENRECT.w, 'screen_h':SCREENRECT.h,
                        'text_x':TEXTRECT.left, 'text_y':TEXTRECT.top,
                        'text_w':TEXTRECT.w, 'text_h':TEXTRECT.h,
                        'fps':FPS_MAX, 'typing_speed':TYPING_SPEED,
                        'sentence_break':SENTENCE_BREAK, 'font_size':FONT_SIZE,
                        'paragraph_break':PARAGRAPH_BREAK}
    for s in numeric_settings.keys():
        try:
            config[s] = float(config[s])
        except ValueError:
            warnings.warn(
                'Value given for {0} is invalid. It should be a number'.format(s))
            config[s] = numeric_settings[s]

    glob.screenrect = Rect(0, 0, config['screen_w'], config['screen_h'])
    glob.textrect = Rect(config['text_x'], config['text_y'], config['text_w'],
                         config['text_h'])
    glob.fps_max = config['fps']
    glob.typing_speed = config['typing_speed']
    glob.sentence_break = config['sentence_break']
    glob.paragraph_break = config['paragraph_break']
    glob.background_name = config['background']
    glob.background_color = config['background_color']
    glob.font_name = config['font']
    glob.font_size = int(config['font_size'])
    glob.text_color = config['text_color']
    glob.text_align = config['text_align']
    glob.input_file = config['input_file']
    glob.input_text = config['input_text']
    glob.random_seed = config['random_seed']


def init():
    """Initialize the program."""
    pygame.mixer.pre_init(22050, -16, 2, 2048)
    pygame.init()
    random.seed(glob.random_seed)
    pygame.display.set_caption("Auto Typist")
    glob.window = pygame.display.set_mode(glob.screenrect.size)
    glob.clock = pygame.time.Clock()
    pygame.mixer.set_num_channels(max(2, int(glob.typing_speed / 60)))

    # Icon
    try:
        icon = pygame.image.load("icon.png")
        pygame.display.set_icon(icon)
    except pygame.error:
        pass

    # Background
    glob.background = pygame.Surface(glob.screenrect.size)
    glob.background.fill(glob.background_color)
    if glob.background_name:
        try:
            fname = os.path.join('data', 'backgrounds', glob.background_name)
            loaded_background = pygame.image.load(fname).convert()
            glob.background.blit(loaded_background, (0, 0))
        except pygame.error:
            pass

    # Font
    if pygame.font.get_init():
        if glob.font_name:
            try:
                fname = os.path.join('data', 'fonts', glob.font_name)
                glob.font = pygame.font.Font(fname, glob.font_size)
            except IOError:
                glob.font = pygame.font.SysFont(glob.font_name, glob.font_size)
        else:
            glob.font = pygame.font.SysFont('', glob.font_size)
    else:
        print("Error: font module is unavailable. Either the font module")
        print("itself is not included in this installation of Pygame or")
        print("SDL_ttf is missing. Please correct this problem and try again.")
        raise Exception("Font support unavailable.")

    # Text
    try:
        with open(glob.input_file, 'r') as f:
            text = f.read()
    except IOError:
        text = glob.input_text
    glob.text_remaining = list(text.replace('\t', ' ' * 8))

    # Sounds
    glob.typing_sounds = []
    for fname in os.listdir(os.path.join('data', 'sounds')):
        try:
            snd = pygame.mixer.Sound(os.path.join('data', 'sounds', fname))
            glob.typing_sounds.append(snd)
        except pygame.error:
            pass

    glob.all_sprites = pygame.sprite.RenderUpdates()
    glob.text_sprite = TextSprite(glob.all_sprites)


def main(*args):
    if len(args) > 1:
        load_config(args[1])
    else:
        load_config()

    init()

    playing = False
    time_passed = 0
    delay_next = 0
    typing_interval = 1 / (glob.typing_speed / 60000)
    glob.running = True
    glob.window.blit(glob.background, (0, 0))
    pygame.display.update()
    glob.clock.tick()
    
    while glob.running:
        # Events
        for event in pygame.event.get():
            if (event.type == QUIT or
                    event.type == KEYDOWN and event.key == K_ESCAPE):
                glob.running = False
                glob.background = pygame.Surface(glob.screenrect.size)
                glob.text_sprite.text = ''
                glob.text_remaining = []
                pygame.display.set_caption("Exiting Auto Typist...")
                glob.window.blit(glob.background, (0, 0))
                pygame.display.update()
            elif event.type == KEYDOWN:
                if event.key == K_RETURN:
                    playing = not playing

        if playing and glob.text_remaining:
            time_passed += glob.clock.tick(glob.fps_max)

            while glob.text_remaining and time_passed >= delay_next:
                time_passed -= delay_next
                thischar = glob.text_remaining[0]

                if len(glob.text_remaining) > 1:
                    nextchar = glob.text_remaining[1]
                else:
                    nextchar = ' '

                if thischar in ('.', '?', '!') and nextchar in (' ', '\n'):
                    delay_next = glob.sentence_break
                elif thischar == '\n' and nextchar == '\n':
                    delay_next = glob.paragraph_break
                elif thischar == ' ' and nextchar == ' ':
                    delay_next = 0
                else:
                    delay_next = typing_interval

                glob.text_sprite.text += glob.text_remaining.pop(0)

                if not thischar in (' ', '\n'):
                    if glob.typing_sounds:
                        s = random.randrange(len(glob.typing_sounds))
                        glob.typing_sounds[s].play(0, 750)
        else:
            glob.clock.tick(glob.fps_max)

        glob.all_sprites.clear(glob.window, glob.background)
        glob.all_sprites.update()
        dirty = glob.all_sprites.draw(glob.window)
        pygame.display.update(dirty)

    pygame.quit()


if __name__ == '__main__':
    sys.exit(main(*sys.argv))

