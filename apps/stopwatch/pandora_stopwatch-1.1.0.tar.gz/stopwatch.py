#!/usr/bin/env python

# Pandora Stopwatch
# Copyright 2012 Julian Marchant <onpon4@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""A simple graphical stopwatch program.
Usage: stopwatch.py [options]

Options:
  -a, --accurate               Run in "accurate" mode, which is more
                                 precise, but uses more CPU time.
  -f FPS, --fps=FPS            Run at frame rate FPS instead of the
                                 default 120 frames per second.  Has no
                                 effect if --accurate is given.
  -h, --help                   Show this help text.
  -o FILE, --output=FILE       Set the file to write the records to.

When the program is finished, it will write recorded times to the plain
text file, records.out, unless a different file is specified with -o.

See README for stopwatch controls.

"""

from __future__ import division
from __future__ import absolute_import
from __future__ import print_function
from __future__ import unicode_literals

__version__ = "1.1.0"

import sys

import pygame
from pygame.locals import *

SCREENRECT = Rect(0, 0, 320, 240)
FPS_MAX = 120
KEYS_TOGGLE = (K_LALT, K_RALT, K_RETURN)
KEYS_COUNT = (K_HOME, K_END, K_UP)
KEYS_RECORD = (K_LSHIFT, K_RSHIFT, K_SPACE, K_PAGEUP, K_PAGEDOWN)
KEYS_RESET = (K_r, K_LCTRL, K_RCTRL)


def format_number(n):
    """Format the number as a string which always has 2 digits."""
    s = str(int(n))

    if len(s) > 2:
        s = '99'
    else:
        while len(s) < 2:
            s = ''.join(('0', s))

    return s


def format_time(t):
    """Return a string representing the given time like a clock.

    Take ``t`` (in milliseconds) and use it to generate a string in
    the form "HH:MM:SS.CC", where HH is the number of hours (max 99), MM
    is the number of minutes, SS is the number of seconds, and CC is the
    number of "centiseconds" (hundredths of a second).

    """
    # Divide by 10 first to start with centiseconds
    t //= 10
    centiseconds = t % 100
    t //= 100
    seconds = t % 60
    t //= 60
    minutes = t % 60
    t //= 60
    hours = min(t, 99)

    hours_string = format_number(hours)
    minutes_string = format_number(minutes)
    seconds_string = format_number(seconds)
    centiseconds_string = format_number(centiseconds)

    return '{0}:{1}:{2}.{3}'.format(hours_string, minutes_string,
                                    seconds_string, centiseconds_string)


def main(*args):
    will_start = True
    accurate = False
    fps_max = FPS_MAX
    output_file = 'records.out'
    for i in xrange(len(args)):
        if args[i] == '-a' or args[i] == '--accurate':
            accurate = True
        elif args[i] == '-f':
            if len(args) > i + 1:
                try:
                    fps_max = float(args[i + 1])
                except ValueError:
                    print('Value for FPS is invalid.')
        elif args[i].startswith('--fps='):
            try:
                fps_max = float(args[i].split('=', 1)[1])
            except ValueError:
                print('Value for FPS is invalid.')
        elif args[i] == '-h' or args[i] == '--help':
            print(__doc__.strip())
            will_start = False
        elif args[i] == '-o':
            if len(args) > i + 1:
                output_file = args[i + 1]
        elif args[i].startswith('--output='):
            output_file = args[i].split('=', 1)[1]

    if not will_start:
        return

    pygame.init()

    try:
        icon = pygame.image.load("icon.png")
        pygame.display.set_icon(icon)
    except pygame.error:
        pass

    window = pygame.display.set_mode(SCREENRECT.size)
    background = pygame.Surface(SCREENRECT.size)
    background.fill((0, 0, 0))
    pygame.display.set_caption("Pandora Stopwatch")

    clock = pygame.time.Clock()

    stopwatch_font = pygame.font.SysFont('Liberation Mono,Courier', 48)
    recorded_times_font = pygame.font.SysFont('Liberation Mono,Courier', 16)

    stopwatch_time = 0
    stopwatch_counting = False
    stopwatch_changed = True
    stopwatch_surface = stopwatch_font.render(
        format_time(0), True, (255, 255, 255))
    stopwatch_rect = stopwatch_surface.get_rect(centerx=SCREENRECT.centerx)

    recorded_times = []
    records_changed = False
    records_surface = pygame.Surface((1, 1))
    records_rect = records_surface.get_rect(centerx=SCREENRECT.centerx,
                                            bottom=SCREENRECT.bottom)

    running = True
    dirty = [SCREENRECT]
    clock.tick()

    while running:
        # Events
        for event in pygame.event.get():
            if (event.type == QUIT or
                    (event.type == KEYDOWN and event.key == K_ESCAPE)):
                running = False

            elif event.type == KEYDOWN:
                if event.key in KEYS_TOGGLE:
                    stopwatch_counting = not stopwatch_counting
                    stopwatch_changed = True

                    if not stopwatch_counting:
                        recorded_times.append(stopwatch_time)
                        records_changed = True

                elif event.key in KEYS_COUNT:
                    stopwatch_counting = not stopwatch_counting
                    stopwatch_changed = True

                    if not stopwatch_counting:
                        recorded_times.append(stopwatch_time)
                        records_changed = True

                elif event.key in KEYS_RECORD:
                    recorded_times.append(stopwatch_time)
                    records_changed = True

                elif event.key in KEYS_RESET:
                    stopwatch_time = 0
                    stopwatch_counting = False
                    stopwatch_changed = True

            elif event.type == KEYUP:
                if event.key in KEYS_COUNT:
                    stopwatch_counting = not stopwatch_counting
                    stopwatch_changed = True

                    if not stopwatch_counting:
                        recorded_times.append(stopwatch_time)
                        records_changed = True

        if accurate:
            # If --accurate is used, use a busy loop. Since it isn't
            # sleeping, there's no point in limiting the frame rate.
            time_passed = clock.tick_busy_loop()
        else:
            time_passed = clock.tick(fps_max)

        if stopwatch_counting:
            stopwatch_time += time_passed
            stopwatch_changed = True

        if stopwatch_changed:
            stopwatch_surface = stopwatch_font.render(
                format_time(stopwatch_time), True, (255, 255, 255))
            stopwatch_rect = stopwatch_surface.get_rect(
                centerx=SCREENRECT.centerx, top=SCREENRECT.top)
            dirty.append(stopwatch_rect)
            stopwatch_changed = False

        if records_changed:
            time_surfaces = []
            w = 1
            for t in recorded_times[-8:]:
                surface = recorded_times_font.render(
                    format_time(t), True, (255, 255, 255))
                time_surfaces.append(surface)
                w = max(surface.get_width(), w)
            
            line_h = recorded_times_font.get_linesize()
            h = line_h * len(time_surfaces)

            records_surface = pygame.Surface((w, h), SRCALPHA)
            for i in xrange(len(time_surfaces)):
                records_surface.blit(time_surfaces[i], (0, line_h * i))
            
            records_rect = records_surface.get_rect(
                centerx=SCREENRECT.centerx, bottom=SCREENRECT.bottom)
            dirty.append(records_rect)
            records_changed = False

        window.blit(background, SCREENRECT)
        window.blit(stopwatch_surface, stopwatch_rect)
        window.blit(records_surface, records_rect)
        
        pygame.display.update(dirty)
        dirty = []

    # Write log
    if recorded_times:
        with open(output_file, 'w') as f:
            for t in recorded_times:
                s = format_time(t) + '\n'
                f.write(s)


if __name__ == '__main__':
    sys.exit(main(*sys.argv))
