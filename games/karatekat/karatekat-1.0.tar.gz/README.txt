This is a short game I made as a little "secret santa" gift for someone in December 2013. There are three levels of progressing difficulty. To win, simply beat all of the enemies in the level.

This game was made with ENIGMA. You can get it here:

http://enigma-dev.org

I was only able to compile it for GNU/Linux x86-64 systems, so if you
don't have a GNU/Linux system, you'll need to compile it yourself with
ENIGMA. To do this, download ENIGMA following the instructions on the
ENIGMA website, and open LateralGM (which should come with ENIGMA). You
can either create a permanent executable with the "compile" button, or
play it instantly (technically, create a temporary executable and run it
immediately) with the "run" button.


CONTROLS
--------

Arrows to move, Space bar to jump, D to punch, S to kick.

There's no in-game way to change the controls, but you can change them
in the source by modifying a few variables in the Game Start event of
obj_controller.

There are a few different kinds of kicks you can do: hold the up or down
arrow while pressing Kick to do a high or low kick, and if you're
spin-jumping (double-jumping), you can do the spin kick by holding down
and pressing Kick.


LICENSE
-------

Except for sprites, backgrounds, sounds, and music, this game is under the following license:

    Copyright (C) 2013 Julian Marchant <onpon4@riseup.net>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.

The sprites in the "cat", "cutemonster", and "tonguemonster" folders are
by dogchicken <http://opengameart.org/users/dogchicken>. They are under
CC BY <https://creativecommons.org/licenses/by/4.0/>. The sprites in the
"cat" folder were also organized by Arsonide.

The sprites in the "masks" and "tiles" folders are by onpon4. They are
under CC0 <https://creativecommons.org/publicdomain/zero/1.0/>.

spr_lifebar is by Nushio <http://opengameart.org/users/nushio>. It is
under CC BY-SA <https://creativecommons.org/licenses/by-sa/4.0/>

bkg_tileset is by Kenney Vleugels <http://www.kenney.nl>. It is under
CC0 <https://creativecommons.org/publicdomain/zero/1.0/>.

snd_8_bit_ninja and snd_grey_sector are by FoxSynergy
<http://opengameart.org/users/foxsynergy>. They are under CC BY
<https://creativecommons.org/licenses/by/4.0/>.

snd_jump, snd_hurt, and snd_die were generated with sfxr by onpon4. They
are under CC0 <https://creativecommons.org/publicdomain/zero/1.0/>.
