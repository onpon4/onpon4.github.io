This folder contains everything you need to make a simple content mod
of SuperTux Milestone 1 (0.1.3). All you need to do is merge the
folders in this directory with the folders in the SuperTux data folder.
Where this folder is depends on your system, but on Windows it's the
folder called "data" under the installation directory, and on Debian
and its derivatives it's /usr/share/games/supertux.

This mod replaces most of the sounds with the versions from Milestone
1.9 and also replaces most of the outdated graphics with the new
versions. The only graphics which have changed in 0.3 that remain
unchanged here are the Mr Bomb graphics, since the new graphics are
much smaller than the old graphics and so changing to the new graphics
could mess up gameplay.

I avoided editing text files, but I had to edit one to include the new
coin graphics, since the old one just uses 3 frames while the new one
uses 8 frames.

For convenience, all Milestone 1 versions of the files remain with
"-old" appended to their names.

See LICENSES for license information. Most files are under the GNU GPL.
