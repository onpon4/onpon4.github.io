#!/usr/bin/python

# ITAD S.G. - Is This Another Dumb Space Game?
# Copyright 2012 Julian Marchant <onpon4@yahoo.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""Is this another dumb space game?

Yes, it is. This is a simple scrolling shooter, currently an early
alpha.

"""

from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
from __future__ import absolute_import

__version__ = "0.0.1"

import sys
import os
import math
import random
from random import random as rand
import json
import weakref
import warnings
import traceback

import pygame
from pygame.locals import *

BOUNDSRECT = Rect(0, 0, 1200, 720)

layer_names = ('stars', 'powerup', 'asteroid_small', None,
               'asteroid_medium', None, 'asteroid_large', None,
               'enemy_bullets', 'player_bullets', 'player_superbullets',
               'enemies', None, 'players', 'player_shields', 'display')
layers = {}
for i in xrange(len(layer_names)):
    if layer_names[i] is not None:
        layers[layer_names[i]] = i
    del i
del layer_names

loaded_images = {}
loaded_sounds = {}
mixer_channels = {}
music_selection = []
screen_xsize_factor = 1
screen_ysize_factor = 1
all_sprites = None
players = None
enemies = None


def main(*args):
    try:
        Game()
    finally:
        pygame.quit()


def load_images(dir_, transparent=True):
    """Load all images from ``dir`` and return failed recursions.

    Load all images from ``dir`` and store them in the global variable
    ``loaded_images``.  ``transparent`` indicates whether or not to
    convert the images for per-pixel alpha blitting.

    This function tries to recursively include directories within
    ``dir``. This cannot always succeed, so if recursion fails in a
    directory, that directory is added in a list which is returned when
    the function finishes. Therefore, you can ensure that all
    directories are reached by doing:

        unloaded_dirs = [mydir]
        while unloaded_dirs:
            unloaded_dirs.extend(load_images(unloaded_dirs[0]))
            del unloaded_dirs[0]

    """
    global loaded_images

    failed_dirs = []

    try:
        fnames = os.listdir(dir_)
    except OSError:
        fnames = []

    for fname in fnames:
        if os.path.isfile(os.path.join(dir_, fname)):
            root, ext = os.path.splitext(fname)

            end = root.split('-')[-1]
            if not end.isdigit():
                full_fname = os.path.join(dir_, fname)
                try:
                    img = pygame.image.load(full_fname)
                    if end.startswith('strip') and end[5:].isdigit():
                        root = root.rpartition('-')[0]
                        images = []
                        numframes = max(int(end[5:]), 1)
                        fullwidth = img.get_width()
                        w = fullwidth // numframes
                        h = img.get_height()
                        scaled_size = (int(w * screen_xsize_factor),
                                       int(h * screen_ysize_factor))

                        for x in xrange(0, fullwidth, w):
                            rect = Rect(x, 0, w, h)
                            subsurf = img.subsurface(rect)
                            frame = pygame.transform.smoothscale(subsurf,
                                                                 scaled_size)
                            if transparent:
                                images.append(frame.convert_alpha())
                            else:
                                images.append(frame.convert())

                        loaded_images[root] = images
                    else:
                        scaled_size = (
                            int(img.get_width() * screen_xsize_factor),
                            int(img.get_height() * screen_ysize_factor))
                        img = pygame.transform.smoothscale(img, scaled_size)

                        if transparent:
                            loaded_images[root] = [img.convert_alpha()]
                        else:
                            loaded_images[root] = [img.convert()]
                except pygame.error:
                    pass
            elif int(end) == 0:
                root = root.rpartition('-')[0]
                fname = ''.join((root, ext))

                full_fname = os.path.join(dir_, ''.join((root, '-0', ext)))
                num = 0
                imgs = []
                while os.path.exists(full_fname):
                    img = pygame.image.load(full_fname)
                    scaled_size = (int(img.get_width() * screen_xsize_factor),
                                   int(img.get_height() * screen_ysize_factor))
                    img = pygame.transform.smoothscale(img, scaled_size)
                    if transparent:
                        imgs.append(img.convert_alpha())
                    else:
                        imgs.append(img.convert())

                    num += 1
                    full_fname = os.path.join(
                            dir_, ''.join((root, '-', str(num), ext)))

                if len(imgs) > 0:
                    loaded_images[root] = imgs
        else:
            try:
                load_images(os.path.join(dir_, fname))
            except RuntimeError:
                d = os.path.join(dir_, fname)
                failed_dirs.append(d)
##                w = 'Recursion failed. Images in {0} were not loaded.'.format(
##                    os.path.normpath(os.path.realpath(d)))
##                warnings.warn(w)

    return failed_dirs


def load_sounds(dir_):
    """Load all sounds from ``dir`` and return failed recursions.

    Load all sounds from ``dir`` and store them in the global variable
    ``loaded_sounds``.

    This function tries to recursively include directories within
    ``dir``. This cannot always succeed, so if recursion fails in a
    directory, that directory is added in a list which is returned when
    the function finishes. Therefore, you can ensure that all
    directories are reached by doing:

        unloaded_dirs = [mydir]
        while unloaded_dirs:
            unloaded_dirs.extend(load_sounds(unloaded_dirs[0]))
            del unloaded_dirs[0]

    """
    global loaded_sounds

    failed_dirs = []

    if pygame.mixer.get_init():
        try:
            fnames = os.listdir(dir_)
        except OSError:
            fnames = []

        for fname in fnames:
            if os.path.isfile(os.path.join(dir_, fname)):
                root, ext = os.path.splitext(fname)
                full_fname = os.path.join(dir_, fname)

                try:
                    snd = pygame.mixer.Sound(full_fname)
                    loaded_sounds[root] = snd
                except pygame.error:
                    pass
            else:
                try:
                    load_sounds(os.path.join(dir_, fname))
                except RuntimeError:
                    d = os.path.join(dir_, fname)
                    failed_dirs.append(d)
##                    w = 'Recursion failed. Sounds in {0} were not loaded.'.format(
##                        os.path.normpath(os.path.realpath(d)))
##                    warnings.warn(w)

    return failed_dirs


def find_music(dir_):
    """Find and all music in ``dir`` and return failed recursions.

    Store the location of every music file in ``dir`` in the global
    variable ``music_selection``.

    This function tries to recursively include directories within
    ``dir``. This cannot always succeed, so if recursion fails in a
    directory, that directory is added in a list which is returned when
    the function finishes. Therefore, you can ensure that all
    directories are reached by doing:

        unsearched_dirs = [mydir]
        while unsearched_dirs:
            unsearched_dirs.extend(find_music(unsearched_dirs[0]))
            del unsearched_dirs[0]

    """
    global music_selection

    failed_dirs = []

    if pygame.mixer.get_init():
        try:
            fnames = os.listdir(dir_)
        except OSError:
            fnames = []

        for fname in fnames:
            if os.path.isfile(os.path.join(dir_, fname)):
                music_selection.append(os.path.join(dir_, fname))
            else:
                try:
                    find_music(os.path.join(dir_, fname))
                except RuntimeError:
                    d = os.path.join(dir_, fname)
                    failed_dirs.append(d)
##                    w = 'Recursion failed. {0} was not searched for music.'.format(
##                        os.path.normpath(os.path.realpath(d)))
##                    warnings.warn(w)

    return failed_dirs


def spawn_powerup(x, y):
    """Spawn a random power up at (x,y)."""
    upgrade_useful = False
    extralife_useful = False
    for player in players.sprites():
        if player.upgrade_level < player.max_upgrade_level:
            upgrade_useful = True

        if player.lives < 6:
            extralife_useful = True

    choice = rand()

    # This method of selecting the powerup might seem strange, but the
    # alternative (creating compound conditionals and putting the normal
    # powerup in an else statement) causes powerups down the line (such
    # as the extra life powerup) to become more likely if an earlier
    # upgrade is found to be useless. With this method, a powerup being
    # found to be useless results in the normal powerup being chosen as
    # the default.
    powerup = Powerup(x, y)

    if choice < 0.35:
        if upgrade_useful:
            powerup = UpgradePowerup(x, y)
    elif choice < 0.4:
        powerup = ShieldPowerup(x, y)
    elif choice < 0.42:
        if extralife_useful:
            powerup = ExtraLifePowerup(x, y)

    all_sprites.add(powerup, layer=layers['powerup'])


def play_sound(sound, loops=0, maxtime=0, fade_ms=0):
    """Play the index of loaded_sounds indicated by ``sound``.

    For information about the remaining arguments, see
    pygame.mixer.Sound.__doc__.

    """
    global loaded_sounds
    global mixer_channels

    try:
        snd = loaded_sounds[sound]
        mixer_channels[sound].play(snd, loops, maxtime, fade_ms)
    except KeyError:
        pass


class Game(object):

    """Main game class."""

    fps_limit = 120

    def __init__(self):
        self._video = {}
        self._audio = {}
        self._controls = {'player':[], 'left':[], 'right':[], 'up':[],
                          'down':[], 'select':[], 'cancel':[],
                          'pause':[], 'quit':[], 'menu':[]}

        self._video['fullscreen'] = False
        self._video['keep_ratio'] = True
        self._audio['enable_sound'] = True
        self._audio['enable_music'] = True
        self._audio['frequency'] = 22050
        self._audio['size'] = -16
        self._audio['channels'] = 2
        self._audio['buffer'] = 2048

        # Player 1 default controls
        self._controls['player'].append({'left':[], 'right':[], 'up':[],
                                         'down':[], 'special':[]})
        self._controls['player'][0]['left'].append(KeyboardControl(K_LEFT))
        self._controls['player'][0]['right'].append(KeyboardControl(K_RIGHT))
        self._controls['player'][0]['up'].append(KeyboardControl(K_UP))
        self._controls['player'][0]['down'].append(KeyboardControl(K_DOWN))
        self._controls['player'][0]['special'].append(KeyboardControl(K_KP0))

        # Player 2 default controls
        self._controls['player'].append({'left':[], 'right':[], 'up':[],
                                         'down':[], 'special':[]})
        self._controls['player'][1]['left'].append(KeyboardControl(K_a))
        self._controls['player'][1]['right'].append(KeyboardControl(K_d))
        self._controls['player'][1]['up'].append(KeyboardControl(K_w))
        self._controls['player'][1]['down'].append(KeyboardControl(K_s))
        self._controls['player'][1]['special'].append(KeyboardControl(K_SPACE))

        # Default global controls
        self._controls['pause'].append(KeyboardControl(K_p))
        self._controls['quit'].append(KeyboardControl(K_F10))
        self._controls['menu'].append(KeyboardControl(K_ESCAPE))

        self._controls['left'].append(KeyboardControl(K_LEFT))
        self._controls['right'].append(KeyboardControl(K_RIGHT))
        self._controls['up'].append(KeyboardControl(K_UP))
        self._controls['down'].append(KeyboardControl(K_DOWN))
        self._controls['select'].append(KeyboardControl(K_RETURN))
        self._controls['cancel'].append(KeyboardControl(K_ESCAPE))

        # Load config
        self._load_config('itad_config.json')

        # Initialize Pygame
        pygame.mixer.pre_init(self._audio['frequency'],
                              self._audio['size'],
                              self._audio['channels'],
                              self._audio['buffer'])
        pygame.init()
        random.seed()

        self.clock = pygame.time.Clock()

        global all_sprites
        global players
        global enemies
        all_sprites = pygame.sprite.LayeredDirty()
        players = pygame.sprite.Group()
        enemies = pygame.sprite.Group()

        # Initialize joysticks
        self.joysticks = []
        for i in xrange(0, pygame.joystick.get_count()):
            js = pygame.joystick.Joystick(i)
            js.init()
            self.joysticks.append(js)

        # Load controls
        self._load_controls('itad_controls.json')

        # Make mouse invisible
        pygame.mouse.set_visible(False)

        # Set display
        dispinfo = pygame.display.Info()

        # When graphics are loaded, they are scaled to the correct
        # size for the scaled resolution decided here.  Then,
        # screen_xsize_factor and screen_ysize_factor are set based on
        # the size difference between the internal game size and scaled
        # window size.  Sprites use these variables to position their
        # rects correctly (by simply multiplying the in-game position by
        # the respective factor).

        disp_w = dispinfo.current_w
        disp_h = dispinfo.current_h
        game_w, game_h = BOUNDSRECT.size

        if self._video['fullscreen'] or not dispinfo.wm:
            if self._video['keep_ratio']:
                if disp_w / disp_h >= game_w / game_h:
                    # Set height to that of the display, then derive
                    # width from that
                    h = disp_h
                    w = int(round(disp_h * game_w / game_h))
                else:
                    # Set width to that of the display, then dirive
                    # height from that
                    w = disp_w
                    h = int(round(disp_w * game_h / game_w))

                # Center display rect
                x = (disp_w - w) // 2
                y = (disp_h - h) // 2

                self.rect = Rect(x, y, w, h)

            else:
                self.rect = Rect(0, 0, disp_w, disp_h)

            self.window = pygame.display.set_mode(self.rect.size, FULLSCREEN)
        else:
            self.rect = Rect(0, 0, 800, 480)
            self.window = pygame.display.set_mode(self.rect.size)

        global screen_xsize_factor
        global screen_ysize_factor
        screen_xsize_factor = self.rect.width / BOUNDSRECT.width
        screen_ysize_factor = self.rect.height / BOUNDSRECT.height

        # Load graphics
        opaque_dir = os.path.join('data', 'images', 'opaque')
        transparent_dir = os.path.join('data', 'images', 'transparent')

        unloaded_dirs = [opaque_dir]
        while unloaded_dirs:
            unloaded_dirs.extend(load_images(unloaded_dirs[0], False))
            del unloaded_dirs[0]

        unloaded_dirs = [transparent_dir]
        while unloaded_dirs:
            unloaded_dirs.extend(load_images(transparent_dir, True))
            del unloaded_dirs[0]

        # Load sounds
        if self._audio['enable_sound']:
            unloaded_dirs = [os.path.join('data', 'sounds')]
            while unloaded_dirs:
                unloaded_dirs.extend(load_sounds(unloaded_dirs[0]))
                del unloaded_dirs[0]

        # Create channels
        global mixer_channels
        pygame.mixer.set_num_channels(len(loaded_sounds))

        i = 0
        for snd in loaded_sounds.keys():
            mixer_channels[snd] = pygame.mixer.Channel(i)
            i += 1

        # Find music
        if self._audio['enable_music']:
            unsearched_dirs = [os.path.join('data', 'music')]
            while unsearched_dirs:
                unsearched_dirs.extend(find_music(unsearched_dirs[0]))
                del unsearched_dirs[0]

        # Load fonts
        if pygame.font.get_init():
            size_factor = screen_ysize_factor

            fnt = os.path.join('data', 'fonts', 'dotrice',
                               'Dotrice-Condensed.otf')
            try:
                self.fnt_score = pygame.font.Font(fnt, int(64 * size_factor))
            except IOError:
                self.fnt_score = pygame.font.Font(None, int(64 * size_factor))

            fnt = os.path.join('data', 'fonts', 'gtw.ttf')
            try:
                self.fnt_status = pygame.font.Font(fnt, int(32 * size_factor))
            except IOError:
                self.fnt_status = pygame.font.Font(None, int(32 * size_factor))

            fnt = os.path.join('data', 'fonts', 'dotrice', 'Dotrice-Bold.otf')
            try:
                self.fnt_menu = pygame.font.Font(fnt, int(48 * size_factor))
            except IOError:
                self.fnt_menu = pygame.font.Font(None, int(48 * size_factor))

        else:
            self.fnt_score = NoFont()

        self.update_all = False

        self.main_menu()

        self._save_config('itad_config.json')
        self._save_controls('itad_controls.json')

    def main_menu(self):
        """Show the main menu."""
        panel = pygame.Surface((BOUNDSRECT.width * screen_xsize_factor,
                                BOUNDSRECT.height * screen_ysize_factor))
        panel.fill((0, 0, 0))
        self.running = 1
        while self.running:
            choice = self.show_menu(self.fnt_menu, '1-player', '2-player',
                                    'Quit', color=(128, 128, 128),
                                    select_color=(255, 255, 255), spacing=32,
                                    panel=panel, panel_rect=BOUNDSRECT)
            if choice == 0:
                self.start_game(1)
            elif choice == 1:
                self.start_game(2)
            else:
                self.running = False

    def start_game(self, numplayers=1):
        """Start gameplay with the given number of players."""
        try:
            p = int(float(numplayers))
        except ValueError:
            p = 1

        if p == 2:
            players = [Player(BOUNDSRECT.width // 3, BOUNDSRECT.height - 48),
                       Player((BOUNDSRECT.width * 2) // 3,
                              BOUNDSRECT.height - 48, image='p2ship')]
        else:
            players = [Player(BOUNDSRECT.width // 2, BOUNDSRECT.height - 48)]

        special_pressed = []
        lives_displays = []
        score_displays = []
        for _ in players:
            special_pressed.append(False)

            # Lives display
            disp = pygame.sprite.DirtySprite()
            disp.lives = None
            lives_displays.append(disp)

            # Score display
            disp = pygame.sprite.DirtySprite()
            disp.score = None
            score_displays.append(disp)

        all_sprites.add(players, layer=layers['players'])
        all_sprites.add(lives_displays, layer=layers['display'])
        all_sprites.add(score_displays, layer=layers['display'])

        player_refs = []
        for player in players:
            player_refs.append(weakref.proxy(player))
            del player

        # Delete the list of players to allow the players to be
        # garbage-collected.
        del players

        # Create stars
        for _ in xrange(0, 10):
            all_sprites.add(Star(), layer=layers['stars'])

        background = pygame.Surface((BOUNDSRECT.width * screen_xsize_factor,
                                     BOUNDSRECT.height * screen_ysize_factor))
        background.fill((0, 0, 0))

        # Clear the screen
        self.window.blit(background, (0, 0))
        pygame.display.update()

        current_music = None
        music_count = 1
        spawn_time = 0
        fps_average = 0
        fps_record = []
        fps_last_count = 9000

        gameover_count = 3000

        fps_display = pygame.sprite.DirtySprite()
        fps_display.fps = 0
        fps_display.image = pygame.Surface((1, 1))
        fps_display.rect = Rect(0, 0, 1, 1)
        all_sprites.add(fps_display, layer=layers['display'])

        self.clock.tick()

        self.running = 2
        while self.running >= 2:
            # Events
            self._get_input(menu=self._game_menu, quit=self.quit)

            while spawn_time >= 100:
                spawn_time -= 100
                if rand() < 0.05:
                    n = rand()
                    if n < 1:
                        enemy = StraightShooter(
                            random.randrange(0, BOUNDSRECT.width), -48)
                        L = layers['enemies']
                    all_sprites.add(enemy, layer=L)

                if rand() < 0.2:
                    n = rand()
                    if n < 0.6:
                        enemy = Asteroid(
                            random.randrange(0, BOUNDSRECT.width), -24)
                        L = layers['asteroid_small']
                    elif n < 0.9:
                        enemy = MediumAsteroid(
                            random.randrange(0, BOUNDSRECT.width), -48)
                        L = layers['asteroid_medium']
                    else:
                        enemy = LargeAsteroid(
                            random.randrange(0, BOUNDSRECT.width), -96)
                        L = layers['asteroid_large']
                    all_sprites.add(enemy, layer=L)

            numplayers = 0
            for i in xrange(len(player_refs)):
                try:
                    left = 0
                    right = 0
                    up = 0
                    down = 0

                    for control in self._controls['player'][i]['left']:
                        left = max(left, control.state)

                    for control in self._controls['player'][i]['right']:
                        right = max(right, control.state)

                    for control in self._controls['player'][i]['up']:
                        up = max(up, control.state)

                    for control in self._controls['player'][i]['down']:
                        down = max(down, control.state)

                    pressed = False
                    for control in self._controls['player'][i]['special']:
                        if control.triggered and not special_pressed[i]:
                            pressed = True
                            player_refs[i].special()
                    special_pressed[i] = pressed

                    player_refs[i].move(right - left, down - up)

                    # Update lives display
                    if lives_displays[i].lives != player_refs[i].lives:
                        lives_displays[i].lives = player_refs[i].lives
                        width = player_refs[i].image.get_width()
                        fwidth = width * player_refs[i].lives
                        height = player_refs[i].image.get_height()

                        img = pygame.Surface((fwidth, height), SRCALPHA)
                        for j in xrange(player_refs[i].lives):
                            img.blit(player_refs[i].image, (width * j, 0))

                        lives_displays[i].image = img
                        lives_displays[i].rect = img.get_rect()

                        lives_displays[i].rect.top = 0
                        if i == 0:
                            lives_displays[i].rect.left = 0
                        else:
                            lives_displays[i].rect.right = background.get_width() - 1

                        lives_displays[i].dirty = 1

                    # Update score display
                    if score_displays[i].score != player_refs[i].score:
                        score_displays[i].score = player_refs[i].score

                        score_text = str(player_refs[i].score)
                        color = pygame.Color(255, 255, 255, 255)
                        img = self.fnt_score.render(score_text, True, color)
                        score_displays[i].image = img
                        score_displays[i].rect = img.get_rect()

                        score_displays[i].rect.top = (
                            lives_displays[i].rect.bottom +
                            (4 * screen_ysize_factor))
                        if i == 0:
                            score_displays[i].rect.left = (
                                4 * screen_xsize_factor)
                        else:
                            score_displays[i].rect.right = (
                                background.get_width() -
                                (4 * screen_xsize_factor))

                        score_displays[i].dirty = 1

                    numplayers += 1

                except ReferenceError:
                    if lives_displays[i].lives is not None:
                        lives_displays[i].lives = None

                        color = pygame.Color(200, 0, 0, 255)
                        img = self.fnt_status.render("Game Over", True, color)
                        lives_displays[i].image = img
                        lives_displays[i].rect = img.get_rect()

                        lives_displays[i].rect.top = 0
                        if i == 0:
                            lives_displays[i].rect.left = 8 * screen_xsize_factor
                        else:
                            lives_displays[i].rect.right = background.get_width() - 1

                        lives_displays[i].dirty = 1

            # Update and redraw
            time_passed = min(self.clock.tick(self.fps_limit), 1000 / 15)
            spawn_time += time_passed

            # Leave the game at game over
            if numplayers <= 0:
                gameover_count -= time_passed
                if gameover_count <= 0:
                    self.running = 1

            # Record frame rate
            fps_last_count += time_passed
            fps_record.append(self.clock.get_fps())

            if fps_last_count >= 750:
                fps_last_count = 0
                fps_average = int(sum(fps_record) / len(fps_record))
                fps_record = []

                caption = 'ITAD S.G. - {0} FPS'.format(fps_average)
                pygame.display.set_caption(caption, 'ITAD S.G.')
                #print(fps_average)

                if fps_display.fps != fps_average:
                    fps_display.fps = fps_average

                    color = pygame.Color(255, 255, 255, 255)
                    img = self.fnt_menu.render(str(fps_display.fps),
                                               True, color)
                    fps_display.image = img
                    fps_display.rect = img.get_rect()
                    fps_display.rect.left = 0
                    fps_display.rect.bottom = background.get_height()
                    fps_display.dirty = 1

            all_sprites.clear(self.window, background)
            all_sprites.update(time_passed)

            if not self.update_all:
                dirty = all_sprites.draw(self.window)
                pygame.display.update(dirty)
            else:
                self.window.blit(background, (0, 0))
                for sprite in all_sprites.sprites():
                    if not sprite.dirty:
                        sprite.dirty = 1
                all_sprites.draw(self.window)
                pygame.display.update()
                self.update_all = False

            # Play music
            if (pygame.mixer.get_init() and
                    not pygame.mixer.music.get_busy() and
                    music_selection):
                music_count -= time_passed

            if music_count <= 0:
                music_count = 5000
                i = None
                while i is None and len(music_selection) > 1:
                    i = random.randrange(0, len(music_selection))
                    if music_selection[i] != current_music:
                        try:
                            pygame.mixer.music.load(music_selection[i])
                            current_music = music_selection[i]
                        except pygame.error:
                            del music_selection[i]
                            i = None
                    else:
                        i = None

                if i is not None:
                    pygame.mixer.music.play()
                elif len(music_selection) > 0:
                    try:
                        pygame.mixer.music.load(music_selection[0])
                        current_music = music_selection[0]
                        pygame.mixer.music.play(-1)
                    except pygame.error:
                        del music_selection[0]

        # Cleanup
        pygame.mixer.music.stop()
        for sprite in all_sprites:
            sprite.kill()

    def show_menu(self, font, *items, **kwargs):
        """show_menu(font, item, ..., color=(128, 128, 128), select_color=(255, 255, 255), spacing=32, panel=None, panel_rect=None)

        Show a menu and return the index of the selection.

        The arguments in *items can have the following attributes:
        image - a Pygame surface to display when not selected. If
            unspecified, the image is created by converting the argument
            into a string and rendering it with the specified font and
            color.
        select_image - a Pygame surface to display when selected. If
            unspecified, the image is created by converting the argument
            into a string and rendering it with the specified font and
            select_color.
        rect - a Pygame Rect object indicating the position of the item
            relative to ``panel_rect``. If unspecified, the horizontal
            center is aligned with the horizontal center of the previous
            item and the top is the bottom of the previous item plus
            ``spacing``.

        Required arguments:
        font - a Pygame font object used to create the images for items
            lacking an ``image`` attribute.

        Optional keyword arguments (in **kwargs):

        Returns the index of the selection as an integer.  If the Cancel
        key is pressed, -1 is returned.  If the game is quit, None is
        returned.

        """
        color = kwargs.setdefault('color', (128, 128, 128))
        select_color = kwargs.setdefault('select_color', (255, 255, 255))
        spacing = kwargs.setdefault('spacing', 32) * screen_ysize_factor
        panel = kwargs.setdefault('panel')
        panel_rect = kwargs.setdefault('panel_rect')

        y = 0
        w = 0
        h = 0
        images = []
        select_images = []
        rects = []

        for item in items:
            if hasattr(item, 'image'):
                image = item.image
            else:
                image = font.render(str(item), True, color).convert_alpha()

            if hasattr(item, 'select_image'):
                select_image = item.select_image
            else:
                select_image = font.render(str(item), True, select_color)

            if hasattr(item, 'rect'):
                rect = Rect(item.rect.left * screen_xsize_factor,
                            item.rect.top * screen_ysize_factor,
                            image.get_width(), image.get_height())
            else:
                rect = image.get_rect(top=y)

            images.append(image)
            select_images.append(select_image)
            rects.append(rect)

            #x = rect.centerx
            y = rect.bottom + spacing
            w = max(w, rect.width)
            h = max(h, rect.bottom)

        background = pygame.display.get_surface().copy()

        if panel is not None:
            if panel_rect is not None:
                panel_rect = Rect(panel_rect.left * screen_xsize_factor,
                                  panel_rect.top * screen_ysize_factor,
                                  panel.get_width(), panel.get_height())
            else:
                panel_rect = panel.get_rect()
                panel_rect.centerx = BOUNDSRECT.centerx * screen_xsize_factor
                panel_rect.centery = BOUNDSRECT.centery * screen_ysize_factor

            background.blit(panel, panel_rect)
        else:
            if panel_rect is not None:
                panel_rect = Rect(panel_rect.left * screen_xsize_factor,
                                  panel_rect.top * screen_ysize_factor,
                                  w, h)
            else:
                panel_rect = Rect(0, 0, w, h)
                panel_rect.centerx = BOUNDSRECT.centerx * screen_xsize_factor
                panel_rect.centery = BOUNDSRECT.centery * screen_ysize_factor

        items_rect = Rect(0, 0, w, h)
        items_rect.center = panel_rect.center

        x = items_rect.centerx
        for i in xrange(len(items)):
            if not hasattr(items[i], 'rect'):
                rects[i].centerx = x
            else:
                rects[i].left += items_rect.left

            rects[i].top += items_rect.top

            x = rects[i].centerx

        for i in xrange(len(images)):
            background.blit(images[i], rects[i])

        self.selection = 0
        self.final_selection = None

        self.window.blit(background, (0, 0))
        pygame.display.update()

        while self.running:
            self._get_input(up=self._menu_up, down=self._menu_down,
                            select=self._menu_select, cancel=self._menu_cancel,
                            quit=self.quit)

            self.selection %= len(rects)

            if self.final_selection is not None:
                return self.final_selection

            self.clock.tick(15)

            self.window.blit(background, (0, 0))
            self.window.blit(select_images[self.selection],
                             rects[self.selection])

            pygame.display.update(rects)

    def quit(self):
        """Quit the game after a confirmation dialog."""
        self.running = False

    def _get_input(self, **event_functions):
        for event in pygame.event.get():
            if event.type == QUIT:
                self.quit()

            elif event.type == KEYDOWN:
                for i in self._controls.keys():
                    if i in event_functions:
                        for control in self._controls[i]:
                            if (control.control_type == 'keyboard' and
                                    event.key == control.key):
                                event_functions[i]()

            elif event.type == JOYAXISMOTION:
                for i in self._controls.keys():
                    if i in event_functions:
                        for control in self._controls[i]:
                            if (control.control_type == 'joystick' and
                                    control.js_type.startswith('axis') and
                                    event.axis == control.js_id):
                                if control.js_type[-1] == '-':
                                    if event.value < -control.deadzone:
                                        event_functions[i]()
                                else:
                                    if event.value > control.deadzone:
                                        event_functions[i]()

            elif event.type == JOYBALLMOTION:
                for i in self._controls.keys():
                    if i in event_functions:
                        for control in self._controls[i]:
                            if (control.control_type == 'joystick' and
                                    control.js_type.startswith('ball') and
                                    event.ball == control.js_id):
                                if control.js_type[-2] == 'x':
                                    n = 0
                                else:
                                    n = 1

                                if control.js_type[-1] == '-':
                                    if event.rel[n] < -control.deadzone:
                                        event_functions[i]()
                                else:
                                    if event.rel[n] > control.deadzone:
                                        event_functions[i]()

            elif event.type == JOYHATMOTION:
                for i in self._controls.keys():
                    if i in event_functions:
                        for control in self._controls[i]:
                            if (control.control_type == 'joystick' and
                                    control.js_type.startswith('hat') and
                                    event.hat == control.js_id):
                                if control.js_type[-2] == 'x':
                                    n = 0
                                else:
                                    n = 1

                                if control.js_type[-1] == '-':
                                    if event.rel[n] < 0:
                                        event_functions[i]()
                                else:
                                    if event.rel[n] > 0:
                                        event_functions[i]()

            elif event.type == JOYBUTTONDOWN:
                for i in self._controls.keys():
                    if i in event_functions:
                        for control in self._controls[i]:
                            if (control.control_type == 'joystick' and
                                    control.js_type == 'button'):
                                event_functions[i]()

    def _save_config(self, fname='config.json'):
        # Save the current settings in the specified JSON config file.
        config = {'video':self._video, 'audio':self._audio}

        with open(fname, 'w') as f:
            json.dump(config, f, sort_keys=True, indent=4)

    def _load_config(self, fname='config.json'):
        # Load the specified JSON config file and sets everything based
        # on the config file.
        try:
            with open(fname, 'r') as f:
                config = json.load(f)

                if 'video' in config.keys():
                    for i in config['video'].keys():
                        self._video[i] = config['video'][i]
                if 'audio' in config.keys():
                    for i in config['audio'].keys():
                        self._audio[i] = config['audio'][i]
        except IOError:
            pass

    def _save_controls(self, fname):
        # Save the current controls in the specified JSON config file.
        # This must not be called until after the joystick module has
        # been initialized.
        controls = {'player':[], 'left':[], 'right':[], 'up':[],
                    'down':[], 'select':[], 'cancel':[], 'pause':[],
                    'quit':[], 'menu':[]}
        for i in self._controls.keys():
            if i == 'player':
                for player in self._controls['player']:
                    game_control = {}
                    for j in player.keys():
                        # Note: button is the current control being
                        # accessed (KeyboardControl or JoystickControl)
                        game_control[j] = []
                        for button in player[j]:
                            control = {}
                            control['type'] = button.control_type
                            if button.control_type == 'keyboard':
                                control['key'] = button.key
                            else:
                                jsnum = button.joystick.get_id()
                                control['jsnum'] = jsnum
                                control['jstype'] = button.js_type
                                control['id'] = button.js_id
                                control['deadzone'] = button.deadzone
                            game_control[j].append(control)
                    controls['player'].append(game_control)
            elif i in controls:
                for button in self._controls[i]:
                    control = {}
                    control['type'] = button.control_type
                    if button.control_type == 'keyboard':
                        control['key'] = button.key
                    else:
                        jsnum = button.joystick.get_id()
                        control['jsnum'] = jsnum
                        control['jstype'] = button.js_type
                        control['id'] = button.js_id
                        control['deadzone'] = button.deadzone
                    controls[i].append(control)

        with open(fname, 'w') as f:
            json.dump(controls, f, sort_keys=True, indent=4)

    def _load_controls(self, fname):
        # Load the specified JSON control config file and sets the
        # controls based on the config file.  This must not be called
        # until after the joystick module has been initialized.
        try:
            with open(fname, 'r') as f:
                controls = json.load(f)

                self._controls = {'player':[], 'left':[], 'right':[],
                                  'up':[], 'down':[], 'select':[],
                                  'cancel':[], 'pause':[], 'quit':[],
                                  'menu':[]}

                for i in controls.keys():
                    if i == 'player':
                        for player in controls['player']:
                            game_control = {'left':[], 'right':[], 'up':[],
                                          'down':[], 'special':[]}
                            for j in player.keys():
                                game_control[j] = []
                                for button in player[j]:
                                    if button['type'] == 'keyboard':
                                        control = KeyboardControl(button['key'])
                                    else:
                                        try:
                                            js = self.joysticks[button['jsnum']]
                                        except IndexError:
                                            js = FakeJoystick(button['jsnum'])

                                        control = JoystickControl(
                                            js, button['jstype'], button['id'],
                                            button.setdefault('deadzone', 0))

                                    game_control[j].append(control)

                            self._controls[i].append(game_control)

                    elif i in self._controls:
                        for button in controls[i]:
                            if button['type'] == 'keyboard':
                                control = KeyboardControl(button['key'])
                            else:
                                try:
                                    js = self.joysticks[button['jsnum']]
                                except IndexError:
                                    js = FakeJoystick(button['jsnum'])
                                control = JoystickControl(
                                        js, button['jstype'], button['id'],
                                        button.setdefault('deadzone', 0))

                            self._controls[i].append(control)
        except IOError:
            pass

    def _game_menu(self):
        choice = self.show_menu(self.fnt_menu, 'Continue game',
                                'Quit to main menu')
        self.update_all = True

        if choice == 1:
            self.running = 1

    def _menu_up(self):
        self.selection -= 1
        play_sound('select_change')

    def _menu_down(self):
        self.selection += 1
        play_sound('select_change')

    def _menu_select(self):
        self.final_selection = self.selection
        play_sound('select')

    def _menu_cancel(self):
        self.final_selection = -1
        play_sound('cancel')


class AdaptiveSprite(pygame.sprite.DirtySprite):

    """
    AdaptiveSprite(x, y, image, size, sub_size, ..., sub_offset=None, anim_fps=0, color=pygame.Color(255, 255, 255, 255))

    Create an AdaptiveSprite object which adjusts the position of the
    display rect to adapt to different screen sizes, as determined by
    the global variables ``screen_xsize_factor`` and
    ``screen_ysize_factor``.

    ``image`` indicates the index of ``loaded_images`` to use.  ``size``
    indicates the original size (a two-part tuple) of the image.
    ``sub_size`` indicates the size (a two-part tuple) of the sub-rect,
    which is intended to be used for collisions (but otherwise does
    nothing).

    Any number of additional arguments may be specified indicating
    groups the sprite should be added to.

    ``sub_offset`` indicates the offset (a two-part tuple) of the
    sub-rect from the top-left corner of the image.  If set to None, it
    becomes a value which results in the sub-rect being centered.
    ``anim_fps`` indicates the rate in frames per second to animate the
    image (if it is an animation) when the ``animate`` method is called.
    ``color`` indicates the color to use if ``image`` is not found in
    ``loaded_images``.

    It may be confusing that the size of the image is passed explicitly.
    The images in ``loaded_images`` are scaled to match the screen size,
    but absolute positioning (independent of the size of the screen) is
    used internally, so grabbing this size causes the positioning and
    size of the sub-rect to be wrong (among other possible problems).
    Also, if the size were not passed explicitly, then the substitute
    image would have to guess at the size, which is undesireable.
    """

    def __init__(self, x, y, image, size, sub_size, *groups, **kwargs):
        pygame.sprite.DirtySprite.__init__(self, *groups)

        sub_offset = kwargs.setdefault('sub_offset')
        anim_fps = kwargs.setdefault('anim_fps', 0)

        if sub_offset is None:
            sub_offset = (int((size[0] - sub_size[0]) // 2),
                          int((size[1] - sub_size[1]) // 2))

        self.x = x
        self.y = y
        self.fullrect = Rect((0, 0), size)
        self.fullrect.center = (round(x), round(y))
        self.subrect = Rect(sub_offset, sub_size)

        if anim_fps != 0:
            self._anim_count_max = 1000 / abs(anim_fps)
        else:
            self._anim_count_max = 9001
        self._anim_count = 0
        self.image_index = 0

        global loaded_images
        try:
            self.images = loaded_images[image]
        except KeyError:
            img = pygame.Surface(size)
            img.set_colorkey(pygame.Color(0, 0, 0))

            color = kwargs.setdefault('color', pygame.Color(255, 255,
                                                            255, 255))
            img.fill(color, self.subrect)

            # Resize placeholder image
            dispsize = (int(size[0] * screen_xsize_factor),
                        int(size[1] * screen_ysize_factor))
            img = pygame.transform.scale(img, dispsize)

            loaded_images[image] = [img]
            self.images = loaded_images[image]

        self.image = self.images[0]
        self.rect = self.image.get_rect()
        self.update_rect()

    def update(self, time_passed=0):
        """Update the sprite's condition.

        Called each frame to update anything needed.  Default
        implementation simply animates and updates the rect.
        ``time_passed`` indicates the time that has passed since the
        previous frame in seconds.

        Generally, derived class's update methods should look something
        like the following:

            # movement code goes here

            self.fullrect.centerx = round(self.x)
            self.fullrect.centery = round(self.y)

            # collision detection goes here

            self.animate(time_passed)
            self.update_rect()

        Overrides pygame.sprite.DirtySprite.update.  See
        pygame.sprite.Sprite.update.__doc__ for more information.

        """
        self.fullrect.centerx = round(self.x)
        self.fullrect.centery = round(self.y)

        self.animate(time_passed)
        self.update_rect()

    def animate(self, time_passed):
        """Advance the animation of the image.

        This should be called once every frame.  ``time_passed``
        indicates the number of milliseconds that have passed since
        the last time this method was called.

        """
        self._anim_count += time_passed

        while self._anim_count >= self._anim_count_max:
            self._anim_count -= self._anim_count_max
            self.image_index += 1
            self.image_index %= len(self.images)
            self.image = self.images[self.image_index]
            self.dirty = 1

    def update_rect(self):
        """Update the display rect position.

        Updates the rect based on self.x, self.y, and the size factors.
        Must be called each time position is changed for the change to
        be visible.

        """
        new_x = round(self.x * screen_xsize_factor)
        new_y = round(self.y * screen_ysize_factor)

        if (new_x != self.rect.centerx or new_y != self.rect.centery):
            self.rect.centerx = new_x
            self.rect.centery = new_y
            self.dirty = 1

    def destroy(self):
        """Destroy this sprite.

        Destruction method. Default implementation simply calls kill().
        In derived classes, this can be used to create effects or handle
        events (e.g. adding score for destroying an enemy ship).

        """
        self.kill()

    def after_death(self):
        """After-death cleanup.

        Called after an object dies (in particular, Explosion calls this
        when the animation finishes). This can be used to, for example,
        revive a dead player using one of its remaining lives. Default
        implementation does nothing, allowing the object to be
        garbage-collected.

        """
        pass


class Player(AdaptiveSprite):

    """Create a Player object.

    If ``size`` is set to ``None``, it becomes (57, 44) if ``image`` is
    'p1ship', (49, 42) if ``image`` is 'p2ship', and (31, 19) otherwise.

    ``lives`` indicates the number of lives the player will start with.

    See AdaptiveSprite.__doc__ for more information.

    """

    speed_factor = 400
    max_upgrade_level = 2
    max_lives = 6
    invincible_time = 3000

    @property
    def upgrade_level(self):
        return self._upgrade_level

    @upgrade_level.setter
    def upgrade_level(self, value):
        self._upgrade_level = max(0, min(int(value), self.max_upgrade_level))

        self._shoot_delay = (300, 150, 250, 250)[self._upgrade_level]

    @property
    def lives(self):
        return self._lives

    @lives.setter
    def lives(self, value):
        self._lives = min(value, self.max_lives)

    @property
    def invincible(self):
        return self._invincible

    @invincible.setter
    def invincible(self, value):
        self._invincible_count = max(self._invincible_count,
                                     self.invincible_time * value)
        if self._invincible != bool(value):
            self._invincible = bool(value)

            if self._invincible:
                self._shield.x = self.x
                self._shield.y = self.y
                self._shield.update_rect()
                all_sprites.add(self._shield,
                                layer=layers['player_shields'])
            else:
                self._shield.kill()

    def __init__(self, x, y, image='p1ship', size=None, sub_size=(31, 19),
                 sub_offset=None, lives=4):
        self.lives = lives

        if size is None:
            if image == 'p1ship':
                size = (57, 44)
            elif image == 'p2ship':
                size = (49, 42)
            else:
                size = (31, 19)

        if sub_offset is None:
            if image == 'p1ship':
                sub_offset = (13, 21)
            elif image == 'p2ship':
                sub_offset = (10, 21)
            else:
                sub_offset = (0, 0)

        AdaptiveSprite.__init__(self, x, y, image, size, sub_size,
                                players, sub_offset=sub_offset,
                                color=pygame.Color(171, 146, 82, 255))

        self._xstart = x
        self._ystart = y
        self._xmove = 0
        self._ymove = 0
        self._shoot_delay = 0
        self._shoot_counter = 0
        self.upgrade_level = 0
        self.score = 0
        self._shield = Shield(self)
        self._invincible = None
        self._invincible_count = -1
        self.invincible = True

    def update(self, time_passed=0):
        if self._xmove != 0 or self._ymove != 0:
            # Change position based on movement that has occured
            self.x += self._xmove * self.speed_factor * time_passed / 1000
            self.y += self._ymove * self.speed_factor * time_passed / 1000
            self._xmove = 0
            self._ymove = 0

            # Update in-game full rect
            self.fullrect.centerx = round(self.x)
            self.fullrect.centery = round(self.y)

            # Keep the ship inside the window
            if self.fullrect.left + self.subrect.left < 0:
                self.fullrect.left = 0 - self.subrect.left
                self.x = self.fullrect.centerx
            if self.fullrect.left + self.subrect.right > BOUNDSRECT.width:
                self.fullrect.left = BOUNDSRECT.width - self.subrect.right
                self.x = self.fullrect.centerx
            if self.fullrect.top + self.subrect.top < 0:
                self.fullrect.top = 0 - self.subrect.top
                self.y = self.fullrect.centery
            if self.fullrect.top + self.subrect.bottom > BOUNDSRECT.height:
                self.fullrect.top = BOUNDSRECT.height - self.subrect.bottom
                self.y = self.fullrect.centery

            # Update rect position
            self.update_rect()

        # Handle invincibility
        self._invincible_count -= time_passed
        if self._invincible_count <= 0:
            self.invincible = False

        # Shoot
        self._shoot_counter += time_passed

        while self._shoot_counter >= self._shoot_delay:
            self._shoot_counter -= self._shoot_delay
            self.shoot(self._shoot_counter)

    def move(self, xmove, ymove):
        """Tell the ship to move the given amounts.

        Both ``xmove`` and ``ymove`` should be values from -1 to 1.
        If total movement is greater than 1, it will be capped to 1
        without changing the direction (preventing diagonal movement
        from being faster and also preventing multiple calls of this
        method from resulting in faster movement).

        """
        if xmove != 0 or ymove != 0:
            self._xmove += xmove
            self._ymove += ymove

            # Limit each part of movement to 1 (allows easy application
            # of the Pathagorean Theorem below). Division allows easy
            # and clean preservation of the sign.
            if abs(self._xmove) > 1:
                self._xmove /= abs(self._xmove)
            if abs(self._ymove) > 1:
                self._ymove /= abs(self._ymove)

            # Limit total movement to 1 (prevent diagonal movement from
            # being faster).
            if abs(self._xmove)**2 + abs(self._ymove)**2 > 1:
                angle = math.atan(abs(self._ymove) / abs(self._xmove))
                self._xmove = math.cos(angle) * (self._xmove / abs(self._xmove))
                self._ymove = math.sin(angle) * (self._ymove / abs(self._ymove))

    def shoot(self, x_time):
        """Shoot a bullet or set of bullets based on powerup state.

        ``x_time`` is the time value used to determine how much to move
        the bullet initially when it is created, i.e. the amount of time
        that has passed since the bullet should have been fired.

        """
        (self._shoot_0, self._shoot_0, self._shoot_1,
         self._shoot_2)[self._upgrade_level](x_time)

    def special(self):
        """Initiate the special attack.

        Special attack, initiated by the player with the "special"
        button.  Currently unimplemented. Will probably be a laser of
        sorts.

        """
        print ("special attack")

    def destroy(self):
        if not self.invincible:
            explosion = Explosion(self.x, self.y, obj=self)
            all_sprites.add(explosion, layer=self._layer + 1)
            play_sound('explosion')
            self.kill()

    def after_death(self):
        """After-death cleanup.

        If there are remaining lives, reduce lives by 1 and return this
        ship to the game; otherwise, allow this ship to be
        garbage-collected (do nothing).

        """
        if self.lives > 0:
            self.lives -= 1

            self._xmove = 0
            self._ymove = 0
            self._shoot_counter = 0
            self.upgrade_level -= 1

            self.x = self._xstart
            self.y = self._ystart
            self.fullrect.centerx = round(self.x)
            self.fullrect.centery = round(self.y)
            self.update_rect()

            all_sprites.add(self)
            players.add(self)

            self.invincible = True

    def _shoot_single(self, x_time):
        # Fires one bullet straight forward.
        bullet = PlayerBullet(self.x, self.y, parent=self)
        bullet.update(x_time)
        all_sprites.add(bullet, layer=layers['player_bullets'])

        play_sound('shoot')

    def _shoot_double(self, x_time):
        # Fires two bullets straight forward.
        bullet = PlayerBullet(self.x - 6, self.y, parent=self)
        bullet.update(x_time)
        all_sprites.add(bullet, layer=20)

        bullet = PlayerBullet(self.x + 6, self.y, parent=self)
        bullet.update(x_time)
        all_sprites.add(bullet, layer=layers['player_bullets'])

        play_sound('shoot')

    def _shoot_super(self, x_time):
        # Fires one super-bullet
        bullet = PlayerBullet(self.x, self.y, image='superbullet',
                              size=(34, 45), sub_size=(34, 34),
                              offset=17, parent=self)
        bullet.update(x_time)
        all_sprites.add(bullet, layer=layers['player_superbullets'])

        play_sound('shoot_super')

    def _shoot_diagonal(self, x_time):
        # Fires 2 bullets forward diagonally
        bullet = PlayerBullet(self.x - 10, self.y, angle=337.5, parent=self)
        bullet.update(x_time)
        all_sprites.add(bullet, layer=layers['player_bullets'])

        bullet = PlayerBullet(self.x + 10, self.y, angle=22.5, parent=self)
        bullet.update(x_time)
        all_sprites.add(bullet, layer=layers['player_bullets'])

        play_sound('shoot')

    def _shoot_0(self, x_time):
        self._shoot_single(x_time)

    def _shoot_1(self, x_time):
        self._shoot_super(x_time)

    def _shoot_2(self, x_time):
        self._shoot_super(x_time)
        self._shoot_diagonal(x_time)


class Shield(AdaptiveSprite):

    """Shield class used by player ships.

    This currently is only display; it is made visible when a player is
    invincible and follows the player's position.

    """

    def __init__(self, parent, **kwargs):
        self.parent = weakref.proxy(parent)
        image = kwargs.setdefault('image', 'shield')
        size = kwargs.setdefault('size', (64, 64))
        sub_size = kwargs.setdefault('sub_size', (64, 64))
        sub_offset = kwargs.setdefault('sub_offset')
        anim_fps = kwargs.setdefault('anim_fps', 15)

        AdaptiveSprite.__init__(self, parent.x, parent.y, image, size,
                                sub_size, sub_offset=sub_offset,
                                anim_fps=anim_fps,
                                color=pygame.Color(255, 255, 255, 255))


    def update(self, time_passed):
        try:
            self.x = self.parent.x
            self.y = self.parent.y

            self.fullrect.centerx = self.x
            self.fullrect.centery = self.y

            self.update_rect()
        except ReferenceError:
            self.kill()

        self.animate(time_passed)

    def destroy(self):
        pass


class Enemy(AdaptiveSprite):

    """Base enemy class.

    This class should not be used directly. Instead, derived classes
    should be created from it.

    The class attribute ``bonus_score`` indicates the number of points
    rewarded to a player for destroying the given Enemy-derived class.

    """

    bonus_score = 100

    def update(self, time_passed):
        self.x += self.xspeed * time_passed / 1000
        self.y += self.yspeed * time_passed / 1000

        self.fullrect.centerx = round(self.x)
        self.fullrect.centery = round(self.y)

        if self.fullrect.top > BOUNDSRECT.height:
            self.kill()

        self.collide()
        self.animate(time_passed)
        self.update_rect()

    def destroy(self):
        if rand() < 0.8:
            spawn_powerup(self.x, self.y)

        self.kill()

    def collide(self):
        """Handle collision detection with players."""
        sub_left = self.fullrect.left + self.subrect.left
        sub_right = self.fullrect.left + self.subrect.right
        sub_top = self.fullrect.top + self.subrect.top
        sub_bottom = self.fullrect.top + self.subrect.bottom

        for sprite in players.sprites():
            playersub_left = sprite.fullrect.left + sprite.subrect.left
            playersub_right = sprite.fullrect.left + sprite.subrect.right
            playersub_top = sprite.fullrect.top + sprite.subrect.top
            playersub_bottom = sprite.fullrect.top + sprite.subrect.bottom

            if (sub_left <= playersub_right and
                    sub_right >= playersub_left and
                    sub_top <= playersub_bottom and
                    sub_bottom >= playersub_top):
                sprite.destroy()
                self.destroy()


class Asteroid(Enemy):

    """Asteroid(x, y, image='asteroid_small', size=(32, 32), sub_size=(28, 28), sub_offset=None, xspeed_range=(-50, 50), yspeed_range=(100, 200))

    Create a new Asteroid object.

    The defaults for ``image``, ``size``, and ``sub_size`` in derived
    classes can be modified by setting the following class attributes:

    default_image
    default_size
    default_sub_size

    See AdaptiveSprite.__doc__ for more information.

    """

    default_image = 'asteroid_small'
    default_size = (37, 37)
    default_sub_size = (24, 24)
    default_anim_fps = 15

    def __init__(self, x, y, **kwargs):
        image = kwargs.setdefault('image', self.default_image)
        size = kwargs.setdefault('size', self.default_size)
        sub_size = kwargs.setdefault('sub_size', self.default_sub_size)
        sub_offset = kwargs.setdefault('sub_offset')
        xspeed_range = kwargs.setdefault('xspeed_range', (-50, 50))
        yspeed_range = kwargs.setdefault('yspeed_range', (100, 200))
        anim_fps = kwargs.setdefault('anim_fps', self.default_anim_fps)

        AdaptiveSprite.__init__(self, x, y, image, size, sub_size, enemies,
                                sub_offset=sub_offset, anim_fps=anim_fps,
                                color=pygame.Color(150, 120, 0, 255))

        # Set random speed
        self.xspeed = random.randint(*xspeed_range)
        self.yspeed = random.randint(*yspeed_range)

        self.image_index = 0
        self.anim_time = 0

    def destroy(self):
        self.kill()


class MediumAsteroid(Asteroid):

    """MediumAsteroid(x, y, image='asteroid_medium', size=(64, 64), sub_size=(60, 60), sub_offset=None, xspeed_range=(-50, 50), yspeed_range=(100, 200))

    Create a new MediumAsteroid object.  When destroyed, it spawns two
    Asteroid objects.  This class is otherwise identical in function to
    Asteroid.

    See Asteroid.__doc__ and AdaptiveSprite.__doc__ for more
    information.

    """

    default_image = 'asteroid_medium'
    default_size = (74, 74)
    default_sub_size = (48, 48)
    default_anim_fps = 12

    def destroy(self):
        """Kill the asteroid and spawn two Asteroid objects."""
        self.kill()

        roid = Asteroid(self.x - 8, self.y, xspeed_range=(-150, -100))
        all_sprites.add(roid)
        roid = Asteroid(self.x + 8, self.y, xspeed_range=(100, 150))
        all_sprites.add(roid)


class LargeAsteroid(Asteroid):

    """LargeAsteroid(x, y, image='asteroid_large', size=(128, 128), sub_size=(124, 124), sub_offset=None, xspeed_range=(-50, 50), yspeed_range=(100, 200))

    Create a new LargeAsteroid object.  When destroyed, it spawns two
    MediumAsteroid objects.  This class is otherwise identical in
    function to Asteroid.

    See Asteroid.__doc__ and AdaptiveSprite.__doc__ for more
    information.

    """

    default_image = 'asteroid_large'
    default_size = (148, 147)
    default_sub_size = (96, 97)
    default_anim_fps = 10

    def destroy(self):
        """Kill the asteroid and spawn two MediumAsteroid objects."""
        self.kill()

        roid = MediumAsteroid(self.x - 16, self.y, xspeed_range=(-100, -50))
        all_sprites.add(roid)
        roid = MediumAsteroid(self.x + 16, self.y, xspeed_range=(50, 100))
        all_sprites.add(roid)


class StraightShooter(Enemy):

    """Moves straight down and fires bullets.

    See AdaptiveSprite.__doc__ for more information.

    """

    bonus_score = 1000

    def __init__(self, x, y, image='enemy_straightshooter', size=(32, 32),
                 sub_size=(14, 27), sub_offset=(9, 0)):
        AdaptiveSprite.__init__(self, x, y, image, size, sub_size,
                                enemies, sub_offset=sub_offset,
                                color=pygame.Color(150, 120, 0, 255))

        self.xspeed = 0
        self.yspeed = 200

        self.shoot_counter = 500

    def update(self, time_passed):
        Enemy.update(self, time_passed)

        self.shoot_counter += time_passed

        while self.shoot_counter >= 750:
            self.shoot_counter -= 750

            bullet = EnemyBullet(self.x, self.y)
            all_sprites.add(bullet, layer=layers['enemy_bullets'])
            play_sound('shoot')


class DirectionalShooter(Enemy):
    pass


class Looper(Enemy):
    pass


class RearEnder(Enemy):
    pass


class Bullet(AdaptiveSprite):
    """Bullet(x, y, image='playerbullet', size=(5, 7), sub_size=(5, 5), speed=1000, angle=0, offset=4, anim_fps=5)

    ``speed`` indicates the speed the bullet should travel in pixels
    per second.  ``angle`` indicates the angle of travel as well as the
    image rotation of the bullet in degrees, counterclockwise, with 0
    pointing up.  ``offset`` indicates the number of pixels the center
    is offset from the back (it is used to calculate the collision
    rect's position).

    Defaults of derived classes for the arguments can be modified by
    setting these class attributes:

    default_image
    default_size
    default_sub_size
    default_speed
    default_angle
    default_offset

    See AdaptiveSprite.__doc__ for more information.

    """
    default_image = 'playerbullet'
    default_size = (5, 7)
    default_sub_size = (5, 5)
    default_speed = 1000
    default_angle = 0
    default_offset = 4

    def __init__(self, x, y, **kwargs):
        pygame.sprite.DirtySprite.__init__(self)

        image = kwargs.setdefault('image', self.default_image)
        size = kwargs.setdefault('size', self.default_size)
        sub_size = kwargs.setdefault('sub_size', self.default_sub_size)
        speed = kwargs.setdefault('speed', self.default_speed)
        angle = kwargs.setdefault('angle', self.default_angle)
        offset = kwargs.setdefault('offset', self.default_offset)

        global loaded_images
        try:
            self.images = loaded_images[image]
        except KeyError:
            img = pygame.Surface(size)
            color = pygame.Color(0, 255, 255, 255)
            img.fill(color)
            loaded_images[image] = [img]
            self.images = loaded_images[image]

        # Get or create the proper rotated version if angle % 360 is not 0
        if angle % 360 != 0:
            rot_image = '{0}-rot{1}'.format(image, angle)
            try:
                self.images = loaded_images[rot_image]
            except KeyError:
                loaded_images[rot_image] = []
                for i in xrange(len(loaded_images[image])):
                    loaded_images[rot_image].append(
                        pygame.transform.rotate(loaded_images[image][i],
                                                -angle))
                self.images = loaded_images[rot_image]

        # Set the sub-rect
        real_angle = math.radians((angle + 270) % 360)
        x_amount = math.cos(real_angle)
        y_amount = math.sin(real_angle)

        r = min(size) / 2
        back_x = -(x_amount * r) + (size[0] / 2)
        back_y = -(y_amount * r) + (size[1] / 2)

        x_offset = back_x + (x_amount * offset)
        y_offset = back_y + (y_amount * offset)

        self.subrect = Rect((0, 0), sub_size)
        self.subrect.center = (x_offset, y_offset)

        # Determine xspeed and yspeed
        self.xspeed = x_amount * speed
        self.yspeed = y_amount * speed

        self.image_index = 0
        self.anim_time = 0
        self.image = self.images[0]

        # Since the image is rotated, the exact size of it cannot be
        # predicted. Therefore, it is calculated here instead.
        size = (round(self.image.get_width() / screen_xsize_factor),
                round(self.image.get_height() / screen_ysize_factor))

        self.x = x
        self.y = y
        self.fullrect = Rect((0, 0), size)
        self.fullrect.center = (round(x), round(y))
        self.rect = self.image.get_rect()
        self.update_rect()


class PlayerBullet(Bullet):

    """PlayerBullet(x, y, parent=None, image='playerbullet', size=(5, 7), sub_size=(5, 5), speed=1000, angle=0, offset=4)

    Create a new PlayerBullet object.

    ``parent`` is the player object that shot this bullet, used to award
    points for hitting enemies.

    See Bullet.__doc__ and AdaptiveSprite.__doc__ for more information.

    """

    default_image = 'playerbullet'
    default_size = (5, 7)
    default_sub_size = (5, 5)
    default_speed = 1000
    default_angle = 0
    default_offset = 4

    def __init__(self, x, y, **kwargs):
        parent = kwargs.setdefault('parent', None)

        if parent is not None:
            self.parent = weakref.ref(parent)
        else:
            self.parent = None

        Bullet.__init__(self, x, y, **kwargs)

    def update(self, time_passed):
        xmove = self.xspeed * time_passed / 1000
        ymove = self.yspeed * time_passed / 1000

        xprevious = self.x
        yprevious = self.y
        self.x += xmove
        self.y += ymove

        self.fullrect.centerx = round(self.x)
        self.fullrect.centery = round(self.y)

        if self.fullrect.bottom < 0 or self.fullrect.top > BOUNDSRECT.height:
            self.kill()

        self.anim_time += time_passed
        if self.anim_time >= 250:
            self.image_index = (self.image_index + 1) % len(self.images)
            self.image = self.images[self.image_index]
            self.anim_time -= 250

        # Collision Detection
        sub_left = self.fullrect.left + self.subrect.left
        sub_right = self.fullrect.left + self.subrect.right
        sub_top = self.fullrect.top + self.subrect.top
        sub_bottom = self.fullrect.top + self.subrect.bottom

        # If xspeed or yspeed is 0, rather than going through a
        # collision algorithm for the empty space between the current
        # and previous positions, extend the size of the rect to take up
        # the empty space.
        if self.yspeed == 0:
            sub_left = min(sub_left, sub_right - xmove)
            sub_right = max(sub_right, sub_left - xmove)
        if self.xspeed == 0:
            sub_top = min(sub_top, sub_bottom - ymove)
            sub_bottom = max(sub_bottom, sub_top - ymove)

        for sprite in enemies.sprites():
            enemysub_left = sprite.fullrect.left
            enemysub_right = sprite.fullrect.right
            enemysub_top = sprite.fullrect.top
            enemysub_bottom = sprite.fullrect.bottom

            if (sub_left <= enemysub_right and
                    sub_right >= enemysub_left and
                    sub_top <= enemysub_bottom and
                    sub_bottom >= enemysub_top):
                if self.parent is not None and self.parent() is not None:
                    self.parent().score += sprite.bonus_score

                sprite.destroy()
                self.destroy()
            elif (self.xspeed != 0 and self.yspeed != 0 and
                  enemysub_left <= max(self.x, xprevious) and
                  enemysub_right >= min(self.x, xprevious) and
                  enemysub_top <= max(self.y, yprevious) and
                  enemysub_bottom >= min(self.y, yprevious)):
                # Line collision (y=mx+b)
                m = self.yspeed / self.xspeed
                b = self.y - m * self.x

                x1 = (enemysub_top - b) / m
                x2 = (enemysub_bottom - b) / m
                y1 = m * enemysub_left + b
                y2 = m * enemysub_right + b

                if ((enemysub_left <= x1 and enemysub_right >= x1) or
                        (enemysub_left <= x2 and enemysub_right >= x2) or
                        (enemysub_top <= y1 and enemysub_bottom >= y1) or
                        (enemysub_top <= y2 and enemysub_bottom >= y2)):
                    if self.parent is not None and self.parent() is not None:
                        self.parent().score += sprite.bonus_score

                    sprite.destroy()
                    self.destroy()

        self.update_rect()


class EnemyBullet(Bullet):

    """EnemyBullet(x, y, image='playerbullet', size=(5, 7), sub_size=(5, 5), speed=500, angle=180, offset=4)

    Bullet for enemies.

    See Bullet.__doc__ and AdaptiveSprite.__doc__ for more information.

    """

    default_image = 'playerbullet'
    default_size = (5, 7)
    default_sub_size = (5, 5)
    default_speed = 750
    default_angle = 180
    default_offset = 4

    def update(self, time_passed):
        xmove = self.xspeed * time_passed / 1000
        ymove = self.yspeed * time_passed / 1000

        xprevious = self.x
        yprevious = self.y
        self.x += xmove
        self.y += ymove

        self.fullrect.centerx = round(self.x)
        self.fullrect.centery = round(self.y)

        if self.fullrect.bottom < 0 or self.fullrect.top > BOUNDSRECT.height:
            self.kill()

        self.anim_time += time_passed
        if self.anim_time >= 250:
            self.image_index = (self.image_index + 1) % len(self.images)
            self.image = self.images[self.image_index]
            self.anim_time -= 250

        # Collision Detection
        sub_left = self.fullrect.left + self.subrect.left
        sub_right = self.fullrect.left + self.subrect.right
        sub_top = self.fullrect.top + self.subrect.top
        sub_bottom = self.fullrect.top + self.subrect.bottom

        # If xspeed or yspeed is 0, rather than going through a
        # collision algorithm for the empty space between the current
        # and previous positions, extend the size of the rect to take up
        # the empty space.
        if self.yspeed == 0:
            sub_left = min(sub_left, sub_right - xmove)
            sub_right = max(sub_right, sub_left - xmove)
        if self.xspeed == 0:
            sub_top = min(sub_top, sub_bottom - ymove)
            sub_bottom = max(sub_bottom, sub_top - ymove)

        for sprite in players.sprites():
            playersub_left = sprite.fullrect.left + sprite.subrect.left
            playersub_right = sprite.fullrect.left + sprite.subrect.right
            playersub_top = sprite.fullrect.top + sprite.subrect.top
            playersub_bottom = sprite.fullrect.top + sprite.subrect.bottom

            if (sub_left <= playersub_right and
                    sub_right >= playersub_left and
                    sub_top <= playersub_bottom and
                    sub_bottom >= playersub_top):
                sprite.destroy()
                self.destroy()
            elif (self.xspeed != 0 and self.yspeed != 0 and
                  playersub_left <= max(self.x, xprevious) and
                  playersub_right >= min(self.x, xprevious) and
                  playersub_top <= max(self.y, yprevious) and
                  playersub_bottom >= min(self.y, yprevious)):
                # Line collision (y=mx+b)
                m = self.yspeed / self.xspeed
                b = self.y - m * self.x

                x1 = (playersub_top - b) / m
                x2 = (playersub_bottom - b) / m
                y1 = m * playersub_left + b
                y2 = m * playersub_right + b

                if ((playersub_left <= x1 and playersub_right >= x1) or
                        (playersub_left <= x2 and playersub_right >= x2) or
                        (playersub_top <= y1 and playersub_bottom >= y1) or
                        (playersub_top <= y2 and playersub_bottom >= y2)):
                    sprite.destroy()
                    self.destroy()

        self.update_rect()


class Powerup(AdaptiveSprite):

    """Powerup(x, y, image='powerup', size=(32, 32), xspeed_range=(-50, 50), yspeed_range=(25, 100))

    Create a new Powerup object.  xspeed_range and yspeed_range are
    two-part tuples indicating the ranges of possible horizontal speeds
    and vertical speeds, respectively (chosen randomly).

    The defaults for ``image`` and ``size`` can be adjusted in derived
    classes by setting the following class attributes:

        default_image
        default_size

    When a Powerup object is collected by a player, that player's score
    is increased by the class attribute ``bonus_score``.  In addition,
    the sound indicated by the class attribute ``collect_sound`` is
    played.  The score bonus and sound played can be adjusted in derived
    classes by setting these attributes.

    See AdaptiveSprite.__doc__ for more information.

    """

    default_image = 'powerup'
    default_size = (32, 32)
    color = pygame.Color(255, 255, 0, 255)
    bonus_score = 2000
    collect_sound = 'powerup'

    def __init__(self, x, y, **kwargs):
        image = kwargs.setdefault('image', self.default_image)
        size = kwargs.setdefault('size', self.default_size)
        xspeed_range = kwargs.setdefault('xspeed_range', (-50, 50))
        yspeed_range = kwargs.setdefault('yspeed_range', (25, 100))

        AdaptiveSprite.__init__(self, x, y, image, size, size,
                                color=self.color)

        self.xspeed = random.randint(*xspeed_range)
        self.yspeed = random.randint(*yspeed_range)

    def update(self, time_passed):
        self.x += self.xspeed * time_passed / 1000
        self.y += self.yspeed * time_passed / 1000

        self.fullrect.centerx = self.x
        self.fullrect.centery = self.y

        # Collision Detection
        for player in players.sprites():
            if (self.fullrect.left <= player.fullrect.right and
                    self.fullrect.right >= player.fullrect.left and
                    self.fullrect.top <= player.fullrect.bottom and
                    self.fullrect.bottom >= player.fullrect.top):
                play_sound('powerup')

                self.collect(player)
                player.score += self.bonus_score
                self.kill()

        if self.fullrect.top > BOUNDSRECT.height + 8:
            self.kill()

        self.update_rect()

    def collect(self, player):
        """Give this powerup's reward to ``player``."""
        pass


class UpgradePowerup(Powerup):

    """Increases the player's upgrade level by 1."""

    default_image = 'powerup_upgrade'
    color = pygame.Color(76, 143, 54, 255)
    bonus_score = 500

    def collect(self, player):
        player.upgrade_level += 1


class ShieldPowerup(Powerup):

    """Causes temporary invincibility."""

    default_image = 'powerup_shield'
    color = pygame.Color(16, 110, 136, 255)
    bonus_score = 500

    def collect(self, player):
        player.invincible = 3


class ExtraLifePowerup(Powerup):

    """Gives an extra life to the player."""

    default_image = 'powerup_extralife'
    color = pygame.Color(197, 0, 0, 255)
    bonus_score = 0

    def collect(self, player):
        player.lives += 1


class ExtraBombPowerup(Powerup):

    """
    """

    default_image = 'powerup_extrabomb'
    color = pygame.Color(106, 16, 136, 255)


class Explosion(AdaptiveSprite):

    """Explosion(x, y, image='explosion', size=(115, 110), duration=1.5, obj=None, obj_duration=0.5)

    Create an Explosion object. This shows an explosion animation for
    a number of seconds specified by ``duration``. In addition, if
    ``obj`` is specified, it will display obj.image underneath the
    explosion for a number of seconds specified by ``obj_duration`` and
    call obj.after_death after the explosion animation finishes.

    Note: this object's layer should be greater than ``obj``'s layer.
    If it is not, the explosion animation will be underneath obj.image
    instead of on top of it.

    """

    def __init__(self, x, y, image='explosion', size=(115, 110),
                 duration=1500, obj=None, obj_duration=500):
        self.duration = duration
        self.obj = obj
        self.obj_duration = obj_duration

        AdaptiveSprite.__init__(self, x, y, image, size, size,
                                color=pygame.Color(171, 146, 82, 255))

        self.anim_time = 0
        self.last_index = None

        self.obj_sprite = pygame.sprite.DirtySprite()
        if self.obj is not None:
            self.obj_sprite.image = self.obj.image
            self.obj_sprite.rect = self.obj.rect
            all_sprites.add(self.obj_sprite, layer=self.obj._layer)

    def update(self, time_passed):
        self.anim_time += time_passed

        if self.anim_time < self.duration:
            image_index = min(int(self.anim_time * len(self.images) /
                                  self.duration),
                              len(self.images) - 1)
            self.image = self.images[image_index]
            self.dirty = 1

            if (self.obj_sprite is not None and
                    self.anim_time >= self.obj_duration):
                self.obj_sprite.kill()
                self.obj_sprite = None

        else:
            if self.obj is not None:
                self.obj.after_death()

            self.kill()


class Star(AdaptiveSprite):

    """Background star.

    These act as part of the background by moving to the bottom of the
    screen and then reappearing at the top once they reach the bottom.

    Their initial position and speed are random and cannot be set.
    However, they can later be manipulated by adjusting the attributes
    ``x``, ``y``, and ``speed``.

    """
    speed_min = 10
    speed_max = 75

    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self)
        self.speed = random.randint(self.speed_min, self.speed_max)

        global loaded_images
        try:
            self.image = loaded_images['star'][0]
        except KeyError:
            img = pygame.Surface((1, 1))
            img.fill(pygame.Color(255, 255, 255, 255))
            loaded_images['star'] = [img]
            self.image = img

        self.x = random.randrange(0, BOUNDSRECT.width)
        self.y = random.randrange(0, BOUNDSRECT.height)
        self.rect = self.image.get_rect()
        self.update_rect()

        self.dirty_counter = 0

    def update(self, time_passed):
        self.y += self.speed * time_passed / 1000
        if self.y >= BOUNDSRECT.height:
            self.x = random.randrange(0, BOUNDSRECT.width)
            self.y = random.randrange(-32, 0)
            self.speed = random.randint(self.speed_min, self.speed_max)

        self.dirty_counter += time_passed
        if self.dirty_counter >= 2 * time_passed:
            self.dirty_counter = 0
            self.update_rect()


class KeyboardControl(object):

    """Create a KeyboardControl object.

    To read input, use the variables triggered and state.  This is
    designed to be usable in the same way as JoystickControl.

    ``key`` should be a valid keycode to detect.

    Use the properties ``triggered`` and ``state`` to see input.  These
    are read-only.

    If it is necessary to know what type of control it is (e.g. for
    saving config files), the class variable ``control_type`` can be
    read. For KeyboardControl, it is 'keyboard'.

    The key this control detects is set by the ``key`` attribute. This
    can be safely set to other keys if desired.

    """

    control_type = 'keyboard'

    def __init__(self, key):
        self.key = key
        self._triggered = False

    @property
    def triggered(self):
        self._refresh()
        return self._triggered

    @property
    def state(self):
        return int(self.triggered)

    def _refresh(self):
        # "Refreshes" knowledge of the key state.  This is called
        # automatically in the triggered getter.
        if pygame.key.get_focused():
            pressed = pygame.key.get_pressed()
            self._triggered = pressed[self.key]
        else:
            self._triggered = False


class JoystickControl(object):

    """Create a JoystickControl object.

    To read input, use the variables triggered and state.  This is
    designed to be usable in the same way as KeyboardControl.

    ``joystick`` should be a valid pygame.joystick.Joystick object.
    ``type`` should be a string and can be any of the following:

        'button'
        'axis-'
        'axis+'
        'hatx-'
        'hatx+'
        'haty-'
        'haty+'
        'ballx-'
        'ballx+'
        'bally-'
        'bally+'

    ``num`` is the specific control, i.e. the button, axis, HAT, or
    trackball number.  ``deadzone`` is the percentage (number from
    0-100) of the center of an axis to ignore (default 0).

    Use the properties ``triggered`` and ``state`` to see input.  These
    are read-only.

    If it is necessary to know what type of control it is (e.g. for
    saving config files), the class variable ``control_type`` can be
    read. For JoystickControl, it is 'joystick'.

    The pygame.joystick.Joystick object are stored in the ``joystick``
    attribute.  The joystick type is stored in the ``js_type``
    property.  The control (e.g. button number) is stored in the
    ``js_id`` attribute.  The deadzone is stored in the ``deadzone``
    attribute. These can all be modified to other legitimate values at
    any time.

    """

    control_type = 'joystick'

    def __init__(self, joystick, type_, num, deadzone=0):
        self.joystick = joystick
        self.js_type = type_
        self.js_id = num
        self.deadzone = deadzone

        self._state = 0

    @property
    def triggered(self):
        self._refresh()
        return bool(self._state)

    @property
    def state(self):
        self._refresh()
        return self._state

    @property
    def js_type(self):
        return self._js_type

    @js_type.setter
    def js_type(self, value):
        self._js_type = value

        if self.joystick is not None:
            if value == 'button':
                self._refresh = self._refresh_button
                self._valuetoget = None
                self._direction = None

            elif value.startswith('axis'):
                self._refresh = self._refresh_axis
                if value[-1] == '-':
                    self._valuetoget = -1
                else:
                    self._valuetoget = 1
                self._direction = None

            elif value.startswith('hat'):
                self._refresh = self._refresh_hat
                if value[-1] == '-':
                    self._valuetoget = -1
                else:
                    self._valuetoget = 1
                self._direction = value[-2]

            elif value.startswith('ball'):
                self._refresh = self._refresh_ball
                if value[-1] == '-':
                    self._valuetoget = -1
                else:
                    self._valuetoget = 1
                self._direction = value[-2]

            else:
                raise ValueError('"{0}" is not a valid control type.'.format(value))
        else:
            self._refresh = lambda: None

    def _refresh_button(self):
        # "Refreshes" knowledge of the button state.  If the control is
        # a button, this method's name is assigned to self._refresh,
        # which is called automatically in the triggered and state setters.

        self._state = 0
        if (self.joystick.get_init() and
                self.js_id < self.joystick.get_numbuttons()):
            self._state = int(self.joystick.get_button(self.js_id))

    def _refresh_axis(self):
        # "Refreshes" knowledge of the axis state.  If the control is an
        # axis, this method's name is assigned to self._refresh, which
        # is called automatically in the triggered and state setters.

        self._state = 0
        if (self.joystick.get_init() and
                self.js_id < self.joystick.get_numaxes()):
            value = self.joystick.get_axis(self.js_id)
            if (value == abs(value) * self._valuetoget and
                    abs(value) * 100 > self.deadzone):
                self._state = abs(value)

    def _refresh_hat(self):
        # "Refreshes" knowledge of the HAT state.  If the control is a
        # HAT, this method's name is assigned to self._refresh, which is
        # called automatically in the triggered and state setters.

        self._state = 0
        if (self.joystick.get_init() and
                self.js_id < self.joystick.get_numhats()):
            if self._direction == 'x':
                value = self.joystick.get_hat(self.js_id)[0]
            else:
                value = self.joystick.get_hat(self.js_id)[1]
            if self._valuetoget == -1:
                self._state = abs(min(value, 0))
            else:
                self._state = max(0, value)

    def _refresh_ball(self):
        # "Refreshes" knowledge of the ball state.  If the control is a
        # ball, this method's name is assigned to self._refresh, which
        # is called automatically in the triggered and state setters.

        self._state = 0
        if (self.joystick.get_init() and
                self.js_id < self.joystick.get_numballs()):
            if self._direction == 'x':
                value = self.joystick.get_ball(self.js_id)[0]
            else:
                value = self.joystick.get_ball(self.js_id)[1]
            if self._valuetoget == -1:
                self._state = abs(min(value, 0))
            else:
                self._state = max(0, value)


class FakeJoystick(object):

    """An empty replacement for pygame.joystick.Joystick."""

    def __init__(self, id_):
        self._id = id_
    def init(self):
        pass
    def quit(self):
        pass
    def get_init(self):
        return False
    def get_id(self):
        return self._id
    def get_name(self):
        return ""
    def get_numaxes(self):
        return 0
    def get_axis(self, *args, **kwargs):
        return 0
    def get_numballs(self):
        return 0
    def get_ball(self, *args, **kwargs):
        return 0, 0
    def get_numbuttons(self):
        return 0
    def get_button(self, *args, **kwargs):
        return False
    def get_numhats(self):
        return 0
    def get_hat(self, *args, **kwargs):
        return 0, 0

class NoFont(object):

    """An empty replacement for pygame.font.Font."""

    def __init__(self, *args, **kwargs):
        pass
    def render(self, *args, **kwargs):
        return pygame.Surface((1, 1))
    def size(self, *args, **kwargs):
        return (0, 0)
    def set_underline(self, *args, **kwargs):
        pass
    def get_underline(self, *args, **kwargs):
        return False
    def set_bold(self, *args, **kwargs):
        pass
    def get_bold(self, *args, **kwargs):
        return False
    def set_italic(self, *args, **kwargs):
        pass
    def get_italic(self, *args, **kwargs):
        return False
    def metrics(self, *args, **kwargs):
        return None
    def get_linesize(self, *args, **kwargs):
        return 0
    def get_height(self, *args, **kwargs):
        return 0
    def get_ascent(self, *args, **kwargs):
        return 0
    def get_descent(self, *args, **kwargs):
        return 0


if __name__ == '__main__':
    main(*sys.argv)
