#!/usr/bin/env python3

# Kitten Command
# Copyright (c) 2014, 2015 Julian Marchant <onpon4@riseup.net>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from __future__ import division
from __future__ import absolute_import
from __future__ import print_function
from __future__ import unicode_literals

__version__ = "1.0"

import json
import math
import os
import random
import sys

import six
import sge
import xsge_gui
import xsge_physics


if getattr(sys, "frozen", False):
    __file__ = sys.executable

DATA = os.path.join(os.path.dirname(__file__), "data")
CONFIG = os.path.join(os.path.expanduser("~"), ".config", "kitten_command")

SCREEN_SIZE = [320, 240]
TILE_SIZE = 16
FPS = 60

ARENA_Y = 80
ARENA_HEIGHT = 144

CAT_ORIGIN_X = 30
CAT_ORIGIN_Y = 40
CAT_FPS = 12
CAT_BBOX_X = -5
CAT_BBOX_Y = 3
CAT_BBOX_WIDTH = 11
CAT_BBOX_HEIGHT = 11
CAT_BULLET_X = 16
CAT_BULLET_Y = 0
CAT_WALK_SPEED = 1
CAT_INVINCIBLE_TIME = 180

BULLET_COST = 20
BULLET_SPEED = 4

GOOMBA_SPEED = 0.375
GREENKOOPA_SPEED = 0.375
SPINY_SPEED = 0.375
REDKOOPA_SPEED = 0.75
HAMMERBRO_SPEED = 0.25
SHELL_SPEED = 2

HAMMER_INTERVAL = 60
HAMMER_WARMUP = 30
HAMMER_FOLLOWTHROUGH = 15
HAMMER_SPEED = 3

SPAWN_INTERVAL = 30

SCORETITLE_Y = 4
SCORE_X = 160
SCORE_Y = 16

loaded_music = {}

fullscreen = False
sound_enabled = True
music_enabled = True
fps_enabled = False
joystick_threshold = 0.1
left_key = ["left"]
right_key = ["right"]
up_key = ["up"]
down_key = ["down"]
action_key = ["space"]
pause_key = ["enter"]
left_js = [(0, "axis-", 0)]
right_js = [(0, "axis+", 0)]
up_js = [(0, "axis-", 1)]
down_js = [(0, "axis+", 1)]
action_js = [(0, "button", 1)]
pause_js = [(0, "button", 9)]

score = 0
highscores = [0, 0, 0, 0, 0]


class Game(sge.Game):

    fps_time = 0
    fps_frames = 0
    fps_text = ""

    def event_step(self, time_passed, delta_mult):
        if fps_enabled:
            self.fps_time += time_passed
            self.fps_frames += 1
            if self.fps_time >= 250:
                self.fps_text = str(int(round((1000 * self.fps_frames) /
                                              self.fps_time)))
                self.fps_time = 0
                self.fps_frames = 0

            self.project_text(font, self.fps_text, self.width - 4,
                              self.height - 4, z=1000,
                              color=sge.Color("green"), halign="right",
                              valign="bottom")

    def event_key_press(self, key, char):
        if key == "f11":
            if self.fullscreen:
                self.scale = 2
                self.fullscreen = False
                self.scale = None
            else:
                self.fullscreen = True

    def event_mouse_button_press(self, button):
        if button == "middle":
            self.event_close()

    def event_close(self):
        self.end()

    def event_paused_close(self):
        self.event_close()


class TitleScreen(sge.Room):

    def __init__(self):
        super(TitleScreen, self).__init__(background=background)

    def event_room_start(self):
        self.add(gui_handler)
        self.event_room_resume()

    def event_room_resume(self):
        sge.Music.clear_queue()
        sge.Music.stop(1000)
        MainMenu.create()

    def event_step(self, time_passed, delta_mult):
        sge.game.project_text(font, "High Score", SCORE_X, SCORETITLE_Y,
                              color=sge.Color("white"), halign="center")
        sge.game.project_text(font, str(max(highscores)), SCORE_X, SCORE_Y,
                              color=sge.Color("white"), halign="center")


class ScoresScreen(sge.Room):

    def event_room_start(self):
        self.add(gui_handler)

    def event_step(self, time_passed, delta_mult):
        text = "High Scores"
        sge.game.project_text(font, text, self.width / 2, 32,
                              color=sge.Color("aqua"), halign="center",
                              valign="top", anti_alias=False)
        text = "Baby\n\n\nEasy\n\n\nNormal\n\n\nHard\n\n\nInsane!"
        sge.game.project_text(font, text, 48, self.height / 2,
                              color=sge.Color("white"), halign="left",
                              valign="middle", anti_alias=False)
        text = "{}\n\n\n{}\n\n\n{}\n\n\n{}\n\n\n{}".format(*highscores)
        sge.game.project_text(font, text, self.width - 48, self.height / 2,
                              color=sge.Color("white"), halign="right",
                              valign="middle", anti_alias=False)

    def event_key_press(self, key, char):
        sge.game.start_room.start()

    def event_joystick_button_press(self, js_name, js_id, button):
        sge.game.start_room.start()


class CreditsScreen(sge.Room):

    def event_room_start(self):
        self.add(gui_handler)
        play_music("music.mid")

        with open(os.path.join(DATA, "credits.json"), 'r') as f:
            sections = json.load(f)

        logo_section = sge.Object.create(self.width / 2, self.height,
                                         tangible=False)
        self.sections = [logo_section]
        for section in sections:
            if "title" in section:
                head_sprite = sge.Sprite.from_text(
                    font, section["title"], width=self.width,
                    color=sge.Color("aqua"), halign="center")
                x = self.width / 2
                y = self.sections[-1].bbox_bottom + font.size * 3
                head_section = sge.Object.create(x, y, sprite=head_sprite,
                                                 tangible=False)
                self.sections.append(head_section)

            if "lines" in section:
                for line in section["lines"]:
                    list_sprite = sge.Sprite.from_text(
                        font, line, width=self.width - 2 * TILE_SIZE,
                        color=sge.Color("white"), halign="center")
                    x = self.width / 2
                    y = self.sections[-1].bbox_bottom + font.size
                    list_section = sge.Object.create(x, y, sprite=list_sprite,
                                                     tangible=False)
                    self.sections.append(list_section)

        for obj in self.sections:
            obj.yvelocity = -0.25

    def event_step(self, time_passed, delta_mult):
        if self.sections[0].yvelocity > 0 and self.sections[0].y > self.height:
            for obj in self.sections:
                obj.yvelocity = 0

        if self.sections[-1].bbox_bottom < 0:
            sge.game.start_room.start()

    def event_key_press(self, key, char):
        if key == "down":
            for obj in self.sections:
                obj.yvelocity -= 0.125
        elif key == "up":
            for obj in self.sections:
                obj.yvelocity += 0.125
        elif key in {"escape", "enter"}:
            sge.game.start_room.start()

    def event_joystick_button_press(self, js_name, js_id, button):
        sge.game.start_room.start()


class Arena(sge.Room):

    def __init__(self, difficulty=0):
        super(Arena, self).__init__(
            background=background, object_area_width=TILE_SIZE,
            object_area_height=TILE_SIZE)
        self.difficulty = difficulty
        self.stage = -1
        self.spawn_chance = 0
        self.spawn_limit = 2
        self.spawn_choices = [Goomba]
        self.gameover = False
        if difficulty == 0:
            self.brick_columns = 5
            self.recover_time = 0
            self.stage_interval = 90 * FPS
        elif difficulty == 1:
            self.brick_columns = 4
            self.recover_time = 3
            self.stage_interval = 45 * FPS
            self.stage = 0
        elif difficulty == 2:
            self.brick_columns = 3
            self.recover_time = 5
            self.stage_interval = 30 * FPS
            self.stage = 1
        elif difficulty == 3:
            self.brick_columns = 2
            self.recover_time = 7
            self.stage_interval = 20 * FPS
            self.stage = 2
        else:
            self.brick_columns = 1
            self.recover_time = 10
            self.stage_interval = 10 * FPS
            self.stage = 5

        self.event_alarm("next_stage")
        self.alarms["spawn"] = SPAWN_INTERVAL

    def pause(self):
        global highscores

        highscores[self.difficulty] = max(highscores[self.difficulty], score)
        sge.Music.pause()
        PauseMenu.create()

    def event_room_start(self):
        global score

        self.add(gui_handler)

        score = 0

        w = SCREEN_SIZE[0]
        y = ARENA_Y - TILE_SIZE
        xsge_physics.Solid.create(0, y, bbox_width=w, bbox_height=TILE_SIZE)
        y = ARENA_Y + ARENA_HEIGHT
        xsge_physics.Solid.create(0, y, bbox_width=w, bbox_height=TILE_SIZE)

        tile_w = brick_sprite.width
        tile_h = brick_sprite.height

        for column in six.moves.range(self.brick_columns):
            x = column * tile_w
            for y in six.moves.range(ARENA_Y, ARENA_Y + ARENA_HEIGHT, tile_h):
                Brick.create(x, y)

        x = self.brick_columns * tile_w + TILE_SIZE
        y = ARENA_Y + ARENA_HEIGHT / 2
        Player.create(x, y)

        self.event_room_resume()

    def event_room_resume(self):
        play_music("music.mid")

    def event_step(self, time_passed, delta_mult):
        sge.game.project_text(font, "Score", SCORE_X, SCORETITLE_Y,
                              color=sge.Color("white"), halign="center")
        sge.game.project_text(font, str(score), SCORE_X, SCORE_Y,
                              color=sge.Color("white"), halign="center")

    def event_alarm(self, alarm_id):
        global highscores

        if alarm_id == "next_stage":
            self.stage += 1

            if self.stage <= 0:
                self.spawn_chance = 0.1
                self.spawn_limit = 2
                self.spawn_choices = [Goomba]
            elif self.stage <= 1:
                self.spawn_chance = 0.15
                self.spawn_limit = 3
                self.spawn_choices = [Goomba]
            elif self.stage <= 2:
                self.spawn_chance = 0.25
                self.spawn_limit = 4
                self.spawn_choices = [Goomba, Goomba, Goomba, GreenKoopa]
            elif self.stage <= 3:
                self.spawn_chance = 0.5
                self.spawn_limit = 5
                self.spawn_choices = [Goomba, Goomba, Goomba, Goomba, Goomba,
                                      GreenKoopa, GreenKoopa, Spiny]
            elif self.stage <= 4:
                self.spawn_chance = 0.5
                self.spawn_limit = 6
                self.spawn_choices = [Goomba, Goomba, Goomba, Goomba, Goomba,
                                      GreenKoopa, GreenKoopa, Spiny, RedKoopa]
            elif self.stage <= 5:
                self.spawn_chance = 0.5
                self.spawn_limit = 6
                self.spawn_choices = [Goomba, Goomba, Goomba, Goomba, Goomba,
                                      Goomba, Goomba, Goomba, GreenKoopa,
                                      GreenKoopa, GreenKoopa, GreenKoopa,
                                      Spiny, Spiny, Spiny, Spiny, RedKoopa,
                                      RedKoopa, HammerBro]
            elif self.stage <= 6:
                self.spawn_chance = 0.5
                self.spawn_limit = 6
                self.spawn_choices = [Goomba, Goomba, Goomba, Goomba, Goomba,
                                      Goomba, GreenKoopa, GreenKoopa, Spiny,
                                      Spiny, Spiny, Spiny, Spiny, Spiny,
                                      RedKoopa, RedKoopa, HammerBro]
            else:
                self.spawn_chance = 1 - ((1 - self.spawn_chance) / 2)
                self.spawn_limit = 7
                
                self.spawn_choices.append(random.choice([
                    Spiny, RedKoopa, RedKoopa, RedKoopa, HammerBro, HammerBro,
                    HammerBro]))

            self.alarms["next_stage"] = self.stage_interval

        elif alarm_id == "spawn":
            enemies = list(filter(lambda o: isinstance(o, Enemy), self.objects))
            if (random.random() < self.spawn_chance and
                    len(enemies) < self.spawn_limit):
                cls = random.choice(self.spawn_choices)
                y = random.uniform(ARENA_Y + TILE_SIZE,
                                   ARENA_Y + ARENA_HEIGHT - TILE_SIZE)
                cls.create(self.width + TILE_SIZE, y)

            self.alarms["spawn"] = SPAWN_INTERVAL

        elif alarm_id == "gameover":
            highscores[self.difficulty] = max(highscores[self.difficulty],
                                              score)
            room = GameOverScreen()
            room.start()

    def event_key_press(self, key, char):
        global highscores

        if key == "escape":
            highscores[self.difficulty] = max(highscores[self.difficulty],
                                              score)
            sge.game.start_room.start()


class GameOverScreen(sge.Room):

    def event_room_start(self):
        self.add(gui_handler)

    def event_step(self, time_passed, delta_mult):
        text = "Game Over\n\nScore - {}".format(score)
        self.project_text(font, text, self.width / 2, self.height / 2, 0,
                          color=sge.Color("white"), halign="center",
                          valign="middle", anti_alias=False)

    def event_key_press(self, key, char):
        sge.game.start_room.start()

    def event_joystick_button_press(self, js_name, js_id, button):
        sge.game.start_room.start()


class Player(xsge_physics.Collider):

    def __init__(self, x, y, player=0):
        super(Player, self).__init__(
            x, y, z=y, sprite=cat_stand_sprite, checks_collisions=False,
            bbox_x=CAT_BBOX_X, bbox_y=CAT_BBOX_Y, bbox_width=CAT_BBOX_WIDTH,
            bbox_height=CAT_BBOX_HEIGHT)
        self.player = player
        self.left_pressed = False
        self.right_pressed = False
        self.up_pressed = False
        self.down_pressed = False
        self.shooting = False
        self.dead = False
        self.recovering = False
        self.recover_timer = None

    def refresh_input(self):
        self.left_pressed = sge.keyboard.get_pressed(left_key[self.player])
        self.right_pressed = sge.keyboard.get_pressed(
            right_key[self.player])
        self.up_pressed = sge.keyboard.get_pressed(up_key[self.player])
        self.down_pressed = sge.keyboard.get_pressed(down_key[self.player])

        # Add current joystick state
        js_controls = [left_js, right_js, up_js, down_js]
        js_states = [False for i in js_controls]
        for i in six.moves.range(len(js_controls)):
            if js_controls[i][self.player] is not None:
                j, t, c = js_controls[i][self.player]
                if t == "axis+":
                    v = sge.joystick.get_axis(j, c)
                    if v > joystick_threshold:
                        js_states[i] = abs(v)
                elif t == "axis-":
                    v = sge.joystick.get_axis(j, c)
                    if v < -joystick_threshold:
                        js_states[i] = abs(v)
                elif t == "axis0":
                    js_states[i] = (abs(sge.joystick.get_axis(j, c)) <=
                                    joystick_threshold)
                elif t == "hatx+":
                    js_states[i] = (sge.joystick.get_hat_x(j, c) == 1)
                elif t == "hatx-":
                    js_states[i] = (sge.joystick.get_hat_x(j, c) == -1)
                elif t == "haty+":
                    js_states[i] = (sge.joystick.get_hat_y(j, c) == 1)
                elif t == "haty-":
                    js_states[i] = (sge.joystick.get_hat_y(j, c) == -1)
                elif t == "hatx0":
                    js_states[i] = (sge.joystick.get_hat_x(j, c) == 0)
                elif t == "haty0":
                    js_states[i] = (sge.joystick.get_hat_y(j, c) == 0)
                elif t == "button":
                    js_states[i] = sge.joystick.get_pressed(j, c)

        self.left_pressed = self.left_pressed or js_states[0]
        self.right_pressed = self.right_pressed or js_states[1]
        self.up_pressed = self.up_pressed or js_states[2]
        self.down_pressed = self.down_pressed or js_states[3]

    def action(self):
        global score

        if not self.dead and not self.recovering:
            play_sound(shoot_sound)
            self.shooting = True
            self.alarms["shoot_end"] = 2 * FPS / CAT_FPS
            Bullet.create(self.x + CAT_BULLET_X, self.y + CAT_BULLET_Y)
            score = max(0, score - BULLET_COST)

    def kill(self):
        if not self.dead and ("invincible" not in self.alarms or
                              sge.game.current_room.gameover):
            self.dead = True
            self.xvelocity = 0
            self.yvelocity = 0
            self.sprite = cat_die_sprite
            self.image_index = 0
            play_sound(die_sound)

    def recover(self):
        if self.dead and not self.recovering:
            self.recovering = True
            self.recover_timer = None
            self.sprite = cat_recover_sprite
            self.image_index = 0
            self.image_fps = None
            self.alarms["invincible"] = CAT_INVINCIBLE_TIME

    def event_step(self, time_passed, delta_mult):
        if not self.dead and not self.recovering:
            self.refresh_input()

            # Set speed
            self.xvelocity = ((self.right_pressed - self.left_pressed) *
                              CAT_WALK_SPEED)
            self.yvelocity = ((self.down_pressed - self.up_pressed) *
                              CAT_WALK_SPEED)
            self.speed = min(self.speed, CAT_WALK_SPEED)

            # Set image
            if self.shooting:
                if self.xvelocity or self.yvelocity:
                    self.sprite = cat_walk_shoot_sprite
                else:
                    self.sprite = cat_stand_shoot_sprite
            else:
                if self.xvelocity or self.yvelocity:
                    self.sprite = cat_walk_sprite
                else:
                    self.sprite = cat_stand_sprite

            # Set Z value
            self.z = self.bbox_bottom

        if self.bbox_left < 0:
            self.bbox_left = 0
        elif self.bbox_right > sge.game.current_room.width:
            self.bbox_right = sge.game.current_room.width

        # Recovery countdown
        if self.recover_timer:
            y = self.bbox_bottom + 4
            sge.game.current_room.project_text(
                font, str(self.recover_timer), self.x, y, 1000,
                color=sge.Color("navy"), halign="center")

        if "invincible" in self.alarms:
            self.image_alpha = 128
        else:
            self.image_alpha = 255

    def event_alarm(self, alarm_id):
        if alarm_id == "shoot_end":
            self.shooting = False
        elif alarm_id == "recover":
            if (self.recover_timer is not None and
                    not sge.game.current_room.gameover):
                self.recover_timer -= 1
                if self.recover_timer <= 0:
                    self.recover()
                else:
                    self.alarms["recover"] = FPS
            else:
                self.recover_timer = None

    def event_animation_end(self):
        if self.recovering:
            self.dead = False
            self.recovering = False
            self.recover_timer = None
            self.sprite = cat_stand_sprite
            self.image_index = 0
            self.image_fps = None
        elif self.dead:
            self.image_index = self.sprite.frames - 1
            self.image_fps = 0
            if not sge.game.current_room.gameover:
                if sge.game.current_room.recover_time > 0:
                    self.recover_timer = sge.game.current_room.recover_time
                    self.alarms["recover"] = FPS
                else:
                    self.recover_timer = 0
                    self.alarms["recover"] = FPS / 4

    def event_key_press(self, key, char):
        if key == action_key[self.player]:
            self.action()
        if key == pause_key[self.player]:
            sge.game.current_room.pause()

    def event_joystick_axis_move(self, js_name, js_id, axis, value):
        js_versions = [(js_id, "axis+", axis), (js_id, "axis-", axis)]
        if value > joystick_threshold:
            js = (js_id, "axis+", axis)
        elif value < -joystick_threshold:
            js = (js_id, "axis-", axis)
        else:
            js = (js_id, "axis0", axis)

        if js == tuple(action_js[self.player]):
            self.action()
        if js == tuple(pause_js[self.player]):
            sge.game.current_room.pause()

    def event_joystick_hat_move(self, js_name, js_id, hat, x, y):
        js_versions = [(js_id, "hatx+", hat), (js_id, "hatx-", hat)]
        if x > 0:
            js = (js_id, "hatx+", hat)
        elif x < 0:
            js = (js_id, "hatx-", hat)
        else:
            js = (js_id, "hatx0", hat)

        if js == tuple(action_js[self.player]):
            self.action()
        if js == tuple(pause_js[self.player]):
            sge.game.current_room.pause()

        js_versions = [(js_id, "haty+", hat), (js_id, "haty-", hat)]
        if y > 0:
            js = (js_id, "haty+", hat)
        elif y < 0:
            js = (js_id, "haty-", hat)
        else:
            js = (js_id, "haty0", hat)

        if js == tuple(action_js[self.player]):
            self.action()
        if js == tuple(pause_js[self.player]):
            sge.game.current_room.pause()

    def event_joystick_button_press(self, js_name, js_id, button):
        js = (js_id, "button", button)

        if js == tuple(action_js[self.player]):
            self.action()
        if js == tuple(pause_js[self.player]):
            sge.game.current_room.pause()


class Brick(xsge_physics.Solid):

    def __init__(self, x, y):
        super(Brick, self).__init__(x, y, z=0, sprite=brick_sprite,
                                    checks_collisions=False)

    def kill(self):
        Corpse.create(self.x, self.y, sprite=brick_shard_sprite, xvelocity=-2,
                      yvelocity=-3, yacceleration=0.25)
        Corpse.create(self.x + 8, self.y, sprite=brick_shard_sprite,
                      xvelocity=2, yvelocity=-3, yacceleration=0.25)
        play_sound(brick_break_sound)
        self.destroy()


class Bullet(sge.Object):

    def __init__(self, x, y):
        super(Bullet, self).__init__(
            x, y, z=y, sprite=bullet_sprite, xvelocity=BULLET_SPEED,
            checks_collisions=False)

    def event_step(self, time_passed, delta_mult):
        if self.bbox_left > sge.game.current_room.width:
            self.destroy()

    def event_collision(self, other, xdirection, ydirection):
        if isinstance(other, Enemy):
            self.destroy()
            other.hurt()


class Enemy(xsge_physics.Collider):

    health = 1
    points = 100

    def hurt(self):
        self.health -= 1
        if self.health > 0:
            play_sound(enemy_hit_sound)
        else:
            self.kill()

    def kill(self):
        global score

        play_sound(kick_sound)
        Corpse.create(self.x, self.y, sprite=self.sprite, yvelocity=-2,
                      yacceleration=0.25, image_yscale=-1, image_fps=0)
        score += self.points
        self.destroy()

    def event_create(self):
        if self.bbox_top < ARENA_Y:
            self.bbox_top = ARENA_Y
        elif self.bbox_bottom > ARENA_Y + ARENA_HEIGHT:
            self.bbox_bottom = ARENA_Y + ARENA_HEIGHT

    def event_step(self, time_passed, delta_mult):
        self.z = self.bbox_bottom

        if self.x - self.image_origin_x + self.sprite.width < 0:
            if not sge.game.current_room.gameover:
                sge.game.current_room.gameover = True
                for obj in sge.game.current_room.objects[:]:
                    if isinstance(obj, (Player, Brick)):
                        obj.kill()
                sge.game.current_room.alarms["gameover"] = 5 * FPS
                sge.Music.clear_queue()
                sge.Music.stop(5000)

            self.destroy()

    def event_collision(self, other, xdirection, ydirection):
        if isinstance(other, Brick):
            self.kill()
            other.kill()
        elif isinstance(other, Player):
            other.kill()

    def event_physics_collision_left(self, other, move_loss):
        self.event_collision(other, -1, 0)

    def event_physics_collision_right(self, other, move_loss):
        self.event_collision(other, 1, 0)

    def event_physics_collision_top(self, other, move_loss):
        self.event_collision(other, 0, -1)

    def event_physics_collision_bottom(self, other, move_loss):
        self.event_collision(other, 0, 1)


class Goomba(Enemy):

    def __init__(self, x, y):
        super(Goomba, self).__init__(x, y, z=y, sprite=goomba_sprite,
                                     xvelocity=-GOOMBA_SPEED)


class GreenKoopa(Enemy):

    health = 3
    points = 200

    def __init__(self, x, y):
        super(GreenKoopa, self).__init__(x, y, z=y, sprite=greenkoopa_sprite,
                                         xvelocity=-GREENKOOPA_SPEED)

    def hurt(self):
        self.health -= 1
        if self.health > 0:
            play_sound(enemy_hit_sound)
        else:
            play_sound(kick_sound)
            GreenShell.create(self.x, self.y)
            self.destroy()


class GreenShell(Enemy):

    health = 8
    points = 200

    def __init__(self, x, y):
        super(GreenShell, self).__init__(x, y, z=y, sprite=greenshell_sprite)

    def event_create(self):
        super(GreenShell, self).event_create()
        self.hurt()

    def hurt(self):
        self.health -= 1
        if self.health > 0:
            play_sound(kick_sound)
            self.sprite = greenshelldash_sprite
            self.xvelocity = SHELL_SPEED
        else:
            self.kill()

    def kill(self):
        global score

        play_sound(kick_sound)
        Corpse.create(self.x, self.y, sprite=greenshell_sprite, yvelocity=-2,
                      yacceleration=0.25, image_yscale=-1, image_fps=0)
        score += self.points
        self.destroy()

    def event_step(self, time_passed, delta_mult):
        super(GreenShell, self).event_step(time_passed, delta_mult)

        if self.x - self.image_origin_x > sge.game.current_room.width:
            self.destroy()

    def event_collision(self, other, xdirection, ydirection):
        if isinstance(other, Brick):
            self.kill()
            other.kill()
        elif isinstance(other, Player):
            if self.speed:
                other.kill()
            else:
                self.hurt()
        elif isinstance(other, Enemy):
            if self.speed:
                self.kill()
                other.kill()

    def event_physics_collision_top(self, other, move_loss):
        super(GreenShell, self).event_physics_collision_top(other, move_loss)
        self.yvelocity = abs(self.yvelocity)
        play_sound(kick_sound)

    def event_physics_collision_bottom(self, other, move_loss):
        super(GreenShell, self).event_physics_collision_bottom(other, move_loss)
        self.yvelocity = -abs(self.yvelocity)
        play_sound(kick_sound)


class Spiny(Enemy):

    health = 6
    points = 300

    def __init__(self, x, y):
        super(Spiny, self).__init__(x, y, z=y, sprite=spiny_sprite,
                                    xvelocity=-SPINY_SPEED)


class RedKoopa(Enemy):

    health = 3
    points = 300

    def __init__(self, x, y):
        super(RedKoopa, self).__init__(x, y, z=y, sprite=redkoopa_sprite,
                                       xvelocity=-REDKOOPA_SPEED)

    def hurt(self):
        self.health -= 1
        if self.health > 0:
            play_sound(enemy_hit_sound)
        else:
            play_sound(kick_sound)
            RedShell.create(self.x, self.y)
            self.destroy()


class RedShell(GreenShell):

    health = 8
    points = 300

    def __init__(self, x, y):
        super(GreenShell, self).__init__(x, y, z=y, sprite=redshell_sprite)

    def hurt(self, reverse=False):
        self.health -= 1
        if self.health > 0:
            play_sound(kick_sound)
            self.sprite = redshelldash_sprite
            target = None

            if reverse:
                def f(o): return isinstance(o, Player)
                players = list(filter(f, sge.game.current_room.objects))
                if players:
                    target = random.choice(players)
            else:
                def f(o, self=self):
                    return o is not self and isinstance(o, Enemy)
                enemies = list(filter(f, sge.game.current_room.objects))
                if enemies:
                    target = random.choice(enemies)

            self.speed = SHELL_SPEED
            if target:
                self.move_direction = math.degrees(math.atan2(
                    self.y - target.y, target.x - self.x))
            else:
                self.move_direction = random.uniform(0, 360)
        else:
            self.kill()

    def kill(self):
        play_sound(kick_sound)
        Corpse.create(self.x, self.y, sprite=redshell_sprite, yvelocity=-2,
                      yacceleration=0.25, image_yscale=-1, image_fps=0)
        self.destroy()

    def event_collision(self, other, xdirection, ydirection):
        if isinstance(other, Brick):
            self.hurt()
            other.kill()
        elif isinstance(other, Player):
            if self.speed:
                other.kill()
            else:
                self.hurt()
        elif isinstance(other, Enemy):
            if self.speed:
                self.hurt(True)
                other.kill()


class HammerBro(Enemy):

    health = 6
    points = 1000

    def __init__(self, x, y):
        super(HammerBro, self).__init__(
            x, y, z=y, sprite=hammerbro_sprite, xvelocity=-HAMMERBRO_SPEED,
            image_xscale=-1)
        self.target = None
        self.alarms["hammer"] = HAMMER_INTERVAL

    def event_step(self, time_passed, delta_mult):
        super(HammerBro, self).event_step(time_passed, delta_mult)

        if self.xvelocity:
            self.image_xscale = (self.xvelocity > 0) - (self.xvelocity < 0)
        elif self.target is not None:
            self.image_xscale = ((self.target.x > self.x) -
                                 (self.target.x < self.x))

    def event_alarm(self, alarm_id):
        if alarm_id == "hammer":
            def f(o): return isinstance(o, Player) and not o.dead
            players = list(filter(f, sge.game.current_room.objects))
            if players:
                self.xvelocity = 0
                self.sprite = hammerbro_throw_sprite
                self.target = random.choice(players)
                self.alarms["hammer_throw"] = HAMMER_WARMUP
            else:
                self.alarms["hammer"] = HAMMER_INTERVAL
        elif alarm_id == "hammer_throw":
            play_sound(hammer_throw_sound)
            self.sprite = hammerbro_sprite
            self.image_index = 0
            self.image_fps = 0
            hammer = Hammer.create(
                self.x, self.y, self.y, sprite=hammer_sprite,
                image_xscale=self.image_xscale)
            hammer.speed = HAMMER_SPEED
            hammer.move_direction = math.degrees(math.atan2(
                hammer.y - self.target.y, self.target.x - hammer.x))
            self.target = None
            self.alarms["hammer_end"] = HAMMER_FOLLOWTHROUGH
        elif alarm_id == "hammer_end":
            self.image_fps = None
            self.xvelocity = -HAMMERBRO_SPEED
            self.alarms["hammer"] = HAMMER_INTERVAL


class Hammer(sge.Object):

    def event_step(self, time_passed, delta_mult):
        if (self.x - self.image_origin_x + self.sprite.width < 0 or
                self.x - self.image_origin_x > sge.game.current_room.width or
                self.y - self.image_origin_y + self.sprite.height < 0 or
                self.y - self.image_origin_y > sge.game.current_room.height):
            self.destroy()

        self.z = self.y

    def event_collision(self, other, xdirection, ydirection):
        if isinstance(other, Player):
            other.kill()


class Corpse(sge.Object):

    def __init__(self, x, y, z=1000, sprite=None, visible=True, xvelocity=0,
                 yvelocity=0, xacceleration=0, yacceleration=0,
                 xdeceleration=0, ydeceleration=0, image_index=0,
                 image_origin_x=None, image_origin_y=None, image_fps=None,
                 image_xscale=1, image_yscale=1, image_rotation=0,
                 image_alpha=255, image_blend=None, life=None):
        super(Corpse, self).__init__(
            x, y, z=z, sprite=sprite, visible=visible, tangible=False,
            xvelocity=xvelocity, yvelocity=yvelocity,
            xacceleration=xacceleration, yacceleration=yacceleration,
            xdeceleration=xdeceleration, ydeceleration=ydeceleration,
            image_index=image_index, image_origin_x=image_origin_x,
            image_origin_y=image_origin_y, image_fps=image_fps,
            image_xscale=image_xscale, image_yscale=image_yscale,
            image_rotation=image_rotation, image_alpha=image_alpha,
            image_blend=image_blend)
        self.life = life

    def event_step(self, time_passed, delta_mult):
        if self.life is not None:
            self.life -= delta_mult
            if self.life <= 0:
                self.destroy()

        if self.y > sge.game.current_room.height + self.image_origin_y:
            self.destroy()


class Menu(xsge_gui.MenuWindow):

    items = []

    @classmethod
    def create(cls, default=0):
        if cls.items:
            self = cls.from_text(
                gui_handler, sge.game.width / 2, sge.game.height * 2 / 3,
                cls.items, font_normal=font, color_normal=sge.Color("white"),
                color_selected=sge.Color("red"),
                background_color=sge.Color("black"), margin=4, halign="center",
                valign="middle")
            default %= len(self.widgets)
            self.keyboard_focused_widget = self.widgets[default]
            self.show()
            return self


class MainMenu(Menu):

    items = ["Start Game", "Options", "Scores", "Credits", "Quit"]

    def event_choose(self):
        if self.choice == 0:
            StartGameMenu.create(default=2)
        elif self.choice == 1:
            OptionsMenu.create_page()
        elif self.choice == 2:
            scores_room = ScoresScreen()
            scores_room.start()
        elif self.choice == 3:
            credits_room = CreditsScreen()
            credits_room.start()
        else:
            sge.game.end()


class StartGameMenu(Menu):

    items = ["Baby", "Easy", "Normal", "Hard", "Insane!", "Back"]

    def event_choose(self):
        if self.choice in {0, 1, 2, 3, 4}:
            arena = Arena(self.choice)
            arena.start()
        else:
            MainMenu.create(default=0)


class OptionsMenu(Menu):

    @classmethod
    def create_page(cls, default=0):
        cls.items = [
            "Fullscreen: {}".format("On" if sge.game.fullscreen else "Off"),
            "Sound: {}".format("On" if sound_enabled else "Off"),
            "Music: {}".format("On" if music_enabled else "Off"),
            "Show FPS: {}".format("On" if fps_enabled else "Off"),
            "Joystick Threshold: {}%".format(int(joystick_threshold * 100)),
            "Configure keyboard", "Configure joysticks", "Detect joysticks",
            "Back"]
        return cls.create(default)

    def event_choose(self):
        global fullscreen
        global sound_enabled
        global music_enabled
        global fps_enabled
        global joystick_threshold

        if self.choice == 0:
            fullscreen = not fullscreen
            sge.game.fullscreen = fullscreen
            OptionsMenu.create_page(default=self.choice)
        elif self.choice == 1:
            sound_enabled = not sound_enabled
            OptionsMenu.create_page(default=self.choice)
        elif self.choice == 2:
            music_enabled = not music_enabled
            OptionsMenu.create_page(default=self.choice)
        elif self.choice == 3:
            fps_enabled = not fps_enabled
            OptionsMenu.create_page(default=self.choice)
        elif self.choice == 4:
            # This somewhat complicated method is to prevent rounding
            # irregularities.
            threshold = ((int(joystick_threshold * 100) + 5) % 100) / 100
            joystick_threshold = threshold
            xsge_gui.joystick_threshold = threshold
            OptionsMenu.create_page(default=self.choice)
        elif self.choice == 5:
            KeyboardMenu.create_page()
        elif self.choice == 6:
            JoystickMenu.create_page()
        elif self.choice == 7:
            sge.joystick.refresh()
            play_sound(hammer_throw_sound)
            OptionsMenu.create_page(default=self.choice)
        else:
            MainMenu.create(default=1)


class KeyboardMenu(Menu):

    page = 0

    @classmethod
    def create_page(cls, default=0, page=0):
        page %= min(len(left_key), len(right_key), len(up_key), len(down_key),
                    len(action_key), len(pause_key))
        cls.items = ["Player {}".format(page + 1),
                     "Left: {}".format(left_key[page]),
                     "Right: {}".format(right_key[page]),
                     "Up: {}".format(up_key[page]),
                     "Down: {}".format(down_key[page]),
                     "Action: {}".format(action_key[page]),
                     "Pause: {}".format(pause_key[page]),
                     "Back"]
        self = cls.create(default)
        self.page = page
        return self

    def event_choose(self):
        if self.choice == 0:
            KeyboardMenu.create_page(default=self.choice, page=(self.page + 1))
        elif self.choice == 1:
            k = wait_key()
            if k is not None:
                left_key[self.page] = k
            KeyboardMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 2:
            k = wait_key()
            if k is not None:
                right_key[self.page] = k
            KeyboardMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 3:
            k = wait_key()
            if k is not None:
                up_key[self.page] = k
            KeyboardMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 4:
            k = wait_key()
            if k is not None:
                down_key[self.page] = k
            KeyboardMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 5:
            k = wait_key()
            if k is not None:
                action_key[self.page] = k
            KeyboardMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 6:
            k = wait_key()
            if k is not None:
                pause_key[self.page] = k
            KeyboardMenu.create_page(default=self.choice, page=self.page)
        else:
            OptionsMenu.create_page(default=5)


class JoystickMenu(Menu):

    page = 0

    @classmethod
    def create_page(cls, default=0, page=0):
        page %= min(len(left_js), len(right_js), len(up_js), len(down_js),
                    len(action_js), len(pause_js))
        js_template = "Joystick {} {} {}"
        cls.items = ["Player {}".format(page + 1),
                     "Left: {}".format(js_template.format(*left_js[page])),
                     "Right: {}".format(js_template.format(*right_js[page])),
                     "Up: {}".format(js_template.format(*up_js[page])),
                     "Down: {}".format(js_template.format(*down_js[page])),
                     "Action: {}".format(js_template.format(*action_js[page])),
                     "Pause: {}".format(js_template.format(*pause_js[page])),
                     "Back"]
        self = cls.create(default)
        self.page = page
        return self

    def event_choose(self):
        if self.choice == 0:
            JoystickMenu.create_page(default=self.choice, page=(self.page + 1))
        elif self.choice == 1:
            js = wait_js()
            if js is not None:
                left_js[self.page] = js
            JoystickMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 2:
            js = wait_js()
            if js is not None:
                right_js[self.page] = js
            JoystickMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 3:
            js = wait_js()
            if js is not None:
                up_js[self.page] = js
            JoystickMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 4:
            js = wait_js()
            if js is not None:
                down_js[self.page] = js
            JoystickMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 5:
            js = wait_js()
            if js is not None:
                action_js[self.page] = js
            JoystickMenu.create_page(default=self.choice, page=self.page)
        elif self.choice == 6:
            js = wait_js()
            if js is not None:
                pause_js[self.page] = js
            JoystickMenu.create_page(default=self.choice, page=self.page)
        else:
            OptionsMenu.create_page(default=6)


class ModalMenu(xsge_gui.MenuDialog):

    items = []

    @classmethod
    def create(cls, default=0):
        if cls.items:
            self = cls.from_text(
                gui_handler, sge.game.width / 2, sge.game.height / 2,
                cls.items, font_normal=font, color_normal=sge.Color("white"),
                color_selected=sge.Color("red"),
                background_color=sge.Color("black"), margin=4, halign="center",
                valign="middle")
            default %= len(self.widgets)
            self.keyboard_focused_widget = self.widgets[default]
            self.show()
            return self


class PauseMenu(ModalMenu):

    items = ["Continue", "Quit"]

    def event_choose(self):
        sge.Music.unpause()

        if self.choice == 1:
            sge.game.start_room.start()


def wait_key():
    # Wait for a key press and return it.
    while True:
        # Input events
        sge.game.pump_input()
        while sge.game.input_events:
            event = sge.game.input_events.pop(0)
            if isinstance(event, sge.input.KeyPress):
                sge.game.pump_input()
                sge.game.input_events = []
                if event.key == "escape":
                    return None
                else:
                    return event.key

        # Regulate speed
        sge.game.regulate_speed(fps=10)

        # Project text
        text = "Press the key you wish to use for this function, or Escape to cancel."
        sge.game.project_text(font, text, sge.game.width / 2,
                              sge.game.height / 2, width=sge.game.width,
                              height=sge.game.height,
                              color=sge.Color("white"),
                              halign="center", valign="middle")

        # Refresh
        sge.game.refresh()


def wait_js():
    # Wait for a joystick press and return it.
    while True:
        # Input events
        sge.game.pump_input()
        while sge.game.input_events:
            event = sge.game.input_events.pop(0)
            if isinstance(event, sge.input.KeyPress):
                if event.key == "escape":
                    sge.game.pump_input()
                    sge.game.input_events = []
                    return None
            elif isinstance(event, sge.input.JoystickAxisMove):
                if event.value > joystick_threshold:
                    sge.game.pump_input()
                    sge.game.input_events = []
                    return (event.js_id, "axis+", event.axis)
                elif event.value < -joystick_threshold:
                    sge.game.pump_input()
                    sge.game.input_events = []
                    return (event.js_id, "axis-", event.axis)
            elif isinstance(event, sge.input.JoystickHatMove):
                sge.game.pump_input()
                sge.game.input_events = []
                t = ("hatx+" if event.x > 0 else
                     "hatx-" if event.x < 0 else
                     "haty+" if event.y > 0 else
                     "haty-" if event.y < 0 else
                     None)
                if t is not None:
                    return (event.js_id, t, event.hat)
            elif isinstance(event, sge.input.JoystickButtonPress):
                sge.game.pump_input()
                sge.game.input_events = []
                return (event.js_id, "button", event.button)

        # Regulate speed
        sge.game.regulate_speed(fps=10)

        # Project text
        text = "Press the joystick button, axis, or hat direction you wish to use for this function, or Escape to cancel."
        sge.game.project_text(font, text, sge.game.width / 2,
                              sge.game.height / 2, width=sge.game.width,
                              height=sge.game.height,
                              color=sge.Color("white"),
                              halign="center", valign="middle")

        # Refresh
        sge.game.refresh()


def play_sound(sound, *args, **kwargs):
    if sound_enabled and sound:
        sound.play(*args, **kwargs)


def play_music(music, force_restart=False):
    """Play the given music file, starting with its start piece."""
    if music_enabled and music:
        music_object = loaded_music.get(music)
        if music_object is None:
            try:
                music_object = sge.Music(os.path.join(DATA, music))
            except IOError:
                sge.Music.clear_queue()
                sge.Music.stop()
                return
            else:
                loaded_music[music] = music_object

        name, ext = os.path.splitext(music)
        music_start = ''.join((name, "-start", ext))
        music_start_object = loaded_music.get(music_start)
        if music_start_object is None:
            try:
                music_start_object = sge.Music(os.path.join(DATA, music_start))
            except IOError:
                music_start_object = music_object
            else:
                loaded_music[music_start] = music_start_object

        if (force_restart or
                (not music_object.playing and not music_start_object.playing)):
            sge.Music.clear_queue()
            sge.Music.stop()
            music_start_object.play()
            music_object.queue(loops=None)
    else:
        sge.Music.clear_queue()
        sge.Music.stop()


Game(SCREEN_SIZE[0], SCREEN_SIZE[1], scale=2, fps=FPS,
     window_text="Kitten Command {}".format(__version__),
     window_icon=os.path.join(DATA, "icon.png"))
sge.game.scale = None

xsge_gui.init()
gui_handler = xsge_gui.Handler()

# Load sprites
fname = os.path.join(DATA, "cat_sheet.png")
cat_stand_sprite = sge.Sprite.from_tileset(
    fname, 0, 64, columns=8, width=64, height=64, origin_x=CAT_ORIGIN_X,
    origin_y=CAT_ORIGIN_Y, fps=CAT_FPS)
cat_stand_shoot_sprite = sge.Sprite.from_tileset(
    fname, 0, 128, columns=8, width=64, height=64, origin_x=CAT_ORIGIN_X,
    origin_y=CAT_ORIGIN_Y, fps=CAT_FPS)
cat_walk_sprite = sge.Sprite.from_tileset(
    fname, 0, 192, columns=8, width=64, height=64, origin_x=CAT_ORIGIN_X,
    origin_y=CAT_ORIGIN_Y, fps=CAT_FPS)
cat_walk_shoot_sprite = sge.Sprite.from_tileset(
    fname, 0, 256, columns=8, width=64, height=64, origin_x=CAT_ORIGIN_X,
    origin_y=CAT_ORIGIN_Y, fps=CAT_FPS)
cat_die_sprite = sge.Sprite.from_tileset(
    fname, 0, 512, columns=7, width=64, height=64, origin_x=CAT_ORIGIN_X,
    origin_y=CAT_ORIGIN_Y, fps=4)
cat_recover_sprite = sge.Sprite.from_tileset(
    fname, 448, 512, columns=2, width=64, height=64, origin_x=CAT_ORIGIN_X,
    origin_y=CAT_ORIGIN_Y, fps=4)
bullet_sprite = sge.Sprite("bullet", DATA, origin_x=1, origin_y=1,
                           bbox_x=-2, bbox_y=-2, bbox_width=5, bbox_height=5)
bullet_dead_sprite = sge.Sprite("bullet_dead", DATA, origin_x=2, origin_y=2)
brick_sprite = sge.Sprite("brick", DATA, transparent=False)
brick_shard_sprite = sge.Sprite("brick_shard", DATA)
goomba_sprite = sge.Sprite(
    "goomba", DATA, origin_x=8, origin_y=8, fps=3, bbox_x=-6, bbox_y=-7,
    bbox_width=12, bbox_height=14)
greenkoopa_sprite = sge.Sprite(
    "greenkoopa", DATA, origin_x=8, origin_y=19, fps=4, bbox_x=1, bbox_y=-17,
    bbox_width=8, bbox_height=25)
greenshell_sprite = sge.Sprite(
    "greenshell", DATA, origin_x=8, origin_y=8, bbox_x=-6, bbox_y=-7,
    bbox_width=10, bbox_height=14)
greenshelldash_sprite = sge.Sprite(
    "greenshelldash", DATA, origin_x=8, origin_y=8, fps=8, bbox_x=-6,
    bbox_y=-7, bbox_width=10, bbox_height=14)
redkoopa_sprite = sge.Sprite(
    "redkoopa", DATA, origin_x=8, origin_y=19, fps=6, bbox_x=1, bbox_y=-17,
    bbox_width=8, bbox_height=25)
redshell_sprite = sge.Sprite(
    "redshell", DATA, origin_x=8, origin_y=8, bbox_x=-6, bbox_y=-7,
    bbox_width=10, bbox_height=14)
redshelldash_sprite = sge.Sprite(
    "redshelldash", DATA, origin_x=8, origin_y=8, fps=8, bbox_x=-6, bbox_y=-7,
    bbox_width=10, bbox_height=14)
spiny_sprite = sge.Sprite(
    "spiny", DATA, origin_x=9, origin_y=9, fps=3, bbox_x=-7, bbox_y=-7,
    bbox_width=15, bbox_height=15)
hammerbro_sprite = sge.Sprite(
    "hammerbro", DATA, origin_x=17, origin_y=19, fps=3, bbox_x=-5, bbox_y=-1,
    bbox_width=11, bbox_height=23)
hammerbro_throw_sprite = sge.Sprite(
    "hammerbro_throw", DATA, origin_x=17, origin_y=19, fps=3, bbox_x=-5,
    bbox_y=-1, bbox_width=11, bbox_height=23)
hammer_sprite = sge.Sprite("hammer", DATA, origin_x=8, origin_y=8, fps=15,
                           bbox_x=-4, bbox_y=-4, bbox_width=8, bbox_height=8)


# Load backgrounds
layers = [sge.BackgroundLayer(
    sge.Sprite("background", DATA, transparent=False), 0, 0, -100000)]
background = sge.Background(layers, sge.Color((85, 170, 255)))

# Load fonts
chars = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-*!")
font_sprite = sge.Sprite("font", DATA)
font = sge.Font.from_sprite(font_sprite, chars, size=8)

# Load sounds
shoot_sound = sge.Sound(os.path.join(DATA, "shoot.wav"), volume=50)
enemy_hit_sound = sge.Sound(os.path.join(DATA, "enemy_hit.wav"), volume=50)
kick_sound = sge.Sound(os.path.join(DATA, "kick.wav"))
hammer_throw_sound = sge.Sound(os.path.join(DATA, "hammer_throw.wav"),
                               volume=50)
die_sound = sge.Sound(os.path.join(DATA, "die.wav"), volume=50)
brick_break_sound = sge.Sound(os.path.join(DATA, "brick_break.wav"))

# Load music
music = sge.Music(os.path.join(DATA, "music.mid"), volume=3)
loaded_music["music.mid"] = music
del music

# Create rooms
sge.game.start_room = TitleScreen()


sge.game.mouse.visible = False

if not os.path.exists(CONFIG):
    os.makedirs(CONFIG)

try:
    with open(os.path.join(CONFIG, "config.json")) as f:
        cfg = json.load(f)
except (IOError, ValueError):
    pass
else:
    highscores = list(cfg.get("highscores", highscores))
    fullscreen = cfg.get("fullscreen", fullscreen)
    sge.game.fullscreen = fullscreen
    sound_enabled = cfg.get("sound_enabled", sound_enabled)
    music_enabled = cfg.get("music_enabled", music_enabled)
    fps_enabled = cfg.get("fps_enabled", fps_enabled)
    joystick_threshold = cfg.get("joystick_threshold", joystick_threshold)
    xsge_gui.joystick_threshold = joystick_threshold

    keys_cfg = cfg.get("keys", {})
    left_key = keys_cfg.get("left", left_key)
    right_key = keys_cfg.get("right", right_key)
    up_key = keys_cfg.get("up", up_key)
    down_key = keys_cfg.get("down", down_key)
    action_key = keys_cfg.get("action", action_key)
    pause_key = keys_cfg.get("pause", pause_key)

    js_cfg = cfg.get("joystick", {})
    left_js = js_cfg.get("left", left_js)
    right_js = js_cfg.get("right", right_js)
    up_js = js_cfg.get("up", up_js)
    down_js = js_cfg.get("down", down_js)
    action_js = js_cfg.get("action", action_js)
    pause_js = js_cfg.get("pause", pause_js)


if __name__ == "__main__":
    try:
        sge.game.start()
    finally:
        keys_cfg = {"left": left_key, "right": right_key, "up": up_key,
                    "down": down_key, "action": action_key, "pause": pause_key}
        js_cfg = {"left": left_js, "right": right_js, "up": up_js,
                  "down": down_js, "action": action_js, "pause": pause_js}

        cfg = {"fullscreen": fullscreen, "sound_enabled": sound_enabled,
               "music_enabled": music_enabled, "fps_enabled": fps_enabled,
               "joystick_threshold": joystick_threshold, "keys": keys_cfg,
               "joystick": js_cfg, "highscores": highscores}

        with open(os.path.join(CONFIG, "config.json"), 'w') as f:
            json.dump(cfg, f, indent=4)
