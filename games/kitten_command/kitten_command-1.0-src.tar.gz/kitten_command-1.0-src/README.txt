Copyright (C) 2014, 2015 Julian Marchant <onpon4@riseup.net>

Copying and distribution of this file, with or without modification,
are permitted in any medium without royalty provided the copyright
notice and this notice are preserved.  This file is offered as-is,
without any warranty.

========================================================================


ABOUT KITTEN COMMAND

This is a little Mario fangame I've developed as a "secret Santa" gift
for Willsaber.

This is a simple game. The concept is: you are a Texan cat, and you need
to defend your homeland from a Koopa Kingdom invasion. Great inspiration
was taken from Missile Command, hence the name.


COPYRIGHT AND FAIR USE NOTICE

This game makes use of certain copyrighted works without the permission
of their copyright holders. These are small components of Super Mario
Bros 3, Super Mario Bros, the Japanese Super Mario Bros 2, and the NES
port of Contra; as well as the Mario Techno Remix by Paul Soh. More
details about these works can be found in data/LICENSES.

United States copyright law includes the doctrine of "fair use", which
allows use of copyrighted works without permission of the copyright
holders. See 17 U.S.C. § 107 for details. Unfortunately, fangames have
not been specifically tested in court, but it is my firm belief that my
use of these copyrighted works is fair use, based on the following
points:

1. Kitten Command is distributed entirely non-commercially. To be
   perfectly clear, this is not a primary foundation for my claim of
   fair use. I believe the use would still be fair use if it was
   commercial. Nonetheless, the fact that the use is non-commercial is
   worth mentioning.

2. The purpose of Kitten Command, as a whole, is entirely different from
   the purposes of the copyrighted works being used. Put another way,
   the use is transformative. As a result, the use does not diminish the
   potential market for or value of any of the copyrighted works used in
   any way. Kitten Command is not a replacement for any of these works.

3. Only the portions of the copyrighted works needed for Kitten Command
   are included in this distribution. The total amount of Super Mario
   Bros 3, Super Mario Bros, the Japanese Super Mario Bros 2, and the
   NES port of Contra used is small compared to the whole of the
   respective works.

4. The copyrighted works used are only small portions of Kitten Command
   as a whole.

Anyone wishing to redistribute Kitten Command has my permission to do
so; you will find that all of my work is released under libre licenses.
However, if you live outside of the United States, please check up on
the laws of your country regarding things like fair use and/or fair
dealing, as different jurisdictions have different rules regarding this.


HOW TO RUN

You will need the following dependencies:

- Python 2 (2.7 or later) or 3 (3.1 or later) <http://www.python.org>
- SGE Game Engine 0.22 or later <http://stellarengine.nongnu.org>

Once you have installed the dependencies, you can start Kitten Command
by running kitten_command.py. By default, it will use Python 3. To run
it with Python 2 instead, you can either change the shebang on line 1
from "python3" to "python2", or explicitly run the Python 2 executable,
e.g.:

    python2 kitten_command.py


HOW TO PLAY

Use the arrow keys and Enter to navigate the menus. By default, your
character is controlled by the arrow keys and Space. You can change the
controls in the Options menu.

The objective of the game is simple: shoot down the Koopa Kingdom
invaders, and prevent them from passing the brick wall behind you for as
long as you can. Try to get your score as high as possible. :)

Other controls:
- F11: Toggle fullscreen.
- Escape: Return to the title screen.
- Middle mouse button: Quit the game.

The middle mouse button quitting the game is meant to work around a bug
in Pygame which sometimes locks up the keyboard when toggling fullscreen
or changing the window size. See this post on the SGE blog for more
information:

https://savannah.nongnu.org/forum/forum.php?forum_id=8113
