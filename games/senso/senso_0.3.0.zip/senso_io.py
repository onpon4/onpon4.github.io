"""Senso I/O - File handling script
Copyright (c) 2010 Julian Marchant ("onpon4")

This file is part of Senso.

Senso is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Senso is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Senso.  If not, see <http://www.gnu.org/licenses/>.

Start Date:      July 1, 2010
Completion Date: September 6, 2010
Version:         1.1.0
Language:        Python 2.6
Dependencies:    None

"""

VERSION = (1,1,0,0)

import os

def read(fname):
    """Reads a standard Senso file and returns a dictionary containing the data.
    Returns a dictionary containing all objects listed in the Senso file in the
    following form:
        'name':[{'property1':value,'property2':value},{'property1':value}]
    The entry key is a string with the name of the object (defined in brackets).
    The entry value is a list containing all objects with that name. Each
    individual object is represented as a dictionary with properties of the
    object listed as shown.

    For increased flexibility, each property has an indicator letter at the
    beginning to signify what type of variable it is:

    i - integer
    f - float
    l - tuple
    s - string

    """

    objects = {}

    try:
        f = open(fname, 'r')
    except IOError:
        raise

    curobj = None
    props = {}

    line = f.readline()
    while line != '':
        line = line.strip() #remove whitespace (especially newlines)
        #Note the difference between the following and the previous check. In
        #the following check, it has been established that this is not the
        #end of a file. line can therefore only be null if this is a blank line
        #(i.e., only whitespace exists in it).
        if line != '' and line[0] !='#':
            if line[0] == '[' and line[-1] == ']':
                if line[1] == '/':
                    if curobj in objects:
                        objects[curobj].append(props)
                    else:
                        objects[curobj] = [props]
                    curobj = None
                    props = {}
                else:
                    curobj = line[1:-1]
            else:
                name = ''
                for i in xrange(0, len(line)):
                    if line[i] == '=':
                        val = line[i+1:]
                        break
                    else:
                        name = '{0}{1}'.format(name, line[i])

                if val[0] == '(':
                    rval = val.strip('()').split(',')
                    val = []
                    for i in rval:
                        n = float(i)
                        if n == int(n):
                            n = int(n)
                        val.append(n)
                        
                    props[name] = tuple(val)
                else:
                    try:
                        n = float(val)
                        if n == int(n):
                            n = int(n)
                        props[name] = n
                        
                    except ValueError:
                        props[name] = val

        line = f.readline()

    f.close()
    return objects

def write(fname, objects):
    """The inverse of the read funtion. Writes to a file in the same format.
    See read function for more info.

    """
    
    try:
        f = open(fname, 'w')
    except IOError:
        raise

    for i in objects.keys():
        for obj in objects[i]:
            f.write('[{0}]{1}'.format(i,os.linesep))
            for prop in obj.keys():
                f.write('{0}={1}{2}'.format(prop,obj[prop],os.linesep))
            f.write('[/{0}]{1}{1}'.format(i,os.linesep))

    f.close()

if __name__ == '__main__':
    write('c:\somefile.crap',{'dog':[{'size':5,'color':'red'},{'size':9,'color':'blue'}]})
