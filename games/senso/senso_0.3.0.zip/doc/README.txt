Thank you for downloading SENSO! This game is incomplete, but I
hope you enjoy the game as much as I do. :)

This is an open-source game, so I encourage anyone and everyone to edit
and redistribute this game. This game is written in Python, making it
very easy to read and edit.

To run the game, run either senso.py or senso.exe (depending on whether
you're using the source build or Windows build). To run the editor, run
either senso_editor.py or senso_editor.exe.

Requirements:
If you're running the game from the source, you need the following:
- Python version 2.6 (Python 2.7 may also work, but NOT Python 3.x)
- Pygame version 1.9 or later (for the game)
- wxPython version 2.8 or later (for the editor)

If you're running the Windows build, everything you need is included. You
also need the following DLLs in your WINDOWS\SYSTEM folder (most, if not
all, are probably already there):

OLEAUT32.dll
USER32.dll
SDL_ttf.dll
KERNEL32.dll
WINMM.DLL
WSOCK32.dll
ADVAPI32.dll
WS2_32.DLL
GDI32.dll
libogg-0.dll
ole32.dll
SHELL32.dll
gdiplus.dll
RPCRT4.dll

If any of these are missing, the game and/or editor will not work,
usually resulting in the game not even starting up. In that case, I 
recommend installing a version of Python, Pygame, and/or wxPython. This
usually causes the necessary DLLs to be installed to your machine.
Unfortunately, I don't know whether or not I have the right to distribute
those files, so I'm playing on the safe side for now. I will hopefully
have these DLLs distributed with the game in the future.

Controls:

Player 1:
    Arrows - move
    Right shift - shoot

Player 2:
    WASD - move
    Left Ctrl - shoot

Player 3:
    IJKL - move
    Space Bar - shoot

Player 4:
    Numpad 8,4,5,6 - move
    Numpad 0 - shoot

Controls can be customized via some editing of a file called controles.snf,
but only if you know the numeric values of the keyboard constants in
Pygame. I will add true control customization later; until then, only 4
working human players can be in a game. Luckily, this should be enough.

How to play:

    Before the game starts, you will be prompted in the command line to
    select a game. Enter the number provided for the game you want to play,
    or simply press Enter to play the default game.

    Gameplay is rather simple. Each player has a SHIP (controlled by the
    player) and 3 SENSO TURRETS which move back and forth and shoot
    at the opponent. Each ship has 10 HP, while each senso turret has
    5 HP. To win, you can either destroy all of the other player's senso
    turrets or destroy the other player's ship.

See HISTORY.txt for historical information.

See COPYING.txt for copyright information (GNU General Public License)

See TODO for a list of stuff that's needed to finish the game.

Be sure to visit back at http://onpon.co.nr/ for updates. :)


MANUALLY EDITING GAMES
---------------------------------------------------------------------

There may be times when the Senso Game Editor doesn't do what you need.
For example, it doesn't yet have functionality to delete games. You
might also accidentally run the Game Editor outside of the main Senso
directory, in which case you will have to manually list your game in
games.snf. Luckily, editing the game files is very easy.

All game files are nothing more than text files. You can use any text
editor to open them. They are also designed to be easy to read; in
fact, you can probably figure most of it out yourself. Basically,
there are objects, which are marked by a name surrounded in brackets
and the same name surrounded in brackets but with a slash in front
of the name. Contained in each object is a number of properties,
which are designated as "name=value".

There are 2 files you need to be concerned with: first is the special
file "games.snf", which tells Senso what your game is called and where
the game file is located. This file is very simple, containing a list
of objects called "game". Each "game" object has two properties: name,
which is the name displayed when the player selects a game in Senso,
and file, which is the file where all the game's information is
stored.

The second file is the file containing your game's settings. There are
three different object names: "settings", "ship", and "target".

Each game must have a single "settings" object. This object contains
all the general settings. It has 4 properties:
- screensize: This is the size of the screen, in pixels. Entered as
   "width,height".
- bgcolor: This is the color of the background, represented by 3
   numbers: Red, Green, and Blue.
- lncolor: This is the color of the line in the middle.
- fps: This is the maximum frame rate that the game should run at in
   frames per second. Higher numbers result in a smoother game;
   however, it does no good to set this higher than your moniter's
   refresh rate (often 60 Hz), since you won't see the difference.
   Set to 0 for no maximum.

Each game can also contain any number of "ship" and/or "target"
objects. "ship" objects represent ships, while "target" objects
represent Senso turrets.

The "ship" object has 8 properties:
- team: Either 0 (the team on the left) or 1 (the team on the right).
- human: Either 0 (AI controlled) or 1 (human controlled).
- position: The starting position of the ship. Entered as "X,Y".
- size: The size of the ship, in pixels. Entered as "width,height".
- speed: The speed of the ship, in pixels per second.
- numbullets: The maximum number of bullets this ship can shoot at
   once.
- bulletsize: The size of bullets the ship shoots. Entered as
   "width,height".
- color: The color of the ship and its bullets.

The "target" object has 10 properties:
- team: Either 0 (left team) or 1 (right team).
- position: The starting position of this Senso turret.
- size: The size of the Senso turret
- xspeed: The starting horizontal speed
- yspeed: The starting vertical speed
- color1: The color of the square part of the turret
- color2: The color of the circle in the middle of the turret, as
   well as the color of its bullets.
- bulletsize: The size of the turret's bullets
- shootwait: The amount of time in milliseconds the turret waits
   in between each shot
- shootfreq: The percent chance (entered as a decimal) that the
   turret will actually shoot each time the shootwait timer ticks.