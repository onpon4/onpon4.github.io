"""Senso Game Editor - GUI for creating Senso game configurations
Copyright (c) 2010 Julian Marchant ("onpon4")

This file is part of Senso.

Senso is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Senso is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Senso.  If not, see <http://www.gnu.org/licenses/>.


Start Date:      July 5, 2010
Completion Date: September 5, 2010
Version:         0.3.0
Language:        Python 2.6
Dependencies:    wxPython 2.8

"""

VERSION = (0,3,0,1)

import os, wx, senso_io as io

class Editor(wx.Frame):
    def __init__(self, parent, id):
        #Create initial blank game
        self.game = {'settings':[{'name':'Untitled', 'screensize':(800,600),
                                  'bgcolor':(0,0,0), 'lncolor':(0,255,0),
                                  'fps':60}], 'ship':[], 'target':[]}
        
        v1,v2,v3,v4 = VERSION
        cap = 'Senso Game Editor v{0}.{1}.{2}'.format(v1,v2,v3)
        wx.Frame.__init__(self, parent, id, cap, size=(480,480))
        tabs = wx.Notebook(self, -1, style=wx.NB_TOP)
        self.settings = SettingsPanel(tabs, self.game['settings'][0])
        self.ships = ShipsPanel(tabs, self.game['ship'])
        self.targets = TargetsPanel(tabs, self.game['target'])
        tabs.AddPage(self.settings, 'Settings')
        tabs.AddPage(self.ships, 'Ships')
        tabs.AddPage(self.targets, 'Targets')

        statusbar = self.CreateStatusBar()

        menubar = wx.MenuBar()
        filemenu = wx.Menu()
        helpmenu = wx.Menu()
        m = filemenu.Append(wx.NewId(), '&Save Game', 'Save changes to the current game')
        self.Bind(wx.EVT_MENU, self.OnSave, m)
        m = filemenu.Append(wx.NewId(), '&Load Game', 'Load a new game')
        self.Bind(wx.EVT_MENU, self.OnLoad, m)
        filemenu.AppendSeparator()
        m = filemenu.Append(wx.ID_EXIT, 'E&xit', 'Exit this program')
        self.Bind(wx.EVT_MENU, self.OnExit, m)
        menubar.Append(filemenu, '&File')
        menubar.Append(helpmenu, '&Help')
        self.SetMenuBar(menubar)

        self.Show(True)

    def OnSave(self, event):
        game = self.GetGame()
        filename = ''

        for i in game['settings'][0]['name']:
            #Only allow the following:
            # Numbers: 48-57
            # Lowercase letters: 97-122
            #Uppercase letters (65-90) converted to lowercase letters and
            #allowed (so it is case-insensitive)
            i = i.lower()
            
            if (ord(i) >= 48 and ord(i) <= 57) \
               or (ord(i) >= 97 and ord(i) <= 122):
                filename += i

        #Don't allow null filenames
        if filename == '':
            filename = '_'

        try:
            gameslist = io.read('games.snf')

            for i in xrange(0, len(gameslist['game'])):
                if game['settings'][0]['name'] == gameslist['game'][i]['name']:
                    dlg = wx.MessageDialog(self, 'A game with the name "{0}" already exists. \
Would you like to overwrite it?'.format(game['settings'][0]['name']), \
                                           'Replace game?', wx.YES|wx.NO)
                    if dlg.ShowModal() == wx.ID_YES:
                        del gameslist['game'][i]
                        break
                    else:
                        return

            fnames = []
            for i in gameslist['game']:
                fnames.append(i['file'])

            if '{0}.sng'.format(filename) in fnames:
                n = 0
                while '{0}{1}.sng'.format(filename,n) in fnames:
                    n += 1
                filename = '{0}{1}'.format(filename,n)

            filename = '{0}.sng'.format(filename)

            gameslist['game'].append({'name':game['settings'][0]['name'],
                                      'file':filename})

            io.write(os.path.join('games',filename), game)
            io.write('games.snf', gameslist)
                
        except IOError:
            filename = '{0}.sng'.format(filename)
            msg = 'The central games file, games.snf, was not found in "{0}". \
This is probably because this application is located in a different directory \
than Senso. Your game will be saved in the file "{1}". Please refer to \
README.txt (found with your copy of Senso) for manual file editing \
instructions.'.format(os.path.normpath(os.path.realpath('')), \
                      os.path.normpath(os.path.realpath(filename)))
            dlg = wx.MessageDialog(self, msg, 'Warning', wx.OK|wx.ICON_EXCLAMATION)
            dlg.ShowModal()
            dlg.Destroy()

            io.write(filename, game)

    def OnLoad(self, event):
        conf = wx.MessageDialog(self, 'Are you sure? Any unsaved changes will be lost.', \
                               'Load game?', wx.YES|wx.NO)
        if conf.ShowModal() == wx.ID_YES:
            try:
                gameslist = io.read('games.snf')
                names = []
                fnames = []

                for i in gameslist['game']:
                    names.append(i['name'])
                    fnames.append(i['file'])

                choice = wx.SingleChoiceDialog(self, 'Choose the game to load:', \
                                               'Game Selector', names)
                if choice.ShowModal() == wx.ID_OK:
                    newgame = io.read(os.path.join('games', fnames[choice.GetSelection()]))
                    self.SetGame(newgame)

            except IOError:
                err = wx.MessageDialog(self, 'The central games file, games.snf, was not found in "{0}".'.format(os.path.normpath(os.path.realpath(''))), \
                                       'Error', wx.OK|wx.ICON_EXCLAMATION)
                err.ShowModal()
                err.Destroy()

        conf.Destroy()

    def OnExit(self, event):
        self.Close(1)

    def GetGame(self):
        return {'settings':[self.settings.sets], 'ship':self.ships.ships, \
                'target':self.targets.targets}

    def SetGame(self, game):
        self.settings.sets = game['settings'][0]
        self.ships.ships = game['ship']
        self.targets.targets = game['target']

        self.settings.Refresh()
        self.ships.Refresh()
        self.targets.Refresh()

class SettingsPanel(wx.Panel):
    def __init__(self, parent, sets):
        wx.Panel.__init__(self, parent)

        self.sets = sets

        hbox0 = wx.BoxSizer(wx.HORIZONTAL) #This was added later, so I lazily numbered it 0
        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        hbox2 = wx.BoxSizer(wx.HORIZONTAL)
        hbox3 = wx.BoxSizer(wx.HORIZONTAL)
        hbox4 = wx.BoxSizer(wx.HORIZONTAL)
        vbox = wx.BoxSizer(wx.VERTICAL)

        label = wx.StaticText(self, -1, 'Name:', size=(120,-1))
        self.sttName = wx.StaticText(self, -1, '')
        self.btnName = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnName, self.btnName)
        hbox0.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox0.AddStretchSpacer()
        hbox0.Add(self.sttName, 0, wx.ALIGN_CENTER)
        hbox0.AddStretchSpacer()
        hbox0.Add(self.btnName, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)
        
        label = wx.StaticText(self, -1, 'Screen Size:', size=(120,-1))
        self.sttScreenSize = wx.StaticText(self, -1, '')
        self.btnScreenSize = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnScreenSize, self.btnScreenSize)
        hbox1.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox1.AddStretchSpacer()
        hbox1.Add(self.sttScreenSize, 0, wx.ALIGN_CENTER)
        hbox1.AddStretchSpacer()
        hbox1.Add(self.btnScreenSize, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)
        
        label = wx.StaticText(self, -1, 'Background Color:', size=(120,-1))
        self.pnlBackgroundColor = wx.Panel(self, -1, size=(32,16))
        self.btnBackgroundColor = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON,self.OnBackgroundColor,self.btnBackgroundColor)
        hbox2.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox2.AddStretchSpacer()
        hbox2.Add(self.pnlBackgroundColor, 0, wx.ALIGN_CENTER)
        hbox2.AddStretchSpacer()
        hbox2.Add(self.btnBackgroundColor, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Line Color:', size=(120,-1))
        self.pnlLineColor = wx.Panel(self, -1, size=(32,16))
        self.btnLineColor = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnLineColor, self.btnLineColor)
        hbox3.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox3.AddStretchSpacer()
        hbox3.Add(self.pnlLineColor, 0, wx.ALIGN_CENTER)
        hbox3.AddStretchSpacer()
        hbox3.Add(self.btnLineColor, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Frame Rate:', size=(120,-1))
        self.sttFrameRate = wx.StaticText(self, -1, '')
        self.btnFrameRate = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnFrameRate, self.btnFrameRate)
        hbox4.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox4.AddStretchSpacer()
        hbox4.Add(self.sttFrameRate, 0, wx.ALIGN_CENTER)
        hbox4.AddStretchSpacer()
        hbox4.Add(self.btnFrameRate, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        vbox.Add(hbox0, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.TOP|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox.Add(hbox1, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox.Add(hbox2, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox.Add(hbox3, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox.Add(hbox4, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)

        self.SetSizer(vbox)
        self.Refresh()

    def OnName(self, event):
        dlg = wx.TextEntryDialog(self, 'Enter a new name for this game:', 'Name')
        dlg.SetValue(self.sets['name'])
        if dlg.ShowModal() == wx.ID_OK:
            self.sets['name'] = dlg.GetValue()
            self.Refresh()
        dlg.Destroy()

    def OnScreenSize(self, event):
        self.sets['screensize'] = ChangeSize(self, 'Enter the new screen size:', 'Screen Size', self.sets['screensize'])
        self.Refresh()

    def OnBackgroundColor(self, event):
        dlg = wx.ColourDialog(self)
        if dlg.ShowModal() == wx.ID_OK:
            data = dlg.GetColourData()
            self.sets['bgcolor'] = data.GetColour()
        dlg.Destroy()
        self.Refresh()

    def OnLineColor(self, event):
        dlg = wx.ColourDialog(self)
        if dlg.ShowModal() == wx.ID_OK:
            data = dlg.GetColourData()
            self.sets['lncolor'] = data.GetColour()
        dlg.Destroy()
        self.Refresh()

    def OnFrameRate(self, event):
        self.sets['fps'] = ChangeInt(self, 'Enter the new frame rate (FPS):', 'Frame Rate', self.sets['fps'])
        self.Refresh()

    def Refresh(self):
        t = self.sets['name']
        self.sttName.SetLabel(t)
        
        t = '{0}x{1}'.format(self.sets['screensize'][0], self.sets['screensize'][1])
        self.sttScreenSize.SetLabel(t)

        r,g,b = self.sets['bgcolor']
        self.pnlBackgroundColor.SetBackgroundColour(wx.Colour(r,g,b))
        self.pnlBackgroundColor.ClearBackground()

        r,g,b = self.sets['lncolor']
        self.pnlLineColor.SetBackgroundColour(wx.Colour(r,g,b))
        self.pnlLineColor.ClearBackground()

        t = '{0} FPS'.format(self.sets['fps'])
        self.sttFrameRate.SetLabel(t)

        self.Layout()

class ShipsPanel(wx.Panel):
    def __init__(self, parent, ships):
        wx.Panel.__init__(self, parent)

        self.ships = ships
        self.selectedship = -1

        hbox = wx.BoxSizer(wx.HORIZONTAL)
        vbox1 = wx.BoxSizer(wx.VERTICAL)
        vbox2 = wx.BoxSizer(wx.VERTICAL)
        hbox21 = wx.BoxSizer(wx.HORIZONTAL)
        hbox22 = wx.BoxSizer(wx.HORIZONTAL)
        hbox23 = wx.BoxSizer(wx.HORIZONTAL)
        hbox24 = wx.BoxSizer(wx.HORIZONTAL)
        hbox25 = wx.BoxSizer(wx.HORIZONTAL)
        hbox26 = wx.BoxSizer(wx.HORIZONTAL)
        hbox27 = wx.BoxSizer(wx.HORIZONTAL)
        hbox28 = wx.BoxSizer(wx.HORIZONTAL)
        
        n = 0
        names = []
        for i in self.ships: n += 1
        for i in xrange(0,n): names.append('Ship {0}'.format(i+1))
        self.lstShips = wx.ListBox(self, -1, (5,5), size=(90,200), choices=names, style=wx.LB_SINGLE)
        self.Bind(wx.EVT_LISTBOX, self.OnSelectShip, self.lstShips)
        
        self.btnNewShip = wx.Button(self, -1, 'New', (5,215))
        self.Bind(wx.EVT_BUTTON, self.OnNewShip, self.btnNewShip)
        
        self.btnCopyShip = wx.Button(self, -1, 'Copy', (5,244))
        self.Bind(wx.EVT_BUTTON, self.OnCopyShip, self.btnCopyShip)
        self.btnCopyShip.Enable(0)
        
        self.btnDeleteShip = wx.Button(self, -1, 'Delete', (5,273))
        self.Bind(wx.EVT_BUTTON, self.OnDeleteShip, self.btnDeleteShip)
        self.btnDeleteShip.Enable(0)
        
        vbox1.Add(self.lstShips, 5, wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_TOP|wx.TOP, 5)
        vbox1.Add(self.btnNewShip, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.TOP, 5)
        vbox1.Add(self.btnCopyShip, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.TOP, 5)
        vbox1.Add(self.btnDeleteShip, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_BOTTOM|wx.TOP|wx.BOTTOM, 5)

        label = wx.StaticText(self, -1, 'Team:', size=(120,-1))
        self.sttShipTeam = wx.StaticText(self, -1, '')
        self.btnShipTeam = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnShipTeam, self.btnShipTeam)
        self.btnShipTeam.Enable(0)
        hbox21.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox21.AddStretchSpacer()
        hbox21.Add(self.sttShipTeam, 0, wx.ALIGN_CENTER)
        hbox21.AddStretchSpacer()
        hbox21.Add(self.btnShipTeam, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Controller:', size=(120,-1))
        self.sttShipController = wx.StaticText(self, -1, '')
        self.btnShipController = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnShipController, self.btnShipController)
        self.btnShipController.Enable(0)
        hbox22.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox22.AddStretchSpacer()
        hbox22.Add(self.sttShipController, 0, wx.ALIGN_CENTER)
        hbox22.AddStretchSpacer()
        hbox22.Add(self.btnShipController, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Position:', size=(120,-1))
        self.sttShipPosition = wx.StaticText(self, -1, '')
        self.btnShipPosition = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnShipPosition, self.btnShipPosition)
        self.btnShipPosition.Enable(0)
        hbox23.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox23.AddStretchSpacer()
        hbox23.Add(self.sttShipPosition, 0, wx.ALIGN_CENTER)
        hbox23.AddStretchSpacer()
        hbox23.Add(self.btnShipPosition, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Size:', size=(120,-1))
        self.sttShipSize = wx.StaticText(self, -1, '')
        self.btnShipSize = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnShipSize, self.btnShipSize)
        self.btnShipSize.Enable(0)
        hbox24.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox24.AddStretchSpacer()
        hbox24.Add(self.sttShipSize, 0, wx.ALIGN_CENTER)
        hbox24.AddStretchSpacer()
        hbox24.Add(self.btnShipSize, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Speed:', size=(120,-1))
        self.sttShipSpeed = wx.StaticText(self, -1, '')
        self.btnShipSpeed = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnShipSpeed, self.btnShipSpeed)
        self.btnShipSpeed.Enable(0)
        hbox25.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox25.AddStretchSpacer()
        hbox25.Add(self.sttShipSpeed, 0, wx.ALIGN_CENTER)
        hbox25.AddStretchSpacer()
        hbox25.Add(self.btnShipSpeed, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Max bullets:', size=(120,-1))
        self.sttShipNumBullets = wx.StaticText(self, -1, '')
        self.btnShipNumBullets = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnShipNumBullets, self.btnShipNumBullets)
        self.btnShipNumBullets.Enable(0)
        hbox26.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox26.AddStretchSpacer()
        hbox26.Add(self.sttShipNumBullets, 0, wx.ALIGN_CENTER)
        hbox26.AddStretchSpacer()
        hbox26.Add(self.btnShipNumBullets, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Bullet size:', size=(120,-1))
        self.sttShipBulletSize = wx.StaticText(self, -1, '')
        self.btnShipBulletSize = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnShipBulletSize, self.btnShipBulletSize)
        self.btnShipBulletSize.Enable(0)
        hbox27.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox27.AddStretchSpacer()
        hbox27.Add(self.sttShipBulletSize, 0, wx.ALIGN_CENTER)
        hbox27.AddStretchSpacer()
        hbox27.Add(self.btnShipBulletSize, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Color:', size=(120,-1))
        self.pnlShipColor = wx.Panel(self, -1, size=(32,16))
        self.btnShipColor = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnShipColor, self.btnShipColor)
        self.btnShipColor.Enable(0)
        hbox28.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox28.AddStretchSpacer()
        hbox28.Add(self.pnlShipColor, 0, wx.ALIGN_CENTER)
        hbox28.AddStretchSpacer()
        hbox28.Add(self.btnShipColor, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        vbox2.Add(hbox21, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.TOP|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox22, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox23, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox24, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox25, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox26, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox27, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox28, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.BOTTOM|wx.ALIGN_CENTER_HORIZONTAL, 5)
        hbox.Add(vbox1, 1, wx.EXPAND)
        hbox.Add(vbox2, 3, wx.EXPAND)

        self.SetSizer(hbox)
        self.Refresh()

    def OnSelectShip(self, event):
        self.selectedship = event.GetSelection()

        self.Refresh()

    def OnNewShip(self, event):
        self.ships.append({'team':0, 'human':1, 'position':(0,0), \
                                  'size':(24,24), 'speed':400, 'numbullets':2, \
                                  'bulletsize':(8,3), 'color':(0,255,0)})

        n = len(self.ships)
        self.lstShips.Append('Ship {0}'.format(n))
        
        self.lstShips.SetSelection(n-1)
        self.selectedship = n-1
        self.Refresh()

    def OnCopyShip(self, event):
        self.ships.append(self.ships[self.selectedship].copy())

        n = len(self.ships)
        self.lstShips.Append('Ship {0}'.format(n))
        
        self.lstShips.SetSelection(n-1)
        self.selectedship = n-1
        self.Refresh()

    def OnDeleteShip(self, event):
        del self.ships[self.selectedship]

        self.Refresh()

    def OnShipTeam(self, event):
        dlg = wx.SingleChoiceDialog(self, 'Which team should this ship be on?', \
                                    'Team selector', ['Team 1', 'Team 2'])
        if dlg.ShowModal() == wx.ID_OK:
            self.ships[self.selectedship]['team'] = dlg.GetSelection()
        dlg.Destroy()

        self.Refresh()

    def OnShipController(self, event):
        dlg = wx.SingleChoiceDialog(self, 'Who will control this ship?', \
                                    'Controller', ['Robot', 'Human'])
        if dlg.ShowModal() == wx.ID_OK:
            self.ships[self.selectedship]['human'] = dlg.GetSelection()
        dlg.Destroy()

        self.Refresh()

    def OnShipPosition(self, event):
        self.ships[self.selectedship]['position'] = ChangePosition(self, 'Enter the new position:', 'Ship Position', self.ships[self.selectedship]['position'])
        self.Refresh()

    def OnShipSize(self, event):
        self.ships[self.selectedship]['size'] = ChangeSize(self, 'Enter the new size:', 'Ship Size', self.ships[self.selectedship]['size'])
        self.Refresh()

    def OnShipSpeed(self, event):
        self.ships[self.selectedship]['speed'] = ChangeInt(self, 'Enter the new ship speed:', 'Ship Speed', self.ships[self.selectedship]['speed'])
        self.Refresh()

    def OnShipNumBullets(self, event):
        self.ships[self.selectedship]['numbullets'] = ChangeInt(self, 'Enter the new bullet limit:', 'Bullet Limit', self.ships[self.selectedship]['numbullets'])
        self.Refresh()

    def OnShipBulletSize(self, event):
        self.ships[self.selectedship]['bulletsize'] = ChangeSize(self, 'Enter the new bullet size:', 'Bullet Size', self.ships[self.selectedship]['bulletsize'])
        self.Refresh()

    def OnShipColor(self, event):
        dlg = wx.ColourDialog(self)
        if dlg.ShowModal() == wx.ID_OK:
            data = dlg.GetColourData()
            self.ships[self.selectedship]['color'] = data.GetColour()
        dlg.Destroy()
        self.Refresh()

    def Refresh(self):
        #Grab selection to retain it in gtk2
        select = self.selectedship
        
        #Refresh listbox
        self.lstShips.Clear()
        for i in xrange(0, len(self.ships)):
            self.lstShips.Append('Ship {0}'.format(i+1))

        #Restore selected ship
        self.selectedship = select

        #Don't allow out-of-index selections
        if self.selectedship >= len(self.ships):
            self.selectedship -= 1

        if self.selectedship != -1:
            self.lstShips.SetSelection(self.selectedship)
            
            shipdata = self.ships[self.selectedship]

            teamstr = 'Team {0}'.format(str(shipdata['team'] + 1))
            if shipdata['human']:
                constr = 'Human'
            else:
                constr = 'Robot'
            posstr = '({0},{1})'.format(shipdata['position'][0],shipdata['position'][1])
            sizestr = '{0}x{1}'.format(shipdata['size'][0],shipdata['size'][1])
            speedstr = str(shipdata['speed'])
            numbulstr = str(shipdata['numbullets'])
            bulsizestr = '{0}x{1}'.format(shipdata['bulletsize'][0], shipdata['bulletsize'][1])

            self.sttShipTeam.SetLabel(teamstr)
            self.sttShipController.SetLabel(constr)
            self.sttShipPosition.SetLabel(posstr)
            self.sttShipSize.SetLabel(sizestr)
            self.sttShipSpeed.SetLabel(speedstr)
            self.sttShipNumBullets.SetLabel(numbulstr)
            self.sttShipBulletSize.SetLabel(bulsizestr)
            
            r,g,b = shipdata['color']
            self.pnlShipColor.SetBackgroundColour(wx.Colour(r,g,b))
            self.pnlShipColor.ClearBackground()
            
            self.btnCopyShip.Enable(1)
            self.btnDeleteShip.Enable(1)
            self.btnShipTeam.Enable(1)
            self.btnShipController.Enable(1)
            self.btnShipPosition.Enable(1)
            self.btnShipSize.Enable(1)
            self.btnShipSpeed.Enable(1)
            self.btnShipNumBullets.Enable(1)
            self.btnShipBulletSize.Enable(1)
            self.btnShipColor.Enable(1)

        else:
            self.sttShipTeam.SetLabel('')
            self.sttShipController.SetLabel('')
            self.sttShipPosition.SetLabel('')
            self.sttShipSize.SetLabel('')
            self.sttShipSpeed.SetLabel('')
            self.sttShipNumBullets.SetLabel('')
            self.sttShipBulletSize.SetLabel('')
            self.pnlShipColor.SetBackgroundColour(wx.NullColour)
            self.pnlShipColor.ClearBackground()

            self.btnCopyShip.Enable(0)
            self.btnDeleteShip.Enable(0)
            self.btnShipTeam.Enable(0)
            self.btnShipController.Enable(0)
            self.btnShipPosition.Enable(0)
            self.btnShipSize.Enable(0)
            self.btnShipSpeed.Enable(0)
            self.btnShipNumBullets.Enable(0)
            self.btnShipBulletSize.Enable(0)
            self.btnShipColor.Enable(0)

        self.Layout()

class TargetsPanel(wx.Panel):
    def __init__(self, parent, targets):
        wx.Panel.__init__(self, parent)

        self.targets = targets
        self.selectedtarget = -1

        hbox = wx.BoxSizer(wx.HORIZONTAL)
        vbox1 = wx.BoxSizer(wx.VERTICAL)
        vbox2 = wx.BoxSizer(wx.VERTICAL)
        hbox21 = wx.BoxSizer(wx.HORIZONTAL)
        hbox22 = wx.BoxSizer(wx.HORIZONTAL)
        hbox23 = wx.BoxSizer(wx.HORIZONTAL)
        hbox24 = wx.BoxSizer(wx.HORIZONTAL)
        hbox25 = wx.BoxSizer(wx.HORIZONTAL)
        hbox26 = wx.BoxSizer(wx.HORIZONTAL)
        hbox27 = wx.BoxSizer(wx.HORIZONTAL)
        hbox28 = wx.BoxSizer(wx.HORIZONTAL)
        hbox29 = wx.BoxSizer(wx.HORIZONTAL)
        hbox2a = wx.BoxSizer(wx.HORIZONTAL)
        
        names = []
        n = len(self.targets)
        for i in xrange(0,n): names.append('Target {0}'.format(i+1))
        self.lstTargets = wx.ListBox(self, -1, (5,5), size=(90,200), choices=names, style=wx.LB_SINGLE)
        self.Bind(wx.EVT_LISTBOX, self.OnSelectTarget, self.lstTargets)

        self.btnNewTarget = wx.Button(self, -1, 'New', (5,215))
        self.Bind(wx.EVT_BUTTON, self.OnNewTarget, self.btnNewTarget)

        self.btnCopyTarget = wx.Button(self, -1, 'Copy', (5,244))
        self.Bind(wx.EVT_BUTTON, self.OnCopyTarget, self.btnCopyTarget)
        self.btnCopyTarget.Enable(0)

        self.btnDeleteTarget = wx.Button(self, -1, 'Delete', (5,273))
        self.Bind(wx.EVT_BUTTON, self.OnDeleteTarget, self.btnDeleteTarget)
        self.btnDeleteTarget.Enable(0)

        vbox1.Add(self.lstTargets, 5, wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_TOP|wx.TOP, 5)
        vbox1.Add(self.btnNewTarget, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.TOP, 5)
        vbox1.Add(self.btnCopyTarget, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.TOP, 5)
        vbox1.Add(self.btnDeleteTarget, 0, wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_BOTTOM|wx.TOP|wx.BOTTOM, 5)

        label = wx.StaticText(self, -1, 'Team:', size=(120,-1))
        self.sttTargetTeam = wx.StaticText(self, -1, '')
        self.btnTargetTeam = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetTeam, self.btnTargetTeam)
        self.btnTargetTeam.Enable(0)
        hbox21.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox21.AddStretchSpacer()
        hbox21.Add(self.sttTargetTeam, 0, wx.ALIGN_CENTER)
        hbox21.AddStretchSpacer()
        hbox21.Add(self.btnTargetTeam, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Position:', size=(120,-1))
        self.sttTargetPosition = wx.StaticText(self, -1, '')
        self.btnTargetPosition = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetPosition, self.btnTargetPosition)
        self.btnTargetPosition.Enable(0)
        hbox22.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox22.AddStretchSpacer()
        hbox22.Add(self.sttTargetPosition, 0, wx.ALIGN_CENTER)
        hbox22.AddStretchSpacer()
        hbox22.Add(self.btnTargetPosition, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Size:', size=(120,-1))
        self.sttTargetSize = wx.StaticText(self, -1, '')
        self.btnTargetSize = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetSize, self.btnTargetSize)
        self.btnTargetSize.Enable(0)
        hbox23.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox23.AddStretchSpacer()
        hbox23.Add(self.sttTargetSize, 0, wx.ALIGN_CENTER)
        hbox23.AddStretchSpacer()
        hbox23.Add(self.btnTargetSize, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Horizontal Speed:', size=(120,-1))
        self.sttTargetSpeedX = wx.StaticText(self, -1, '')
        self.btnTargetSpeedX = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetSpeedX, self.btnTargetSpeedX)
        self.btnTargetSpeedX.Enable(0)
        hbox24.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox24.AddStretchSpacer()
        hbox24.Add(self.sttTargetSpeedX, 0, wx.ALIGN_CENTER)
        hbox24.AddStretchSpacer()
        hbox24.Add(self.btnTargetSpeedX, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Vertical Speed:', size=(120,-1))
        self.sttTargetSpeedY = wx.StaticText(self, -1, '')
        self.btnTargetSpeedY = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetSpeedY, self.btnTargetSpeedY)
        self.btnTargetSpeedY.Enable(0)
        hbox25.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox25.AddStretchSpacer()
        hbox25.Add(self.sttTargetSpeedY, 0, wx.ALIGN_CENTER)
        hbox25.AddStretchSpacer()
        hbox25.Add(self.btnTargetSpeedY, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Back Color:', size=(120,-1))
        self.pnlTargetColor1 = wx.Panel(self, -1, size=(32,16))
        self.btnTargetColor1 = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetColor1, self.btnTargetColor1)
        self.btnTargetColor1.Enable(0)
        hbox26.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox26.AddStretchSpacer()
        hbox26.Add(self.pnlTargetColor1, 0, wx.ALIGN_CENTER)
        hbox26.AddStretchSpacer()
        hbox26.Add(self.btnTargetColor1, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Front Color:', size=(120,-1))
        self.pnlTargetColor2 = wx.Panel(self, -1, size=(32,16))
        self.btnTargetColor2 = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetColor2, self.btnTargetColor2)
        self.btnTargetColor2.Enable(0)
        hbox27.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox27.AddStretchSpacer()
        hbox27.Add(self.pnlTargetColor2, 0, wx.ALIGN_CENTER)
        hbox27.AddStretchSpacer()
        hbox27.Add(self.btnTargetColor2, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Bullet Size:', size=(120,-1))
        self.sttTargetBulletSize = wx.StaticText(self, -1, '')
        self.btnTargetBulletSize = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetBulletSize, self.btnTargetBulletSize)
        self.btnTargetBulletSize.Enable(0)
        hbox28.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox28.AddStretchSpacer()
        hbox28.Add(self.sttTargetBulletSize, 0, wx.ALIGN_CENTER)
        hbox28.AddStretchSpacer()
        hbox28.Add(self.btnTargetBulletSize, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Shoot Delay:', size=(120,-1))
        self.sttTargetShootWait = wx.StaticText(self, -1, '')
        self.btnTargetShootWait = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetShootWait, self.btnTargetShootWait)
        self.btnTargetShootWait.Enable(0)
        hbox29.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox29.AddStretchSpacer()
        hbox29.Add(self.sttTargetShootWait, 0, wx.ALIGN_CENTER)
        hbox29.AddStretchSpacer()
        hbox29.Add(self.btnTargetShootWait, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        label = wx.StaticText(self, -1, 'Shoot Frequency:', size=(120,-1))
        self.sttTargetShootFreq = wx.StaticText(self, -1, '')
        self.btnTargetShootFreq = wx.Button(self, -1, 'Change')
        self.Bind(wx.EVT_BUTTON, self.OnTargetShootFreq, self.btnTargetShootFreq)
        self.btnTargetShootFreq.Enable(0)
        hbox2a.Add(label, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL)
        hbox2a.AddStretchSpacer()
        hbox2a.Add(self.sttTargetShootFreq, 0, wx.ALIGN_CENTER)
        hbox2a.AddStretchSpacer()
        hbox2a.Add(self.btnTargetShootFreq, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL)

        vbox2.Add(hbox21, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.TOP|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox22, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox23, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox24, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox25, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox26, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox27, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox28, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox29, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5)
        vbox2.Add(hbox2a, 1, wx.LEFT|wx.RIGHT|wx.EXPAND|wx.BOTTOM|wx.ALIGN_CENTER_HORIZONTAL, 5)
        hbox.Add(vbox1, 1, wx.EXPAND)
        hbox.Add(vbox2, 3, wx.EXPAND)

        self.SetSizer(hbox)
        self.Layout()

    def OnSelectTarget(self, event):
        self.selectedtarget = event.GetSelection()
        self.Refresh()

    def OnNewTarget(self, event):
        self.targets.append({'team':0, 'position':(0,0), 'size':(32,32), \
                             'xspeed':0, 'yspeed':0, 'color1':(0,0,0), \
                             'color2':(0,255,0), 'bulletsize':(8,3), \
                             'shootwait':1000, 'shootfreq':0.2})
        n = len(self.targets)
        self.lstTargets.Append('Target {0}'.format(n))

        self.lstTargets.SetSelection(n-1)
        self.selectedtarget = n-1
        self.Refresh()

    def OnCopyTarget(self, event):
        self.targets.append(self.targets[self.selectedtarget].copy())

        n = len(self.targets)
        self.lstTargets.Append('Target {0}'.format(n))

        self.lstTargets.SetSelection(n-1)
        self.selectedtarget = n-1
        self.Refresh()

    def OnDeleteTarget(self, event):
        del self.targets[self.selectedtarget]

        self.Refresh()

    def OnTargetTeam(self, event):
        dlg = wx.SingleChoiceDialog(self, 'Which team should this target be on?', \
                                    'Team selector', ['Team 1', 'Team 2'])
        if dlg.ShowModal() == wx.ID_OK:
            self.targets[self.selectedtarget]['team'] = dlg.GetSelection()
        dlg.Destroy()

        self.Refresh()

    def OnTargetPosition(self, event):
        self.targets[self.selectedtarget]['position'] = ChangePosition(self, 'Enter the new position:', 'Target Position', self.targets[self.selectedtarget]['position'])
        self.Refresh()

    def OnTargetSize(self, event):
        self.targets[self.selectedtarget]['size'] = ChangeSize(self, 'Enter the new size:', 'Target Size', self.targets[self.selectedtarget]['size'])
        self.Refresh()

    def OnTargetSpeedX(self, event):
        self.targets[self.selectedtarget]['xspeed'] = ChangeInt(self, 'Enter the new horizontal speed:', 'Horizontal Speed', self.targets[self.selectedtarget]['xspeed'])
        self.Refresh()

    def OnTargetSpeedY(self, event):
        self.targets[self.selectedtarget]['yspeed'] = ChangeInt(self, 'Enter the new vertical speed:', 'Vertical Speed', self.targets[self.selectedtarget]['yspeed'])
        self.Refresh()

    def OnTargetColor1(self, event):
        dlg = wx.ColourDialog(self)
        if dlg.ShowModal() == wx.ID_OK:
            data = dlg.GetColourData()
            self.targets[self.selectedtarget]['color1'] = data.GetColour()
        dlg.Destroy()
        self.Refresh()

    def OnTargetColor2(self, event):
        dlg = wx.ColourDialog(self)
        if dlg.ShowModal() == wx.ID_OK:
            data = dlg.GetColourData()
            self.targets[self.selectedtarget]['color2'] = data.GetColour()
        dlg.Destroy()
        self.Refresh()

    def OnTargetBulletSize(self, event):
        self.targets[self.selectedtarget]['bulletsize'] = ChangeSize(self, 'Enter the new bullet size:', 'Bullet Size', self.targets[self.selectedtarget]['bulletsize'])
        self.Refresh()

    def OnTargetShootWait(self, event):
        self.targets[self.selectedtarget]['shootwait'] = ChangeInt(self, 'Enter the new shoot wait:', 'Shoot Wait', self.targets[self.selectedtarget]['shootwait'])
        self.Refresh()

    def OnTargetShootFreq(self, event):
        self.targets[self.selectedtarget]['shootfreq'] = ChangePercent(self, 'Enter the new shoot frequency:', 'Shoot Frequency', self.targets[self.selectedtarget]['shootfreq'])
        self.Refresh()

    def Refresh(self):
        #Retain selection
        select = self.selectedtarget
        
        #Refresh listbox
        self.lstTargets.Clear()
        n = len(self.targets)
        for i in xrange(0,n):
            self.lstTargets.Append('Target {0}'.format(i+1))

        self.selectedtarget = select

        #Don't allow out-of-index selections
        if self.selectedtarget >= n:
            self.selectedtarget -= 1

        if self.selectedtarget != -1:
            self.lstTargets.SetSelection(self.selectedtarget)
            
            targetdata = self.targets[self.selectedtarget]

            teamstr = 'Team {0}'.format(str(targetdata['team'] + 1))
            posstr = '({0},{1})'.format(targetdata['position'][0],targetdata['position'][1])
            sizestr = '{0}x{1}'.format(targetdata['size'][0],targetdata['size'][1])
            xspeedstr = str(targetdata['xspeed'])
            yspeedstr = str(targetdata['yspeed'])
            bulsizestr = '{0}x{1}'.format(targetdata['bulletsize'][0], targetdata['bulletsize'][1])
            shootwaitstr = '{0} milliseconds'.format(targetdata['shootwait'])
            shootfreqstr = '{0}%'.format(int(targetdata['shootfreq'] * 100))

            self.sttTargetTeam.SetLabel(teamstr)
            self.sttTargetPosition.SetLabel(posstr)
            self.sttTargetSize.SetLabel(sizestr)
            self.sttTargetSpeedX.SetLabel(xspeedstr)
            self.sttTargetSpeedY.SetLabel(yspeedstr)
            self.sttTargetBulletSize.SetLabel(bulsizestr)
            self.sttTargetShootWait.SetLabel(shootwaitstr)
            self.sttTargetShootFreq.SetLabel(shootfreqstr)

            r,g,b = targetdata['color1']
            self.pnlTargetColor1.SetBackgroundColour(wx.Colour(r,g,b))
            self.pnlTargetColor1.ClearBackground()
            r,g,b = targetdata['color2']
            self.pnlTargetColor2.SetBackgroundColour(wx.Colour(r,g,b))
            self.pnlTargetColor2.ClearBackground()

            self.btnCopyTarget.Enable(1)
            self.btnDeleteTarget.Enable(1)
            self.btnTargetTeam.Enable(1)
            self.btnTargetPosition.Enable(1)
            self.btnTargetSize.Enable(1)
            self.btnTargetSpeedX.Enable(1)
            self.btnTargetSpeedY.Enable(1)
            self.btnTargetColor1.Enable(1)
            self.btnTargetColor2.Enable(1)
            self.btnTargetBulletSize.Enable(1)
            self.btnTargetShootWait.Enable(1)
            self.btnTargetShootFreq.Enable(1)

        else:
            self.sttTargetTeam.SetLabel('')
            self.sttTargetPosition.SetLabel('')
            self.sttTargetSize.SetLabel('')
            self.sttTargetSpeedX.SetLabel('')
            self.sttTargetSpeedY.SetLabel('')
            self.sttTargetBulletSize.SetLabel('')
            self.sttTargetShootWait.SetLabel('')
            self.sttTargetShootFreq.SetLabel('')

            self.pnlTargetColor1.SetBackgroundColour(wx.NullColour)
            self.pnlTargetColor1.ClearBackground()
            self.pnlTargetColor2.SetBackgroundColour(wx.NullColour)
            self.pnlTargetColor2.ClearBackground()

            self.btnCopyTarget.Enable(0)
            self.btnDeleteTarget.Enable(0)
            self.btnTargetTeam.Enable(0)
            self.btnTargetPosition.Enable(0)
            self.btnTargetSize.Enable(0)
            self.btnTargetSpeedX.Enable(0)
            self.btnTargetSpeedY.Enable(0)
            self.btnTargetColor1.Enable(0)
            self.btnTargetColor2.Enable(0)
            self.btnTargetBulletSize.Enable(0)
            self.btnTargetShootWait.Enable(0)
            self.btnTargetShootFreq.Enable(0)

        self.Layout()

class GameSelectorDialog(wx.Dialog):
    def __init__(self, parent, title):
        wx.Dialog.__init__(self, parent, -1, title, size=(300,280))

        #Load games from files
        self.games = []
        self.names = []
        
        try:
            gamesfile = io.read('games.snf')
        except IOError:
            err = wx.MessageDialog(self, "Could not find games.snf. This probably means that this application has not been placed in the main Senso directory. Please ensure that games.snf and the games folder are in the same directory as this application and try again.", \
                                   'Error', wx.OK|wx.ICON_ERROR)
            err.ShowModal()
            err.Destroy()
            self.EndModal(wx.ID_CANCEL)

        for i in gamesfile['game']:
            try:
                game = io.read(i['file'])

                #Get ships/targets
                try:
                    ships = game['ship']
                except KeyError:
                    ships = []
                try:
                    targets = game['target']
                except KeyError:
                    targets = []

                #Figure out the number of human players
                nplayers = 0
                for i in ships:
                    if i['human']:
                        nplayers += 1
                
                self.names.append(i['name'])
                self.games.append({'file':i['file'], 'players':nplayers, \
                              'ships':len(ships), \
                              'targets':len(targets)})
            except IOError:
                pass

        vbox = wx.BoxSizer(wx.VERTICAL)
        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        hbox2 = wx.BoxSizer(wx.HORIZONTAL)
        vbox1 = wx.BoxSizer(wx.VERTICAL)
        vbox2 = wx.BoxSizer(wx.VERTICAL)

        label = wx.StaticText(self, -1, text)

        self.lstGames = wx.ListBox(self, -1, size=(120,200), choices=names, style=wx.LB_SINGLE)

        lbl1 = wx.StaticText(self, -1, 'File:')
        lbl2 = wx.StaticText(self, -1, 'Players:')
        lbl3 = wx.StaticText(self, -1, 'Ships:')
        lbl4 = wx.StaticText(self, -1, 'Targets:')
        vbox1.Add(lbl1, 0, wx.ALIGN_LEFT)
        vbox1.AddStretchSpacer()
        vbox1.Add(lbl2, 0, wx.ALIGN_LEFT)
        vbox1.AddStretchSpacer()
        vbox1.Add(lbl3, 0, wx.ALIGN_LEFT)
        vbox1.AddStretchSpacer()
        vbox1.Add(lbl4, 0, wx.ALIGN_LEFT)

        self.lblFile = wx.StaticText(self, -1, '')
        self.lblPlayers = wx.StaticText(self, -1, '')
        self.lblShips = wx.StaticText(self, -1, '')
        self.lblTargets = wx.StaticText(self, -1, '')
        vbox2.Add(self.lblFile, 0, wx.ALIGN_RIGHT)
        vbox2.AddStretchSpacer()
        vbox2.Add(self.lblPlayers, 0, wx.ALIGN_RIGHT)
        vbox2.AddStretchSpacer()
        vbox2.Add(self.lblShips, 0, wx.ALIGN_RIGHT)
        vbox2.AddStretchSpacer()
        vbox2.Add(self.lblTargets, 0, wx.ALIGN_RIGHT)

        hbox1.Add(self.lstGames, 0, wx.LEFT, 10)
        hbox1.AddStretchSpacer()
        hbox1.Add(vbox1, 0, wx.ALIGN_CENTER_VERTICAL)
        hbox1.AddStretchSpacer()
        hbox1.Add(vbox2, 0, wx.ALIGN_CENTER_VERTICAL|wx.RIGHT, 10)

        self.btnNew = wx.Button(self, -1, 'New')
        self.btnCopy = wx.Button(self, -1, 'Copy')
        self.btnDelete = wx.Button(self, -1, 'Delete')

        self.Bind(wx.EVT_BUTTON, self.OnNew, self.btnNew)
        self.Bind(wx.EVT_BUTTON, self.OnCopy, self.btnCopy)
        self.Bind(wx.EVT_BUTTON, self.OnDelete, self.btnDelete)

        self.btnDelete.Enable(0)

        hbox2.AddStretchSpacer()
        hbox2.Add(self.btnNew, 0)
        hbox2.AddStretchSpacer()
        hbox2.Add(self.btnCopy, 0)
        hbox2.AddStretchSpacer()
        hbox2.Add(self,btnDelete, 0)
        hbox2.AddStretchSpacer()

        buttons = self.CreateButtonSizer(wx.OK|wx.CANCEL)

        vbox.Add(hbox1, 0, wx.EXPAND|wx.TOP, 10)
        vbox.AddStretchSpacer()
        vbox.Add(hbox2, 0, wx.EXPAND)
        vbox.AddStretchSpacer()
        vbox.Add(buttons, 0, wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.EXPAND, 10)

        self.SetSizer(vbox)
        self.Layout()
        self.Centre()

    def OnNew(self, event):
        pass

    def OnCopy(self, event):
        pass

    def OnDelete(self, event):
        pass

class SizeDialog(wx.Dialog):
    def __init__(self, parent, text, title, defsize=(0,0)):
        wx.Dialog.__init__(self, parent, -1, title, size=(300,150))

        vbox = wx.BoxSizer(wx.VERTICAL)
        hbox = wx.BoxSizer(wx.HORIZONTAL)

        label = wx.StaticText(self, -1, text)

        self.txtWidth = wx.TextCtrl(self, -1, str(defsize[0]))
        xlabel = wx.StaticText(self, -1, 'X')
        self.txtHeight = wx.TextCtrl(self, -1, str(defsize[1]))

        hbox.AddStretchSpacer()
        hbox.Add(self.txtWidth, 1, wx.ALIGN_CENTER_VERTICAL)
        hbox.Add(xlabel, 0, wx.ALIGN_CENTER_VERTICAL|wx.LEFT|wx.RIGHT, 5)
        hbox.Add(self.txtHeight, 1, wx.ALIGN_CENTER_VERTICAL)
        hbox.AddStretchSpacer()

        buttons = self.CreateButtonSizer(wx.OK|wx.CANCEL)

        vbox.AddStretchSpacer()
        vbox.Add(label, 0, wx.ALIGN_CENTER_HORIZONTAL)
        vbox.AddStretchSpacer()
        vbox.Add(hbox, 0, wx.EXPAND)
        vbox.AddStretchSpacer()
        vbox.Add(buttons, 0, wx.LEFT|wx.RIGHT|wx.EXPAND, 10)
        vbox.AddStretchSpacer()

        self.SetSizer(vbox)
        self.Layout()
        self.Centre()

def ChangeSize(parent, text, title, cursize):
    while 1:
        dlg = SizeDialog(parent, text, title, cursize)
        if dlg.ShowModal() == wx.ID_OK:
            w = dlg.txtWidth.GetValue()
            h = dlg.txtHeight.GetValue()
            dlg.Destroy()
            try:
                w = int(w)
                h = int(h)
                dlg.Destroy()
                if w > 0 and h > 0:
                    return w, h
                else:
                    err = wx.MessageDialog(parent, 'Only positive numbers, please!', \
                                           'Error', wx.OK|wx.ICON_ERROR)
                    err.ShowModal()
                    err.Destroy()
            except ValueError:
                err = wx.MessageDialog(parent, 'Please enter only integers.', \
                                       'Error', wx.OK|wx.ICON_ERROR)
                err.ShowModal()
                err.Destroy()
        else:
            dlg.Destroy()
            return cursize

def ChangePosition(parent, text, title, curpos):
    """A slight variation of ChangeSize, this one allows non-positive
    numbers."""
    while 1:
        dlg = SizeDialog(parent, text, title, curpos)
        if dlg.ShowModal() == wx.ID_OK:
            x = dlg.txtWidth.GetValue()
            y = dlg.txtHeight.GetValue()

            dlg.Destroy()
            try:
                x = int(x)
                y = int(y)
                dlg.Destroy()
                return x, y
            except ValueError:
                err = wx.MessageDialog(parent, 'Please enter only integers.', \
                                       'Error', wx.OK|wx.ICON_ERROR)
                err.ShowModal()
                err.Destroy()
        else:
            dlg.Destroy()
            return curpos

def ChangeInt(parent, text, title, curnum):
    while 1:
        dlg = wx.TextEntryDialog(parent, text, title)
        dlg.SetValue(str(curnum))
        if dlg.ShowModal() == wx.ID_OK:
            try:
                val = int(dlg.GetValue())
                dlg.Destroy()
                if val >= 0:
                    return val
                else:
                    err = wx.MessageDialog(parent, 'Only positive numbers, please!', \
                                           'Error', wx.OK|wx.ICON_ERROR)
                    err.ShowModal()
                    err.Destroy()
            except ValueError:
                err = wx.MessageDialog(parent, 'Please enter only integers.', \
                                       'Error', wx.OK|wx.ICON_ERROR)
                err.ShowModal()
                err.Destroy()
        else:
            dlg.Destroy()
            return curnum

def ChangePercent(parent, text, title, curnum):
    while 1:
        dlg = wx.TextEntryDialog(parent, text, title)
        dlg.SetValue(str(curnum*100))
        if dlg.ShowModal() == wx.ID_OK:
            try:
                val = float(dlg.GetValue())
                dlg.Destroy()
                if val >= 0 and val <= 100:
                    return val / 100.
                else:
                    err = wx.MessageDialog(parent, 'Please enter a number between 0 and 100.', \
                                           'Error', wx.OK|wx.ICON_ERROR)
                    err.ShowModal()
                    err.Destroy()
            except ValueError:
                err = wx.MessageDialog(parent, 'Please enter only numbers.', \
                                       'Error', wx.OK|wx.ICON_ERROR)
                err.ShowModal()
                err.Destroy()
        else:
            dlg.Destroy()
            return curnum

if __name__ == '__main__':
    app = wx.PySimpleApp()
    frame = Editor(None, wx.ID_ANY)
    app.MainLoop()
